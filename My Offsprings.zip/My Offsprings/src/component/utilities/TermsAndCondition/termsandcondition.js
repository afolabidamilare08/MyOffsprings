import React from 'react';

export const TermsandCondition = (props) => {

      return ( 
          <div className="TermsandCondition-div" style={props.style} >
              <div className="TermsandCondition-div_top" >
                 Terms And Conditions
              </div>
              <div className="TermsandCondition-div_body" >
                    {props.children}
              </div>
              <div className="TermsandCondition-div_foot" >
                    <button className="TermsandCondition-div_foot_1" onClick={ props.Agree }  > I Accept </button>
                    <button className="TermsandCondition-div_foot_2" onClick={ props.Cancel } > Cancel </button>
              </div>
          </div>
      );

}

export const TermsandConditionList =  (
            <ul>
                <li className="TermsandCondition-div_body_list" >
                    Your uploaded images for sales must include the current state of the product 
                    and the expected final state of the product.
                </li>
                <li className="TermsandCondition-div_body_list" >
                    You will be responsible for the transportation of the product
                    to the buyer , unless otherwise stated which Farmyapp will compensate you for.
                </li>
                <li className="TermsandCondition-div_body_list" >
                    The harvest date you will upload must be exact and in case of any changes please inform
                    everyone who has ordered for the product in Question
                </li>
                <li className="TermsandCondition-div_body_list" >
                    Input the minimum means of transportation required to carry units of your product
                    and the maximum amount it can carry , so proper estimation of transport cost can be 
                    made. 
                </li>
                <li className="TermsandCondition-div_body_list" >
                    Try as much as possible to respond to every comment on your products. 
                </li>
                <li className="TermsandCondition-div_body_list" >
                     Products ordered through Farmyapp should be priority no matter the demand for the products.
                </li>
                <li className="TermsandCondition-div_body_list" >
                     Please input the correct account number , bank name and account name in that , that's how you would
                     be paid. 
                </li>
                <li className="TermsandCondition-div_body_list" >
                     Every delivery should be made within 24 hours of harvest except otherwise agreed on. 
                </li>
                <li className="TermsandCondition-div_body_list" >
                     Please give customer services , having it in mind that you are a representative of 
                     Farming and Agricurlture at all times.
                </li>
                <li className="TermsandCondition-div_body_list" >
                     Products must be well described with all possible known name ( local , botanical , english e.t.c ) 
                </li>
                <li className="TermsandCondition-div_body_list" >
                     Products should be in proper condition on delivery
                </li>
                <li className="TermsandCondition-div_body_list" >
                     Make sure the buyer marks your order as delivered and also rate you so you can get paid 
                </li>
                <li className="TermsandCondition-div_body_list" >
                     Farmyapp is entitled to 3% of the cost of every products.
                </li>
            </ul>

    );

export const TermsandConditionListServices = (

    <ul>
        <li className="TermsandCondition-div_body_list" >
             Input the correct working hours and days.        
        </li>
        <li className="TermsandCondition-div_body_list" >
            Respond to every comments promptly.         
        </li>
        <li className="TermsandCondition-div_body_list" >
            Give the best customer service at all times ( Remember Your
            rating affects your recommendation ).        
        </li>
        <li className="TermsandCondition-div_body_list" >
            Arrive to deliver your service as timely as possible.           
        </li>
        <li className="TermsandCondition-div_body_list" >
            Cancel or ask for permission to deliver a service at another
            time if you would not be available at stipulated time.         
        </li>
        <li className="TermsandCondition-div_body_list" >
             Every material that would be used for service delivery , like 
             ( drugs, vaccine, oil e.t.c  ) should be paid for before service delivery.        
        </li>
        <li className="TermsandCondition-div_body_list" >
            Farmyapp is entitled to 3% of every hire cost.        
        </li>
    </ul>

);

export const TermsandConditionListOrder = (

    <ul>
        <li className="TermsandCondition-div_body_list" >
             Please ask every possible questions in the product comment section.        
        </li>
        <li className="TermsandCondition-div_body_list" >
             Cost of transportation cannot be refunded.
        </li>
        <li className="TermsandCondition-div_body_list" >
            It requires a great breach from product discription to be able to return products.       
        </li>
        <li className="TermsandCondition-div_body_list" >
            Transport is been charged per product so we advice you buy from farms as close as possible.     
        </li>
        <li className="TermsandCondition-div_body_list" >
            For product from long distance , you may be expected to pick them up at the bus station depending on quantity description.        
        </li>
        <li className="TermsandCondition-div_body_list" >
            Read other comments and replies , to get full knowledge of what the product you are buying is like.
        </li>
        <li className="TermsandCondition-div_body_list" >
            Note that every product is limited and you have to order yours as quickly as possible.
        </li>
        <li className="TermsandCondition-div_body_list" >
            Adding product to cart dosen't mean you have booked the product , it only when you have checked out your cart.
        </li>
    </ul>

);


export const TermsandConditionListSOrder = (

    <ul>
        <li className="TermsandCondition-div_body_list" >
             By hiring this service you are agreeing to pay for other expenses that will be incurred to render the service.      
        </li>
        <li className="TermsandCondition-div_body_list" >
            You have given the correct address and will be opened for the service you hired at the stipulated time.    
        </li>
        <li className="TermsandCondition-div_body_list" >
            You will be called for any variation in time that may occur based on the service you have hired.     
        </li>
    </ul>

);
