import React from 'react';

const Svg = (props) => {

    return   <svg className={props.className} style={{
        fill:props.style
    }} onClick={props.onClick} >
                <use xlinkHref={'icons/' + props.href } ></use>
            </svg>

}

export default Svg;

// <svg  >
//     <use xlinkHref="" ></use>
// </svg>