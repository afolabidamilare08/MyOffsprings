  import React from 'react';

const TopbannerDiv = (props) => {

      return ( 

        <div className="top-banner-div"
             onClick={props.closeshow}
             style={ { backgroundColor : props.backgroundcolor , transform: props.show ? 'translateY(0)' : 'translateY(-140rem)' , top:props.top  } }
               >
            {props.message}
        </div>

      );

}

export default TopbannerDiv;