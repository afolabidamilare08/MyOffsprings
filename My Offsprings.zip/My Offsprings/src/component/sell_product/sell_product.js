import React from 'react';
// import { InputWithLabel, LoginTextarea, LoginSelect } from '../login_components/login_components';


export const Productgallery = (props) => {

    return  <div className="sell_prouct-div_form-gal_div" >

                <div className="sell_prouct-div_form-gal_div-img" >
                    {props.placeholder}
                </div>

                <div className="sell_prouct-div_form-gal_div_div_form" >
                    <label for={props.label} className="sell_prouct-div_form-gal_div_div_form-label" >
                        Choose
                    </label>
                    <input id={props.label} type="file" style={{display:'none'}} onChange={props.pickimage} className="sell_prouct-div_form-gal_div_div_form-input" />
                </div>

            </div>

}

export const Productgallery2 = (props) => {

    return  <div className="sell_prouct-div_form-gal_div" >

                <div className="sell_prouct-div_form-gal_div-img" >
                    {props.placeholder}
                </div>

                <div className="sell_prouct-div_form-gal_div_div_form" >
                    <label for="file1" className="sell_prouct-div_form-gal_div_div_form-label" >
                        Choose
                    </label>
                    <input id="file1" type="file" style={{display:'none'}} onChange={props.pickimage} className="sell_prouct-div_form-gal_div_div_form-input" />
                </div>

            </div>

}





export const SellProduct = (props) => {

    return(

        <div className="sell_prouct-div" >

            <div className="sell_prouct-div_top" >
                Sell Product
            </div>

            <form onSubmit={props.form_submt} className="sell_prouct-div_form" >

                {props.children}

            </form>

        </div>

    );

}

