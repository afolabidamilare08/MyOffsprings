import React,{useEffect} from 'react';
import { Link } from 'react-router-dom/cjs/react-router-dom';
import {BsPen} from 'react-icons/bs';
import {RiDeleteBin6Line} from 'react-icons/ri';
import Aos from 'aos';
import 'aos/dist/aos.css';

const EditQuestionList = (props) => {

    useEffect( () => {
        Aos.init({duration:2000})
    } , [] )

    if( props.desc.length > 400 ){
        var qdesc = []
        for( var u = 0 ; u < 400 ; u++ ){
            qdesc.push(props.desc[u])
        }
    }else{
        qdesc = props.desc
    }

    if( props.title.length > 90 ){
        var qtitle = []
        for( var p = 0 ; p < 90 ; p++ ){
            qtitle.push(props.title[p])
        }
    }else{
        qtitle = props.title
    }


    return(

        <div className="question_list-div" data-aos="fade-up" data-aos-once={true}>

            <div className="question_list-div-top" >

                <div className="question_list-div-top-right" >

                    <Link className="question_list-div-top-right-title" to={props.to} > {qtitle}  </Link>

                </div>

            </div>

            <div className="question_list-div-body" >
                {qdesc} ...
            </div>

            <div className="question_list-div-opt" >
                
                <Link to={props.to} className="question_list-div-opt-edit" > <BsPen className="question_list-div-opt-edit-ic" /> Edit Question </Link>

                <button onClick={ props.delete } className="question_list-div-opt-delete" > <RiDeleteBin6Line className="question_list-div-opt-delete-ic" /> Delete Question </button>

            </div>

        </div>
    
    );

}


export default EditQuestionList;
