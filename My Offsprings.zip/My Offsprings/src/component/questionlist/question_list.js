import React,{useEffect} from 'react';
import { Link } from 'react-router-dom/cjs/react-router-dom';
import {BsPersonFill} from 'react-icons/bs';
import {BiChat} from 'react-icons/bi';
import Aos from 'aos';
import 'aos/dist/aos.css';


const QuestionList = (props) => {

    useEffect( () => {
        Aos.init({duration:2000})
    } , [] )

    if( props.desc.length > 400 ){
        var qdesc = []
        for( var i = 0 ; i < 400 ; i++ ){
            qdesc.push(props.desc[i])
        }
    }else{
        qdesc = props.desc
    }

    if( props.title.length > 90 ){
        var qtitle = []
        for( var g = 0 ; g < 90 ; g++ ){
            qtitle.push(props.title[g])
        }
    }else{
        qtitle = props.title
    }


    return(

        <div className="question_list-div" data-aos="fade-up" data-aos-once={true} >

            <div className="question_list-div-top" >

                <div className="question_list-div-top-left" >

                </div>

                <div className="question_list-div-top-right" >

                    <Link className="question_list-div-top-right-title" to={props.to} > {qtitle}  </Link>
                    {/* <div className="question_list-div-top-right-date" > 34 minuites ago </div> */}
                    {/* <div className="question_list-div-top-right-ans" > 205 Answers </div> */}

                </div>

            </div>

            <div className="question_list-div-body" >
                {qdesc} ...
                {/* <Link className="question_list-div-body-more" > ... read more </Link> */}
            </div>

            <div className="question-list_div-top" >

                <div className="question-list_div-top-left" >

                        <div className="question-list_div-top-left_img" >
                            
                            { props.img ? <img src={props.img} alt="" className="comment_div-top_img-pic" /> :                

                                <BsPersonFill className="question-list_div-top-left_img-ic" />

                            }

                        </div>

                        <div className="question-list_div-top-left_name" >
                            <span className="question-list_div-top-left_name-top" > {props.first_name} {props.last_name} </span>
                                <br/>
                            <span className="question-list_div-top-left_name-btm" > {props.time} </span>
                        </div>

                </div>

                <div className="question-list_div-top-right" >
                    <div className="question-list_div-top-right-react" >
                        <BiChat className="question-list_div-top-right-react-ic" />
                        {props.react} Reactions
                    </div>
                    <div className="question-list_div-top-right-beact" >
                        <span className="question-list_div-top-right-beact-quest" > Question Status:  </span>
                        <span className="question-list_div-top-right-beact-quest2" style={{
                            color: props.status ? 'green' : 'red' 
                        }} > {!props.status ? 'Not yet answered' : 'Answered' }  </span>
                    </div>
                </div>

            </div>

        </div>

    );

}

export default QuestionList;
