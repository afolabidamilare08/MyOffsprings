import React,{useEffect} from 'react';
import { Link } from 'react-router-dom';
import {AiFillStar, AiOutlineStar} from 'react-icons/ai';
import Aos from 'aos';
import 'aos/dist/aos.css';

const ProductList = (props) => {

    useEffect( () => {
        Aos.init({duration:2000})
    } , [] )

    if( props.product_name.length > 20 ){
        var pname = []
        for( var i = 0 ; i < 20 ; i++ ){
            pname.push(props.product_name[i])
        } 
        pname.push('...')
    }else{
        pname = props.product_name
    }

    return (

        <div className="product_list" data-aos="fade-up" data-aos-once={true} >

            <div className="product_list-pic" >
                <img src={props.image} alt="" className="product_list-pic-img" />
            </div>

            <div className="product_list-dec" >

                <Link className="product_list-dec-name" to={props.to} > {pname} </Link>

                <div className="product_list-dec-rat" >

                    { props.avg_rating > 0 ?   

                        <AiFillStar className="product_list-dec-rat-ic" />

                    : <AiOutlineStar className="product_list-dec-rat-ic" /> 

                    }

                    { props.avg_rating > 1 ? 

                        <AiFillStar className="product_list-dec-rat-ic" />

                    : <AiOutlineStar className="product_list-dec-rat-ic" /> 

                    }
                    
                    { props.avg_rating > 2 ? 

                        <AiFillStar className="product_list-dec-rat-ic" />

                    : <AiOutlineStar className="product_list-dec-rat-ic" /> 

                    }

                    { props.avg_rating > 3 ? 

                        <AiFillStar className="product_list-dec-rat-ic" />

                    : <AiOutlineStar className="product_list-dec-rat-ic" /> 

                    }

                    { props.avg_rating > 4 ? 

                        <AiFillStar className="product_list-dec-rat-ic" />

                    : <AiOutlineStar className="product_list-dec-rat-ic" /> 

                    }


                </div>

                <div className="product_list-dec-cat" >

                ₦ {new Intl.NumberFormat({ style: 'currency', currency: 'EUR' }).format(props.price) }
                    {/* <span className="product_list-dec-cat-one" > Category: </span>
                    <span className="product_list-dec-cat-two" > Feeder </span> */}
                </div>

            </div>

            <Link to={props.to} className="product_list-dec-btn" >
                Add to Cart
            </Link>

        </div>
        
    );

}

export default ProductList;

