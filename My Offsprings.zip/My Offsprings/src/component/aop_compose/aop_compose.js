import React from 'react';
import { BiImageAdd } from 'react-icons/bi';
import { LoginBtn, InputWithLabel } from '../login_components/login_components';
import {Link} from 'react-router-dom';
// import {GoogleLogin} from 'react-google-login';


// const GOOGLE_API_KEY = process.env.REACT_APP_GOOGLE_LOGIN_KEY



export const AopCompose = (props) => {

      return ( 
        
        <>

            <div className="aop_compose_top" > Ask A Question </div>

            { props.error ? 
                    <div className="login_page_template_mid_error" >
                        {props.msg}
                    </div> : null }

            <form className="aop_compose_form" onSubmit={props.submit} >

                <div className="aop_compose_form-div" >
                    <label className="aop_compose_form-div-label" > Question Title </label>
                    <input className="aop_compose_form-div-input"
                           type="text" 
                           placeholder="What's Your Question Title"
                           onChange={props.title_onChange} 
                           value={props.title_value}
                             />
                </div>

                <div className="aop_compose_form-div" >
                    <label className="aop_compose_form-div-label" > Question Description </label>
                    <textarea className="aop_compose_form-div-textarea" 
                              type="text" 
                              placeholder="Leave More Details About Your Question"
                              onChange={props.desc_onChange} 
                              value={props.desc_value}
                               ></textarea>
                </div>

                <div className="aop_compose_form-img" >

                    <div className="aop_compose_form-img-top" >
                        You Can Add An Image If Necessary 
                    </div>

                    <div style={{ display:'flex',flexDirection:'column',alignItems:'center',width:'fit-content'}} >
                        <label className="aop_compose_form-img-label" for="item" >
                            
                            { props.image ? 
                            
                                <img className="aop_compose_form-img-label-img" alt="" src={props.image} />

                            : <BiImageAdd className="aop_compose_form-img-label-ic"/> }

                        </label>
                        
                        { props.image ? <Link to="#" onClick={props.remove_img} className="aop_compose_form-img-label-remove" > remove </Link> : null }

                    </div>

                    <input className="aop_compose_form-img-input" onChange={props.image_change} type="file" id="item" />

                </div>

                <LoginBtn disabled={props.disabled} value={props.btn_value} />

            </form>



        </>

      );

}



export const AopLeftSignIn = (props) => {

    return ( 
      
      <>

          <div className="aop_compose_top" > Sign In </div>

           { props.error ?  <div className="login_page_template_mid_error" > {props.msg} </div> : null }

          <form className="aop_compose_form" onSubmit={props.submit} >

              <InputWithLabel
                label="Email/Username"
                type="text"
                value={props.email_value}
                onChange={ props.emailonChange }
              />

              <InputWithLabel
                label="Password"
                type="password"
                value={props.password_value}
                onChange={ props.passwordonChange }
              />

              <LoginBtn disabled={props.disabled} value="Sign In" />

          </form>

          {/* <div className="login_page_template_mid_or" >
                    <div className="login_page_template_mid_or_line" ></div>
                    <div className="login_page_template_mid_or_text" > or </div>
                    <div className="login_page_template_mid_or_line" ></div>
                </div>
                <div className="login_page_template_mid_social" >
                <div className="login_page_template_mid_social" >
                    <div className="login_page_template_mid_social_top" > Sign in with </div>
                    <div className="login_page_template_mid_social_list" >
                        <button className="login_page_template_mid_social_list_link" >
                            <FaGoogle className="login_page_template_mid_social_list_link-ic"/>
                        </button>
                        <Link to="/" className="login_page_template_mid_social_list_link" ></Link>
                        <Link to="/" className="login_page_template_mid_social_list_link" ></Link>
                                <GoogleLogin
                                    clientId={GOOGLE_API_KEY}
                                    onSuccess={props.responseGoogle}
                                    onFailure={props.responseGoogle}
                                    isSignedIn={false}
                                />
                   </div>
                </div>
          </div> */}

                <Link className="login_page_template_mid_already" to="/signup" > I Don't Have An Account Yet </Link>


      </>

    );

}

