import React from 'react';
import ProfileImg from '../utilities/img/profile_user.png';
import PreOrder from '../utilities/img/delivery-man.png';

export const InputWithLabel = (props) => {

    return (

        <div className="inputwithlabel" >
            <label className="inputwithlabel_label" > {props.label} </label>
            <input className="inputwithlabel_input" min={ props.type === 'number' ? 0 : '' } autoComplete={ props.type === 'password' ? "true" : "false" } required placeholder="" type={props.type} onChange={props.onChange} value={props.value} />
        </div>

    );

}


export const LoginBtn = (props) => {

    return (

        <button className="login_btn" disabled={props.disabled} >
            {props.value}
        </button>

    );

}

export const LoginSelect = (props) => {

    return (


        <div className="inputwithlabel" >

            <label className="inputwithlabel_label" > {props.label} </label>

            <select className="login_select" required onChange={props.onChange} value={props.value} >
                {props.options}
            </select>

        </div>

    );

}


export const LoginTextarea = (props) => {

    return (

        <div className="inputwithlabel" >

            <label className="inputwithlabel_label" > {props.label} </label>

            <textarea className="inputwithlabel_input" required style={{resize:'none'}} onChange={props.onChange} value={props.value}  >

            </textarea>

        </div>

    )

}


export const BoxMessage = (props) => {

    return (

        <div className="welcome_user">

            <div className="welcome_user_png">
                <img src={PreOrder} alt="png" className="welcome_user_png_img" />
            </div>

            <div className="welcome_user_name">
                {props.title}
            </div>

            <div className="welcome_user_story">
                {props.story}
            </div>

            {/* <a href="{% url 'dashboard' %}" className="edit_profile_div_middle_form_btn welcome_user_btn" >
            Go To Dashboard
            </a> */}

        </div>

    )

}


export const BoxMessage2 = (props) => {

    return (

        <div className="welcome_user">

            <div className="welcome_user_png">
                <img src={ProfileImg} alt="png" className="welcome_user_png_img" />
            </div>

            <div className="welcome_user_name">
                {props.title}
            </div>

            <div className="welcome_user_story">
                {props.story}
            </div>

            {/* <a href="{% url 'dashboard' %}" className="edit_profile_div_middle_form_btn welcome_user_btn" >
            Go To Dashboard
            </a> */}

        </div>

    )

}