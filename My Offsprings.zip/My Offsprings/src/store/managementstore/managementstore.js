import React from 'react';


 export  default React.createContext({
    
        User_token: null,
        User_id : null,
        Loginhandler : () => {},
        Logouthandler : () => {},
        Search_Value:'',
        set_search_value: () => {},
        aSearch_Value:'',
        set_asearch_value: () => {},
        User_Cart:null,
        Refresh_Cart: () => {},
        Notification_List:null,
        Unread_Notification_List:null,
        Refresh_Notification: () => {},
        Backend_url:null
    })


    

