import React,{Component} from 'react';
import '../css/main.css';
import {BrowserRouter} from 'react-router-dom';
import Store from './managementstore/managementstore';
import Axios from 'axios';

 
class LogicStore extends Component {

  state = {
    User_token:null,
    User_id:null,
    Search_Value:'',
    aSearch_Value:'',
    User_Cart:null,
    Notification_List:null,
    Unread_Notification_List:null,
    backend_url:'http://127.0.0.1:8000'
  }

  componentDidMount(){

    

    if(localStorage.getItem('offspring-token') && localStorage.getItem('offspring-userid') ){
      this.setState({User_token:localStorage.getItem('offspring-token')})
      this.setState({User_id:localStorage.getItem('offspring-userid')})
      // this.setState({User_cart_id:localStorage.getItem('farmyapp-usercartid')})
      Axios.defaults.headers.common['Authorization'] = 'Token ' +localStorage.getItem('offspring-token');
      this.Cart_Refresh() 

        const uSeR_id = localStorage.getItem('offspring-userid')

        Axios.get('notification/notifications/' + uSeR_id + '/' ).then(

          response => {
            this.Notification_Sorting(response.data.notification)
          }

        ).catch()


    }

    if(!localStorage.getItem('offspring-token') || !localStorage.getItem('offspring-userid')){
      this.setState({User_token:null})
      this.setState({User_id:null})
      this.setState({User_Cart:null})
      Axios.defaults.headers.common['Authorization'] = null;
    }

  }

  Cart_Refresh = () => {

    Axios.get('/mycart/mycart/' ).then(

      response => {
        this.setState({User_Cart:response.data.results[0]})
      }

    ).catch()

  }




  Notification_Sorting = (data) => {

    var notifications = data
    var unread_notifications = []

    for (let p = 0; p < notifications.length; p++) {
      
      if ( notifications[p].read === false ) {
        unread_notifications.push(notifications[p])
      }

    }

    this.setState({
      Notification_List:notifications,
      Unread_Notification_List:unread_notifications
    })

  }




  GetNewNotification = () => {
    Axios.get('notification/notifications/' + this.state.User_id + '/' ).then(

      response => {
        this.Notification_Sorting(response.data.notification)
      }

    ).catch()
  }



  Login = (detail) => {
    this.setState({User_token:detail.token})
    this.setState({User_id:detail.id})
    Axios.defaults.headers.common['Authorization'] = 'Token '+ detail.token;
    this.Cart_Refresh()
  }

  Logout= () => {
    this.setState({User_token:false})
    this.setState({User_id:false})
    this.setState({User_Cart:null})
    localStorage.removeItem('offspring-token')
    localStorage.removeItem('offspring-userid')
    Axios.defaults.headers.common['Authorization'] = null ;
  }

  set_search = (txt) => {
    this.setState({Search_Value:txt})
  }

  aset_search = (txt) => {
    this.setState({Search_Value:txt})
  }


  render() {

        return (
          <BrowserRouter>
            {/* <ScrollMemory/> */}
              <Store.Provider

              value={{
                User_token:this.state.User_token,
                User_id:this.state.User_id,
                Loginhandler:this.Login,
                Logouthandler:this.Logout,
                Search_Value:this.state.Search_Value,
                set_search_value:this.set_search,
                aSearch_Value:this.state.aSearch_Value,
                aset_search_value:this.aset_search,
                Refresh_Cart:this.Cart_Refresh,
                User_Cart:this.state.User_Cart,
                Notification_List:this.state.Notification_List,
                Unread_Notification_List:this.state.Unread_Notification_List,
                Refresh_Notification:this.GetNewNotification,
                Backend_url:this.state.backend_url
              }}

              >

                { this.props.children }
                  
              </Store.Provider>
          </BrowserRouter>
        );

 }

}


export default LogicStore;