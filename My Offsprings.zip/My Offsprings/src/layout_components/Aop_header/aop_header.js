import React,{useContext} from 'react';
import { FaSearch } from 'react-icons/fa';
import { FiShoppingBag, FiUser } from 'react-icons/fi';
import { BsHouse} from 'react-icons/bs';
import { MdDehaze } from 'react-icons/md';
import {Link} from 'react-router-dom'; 
import LogoImage from '../../component/utilities/img/mom1.png';
import LogoImage2 from '../../component/utilities/img/mom.png';
import Store from '../../store/managementstore/managementstore';


const AopHeader = (props) => { 

    const context = useContext(Store)

      return ( 
          <div className="aop_header" >
            <div className="aop_header_top" >
                <Link to="/aop" className="aop_header_top_logo" >
                <Link to='/' className="main_header_top_logo" >
                    {/* <FaBabyCarriage className="main_header_top_logo_ic" />  */}
                    <img src={LogoImage} alt="" className="main_header_top_logo-img" />
                    <img src={LogoImage2} alt="" className="main_header_top_logo-img2" />
                </Link>
                </Link>
                <form onSubmit={props.search} className="aop_header_top_search" >
                    <input type="search" placeholder="What question are you looking for...?" value={ props.searchvalue } onChange={ props.onChangesearchvalue } className="aop_header_top_search_input"  />
                    <button className="aop_header_top_search_btn"  >
                        <FaSearch className="aop_header_top_search_btn_ic" />
                    </button>
                </form>
                <div className="aop_header_top_right" >
                    <Link to="/aop" className="aop_header_top_right_link aop_header_top_right_dont" >
                        <BsHouse className="aop_header_top_right_link_ic" />
                        <div className="aop_header_top_right_link_txt" >
                            Home
                        </div>
                    </Link>

                    <Link to="/profile" className="aop_header_top_right_link  aop_header_top_right_dont" >
                    { context.Unread_Notification_List ? 
                                
                                context.Unread_Notification_List.length > 0 ?
                                    <div className="main_header_top_right_link_dot2" ></div>
                                : null

                                : null }
                        <FiUser className="aop_header_top_right_link_ic" />
                        <div className="aop_header_top_right_link_txt" >
                            Profile
                        </div>
                    </Link>

                    <div onClick={props.openit} className="aop_header_top_right_link aop_header_top_right_new " >
                    { context.Unread_Notification_List ? 
                                
                                context.Unread_Notification_List.length > 0 ?
                    <div className="aop_header_top_right_link_dot2" ></div>
                                : null

                                : null }
                        <MdDehaze className="aop_header_top_right_link_ic" />
                    </div>

                    <Link to="" className="aop_header_top_right_link aop_header_top_right_dont" >
                        <FiShoppingBag className="aop_header_top_right_link_ic" />
                        <div className="aop_header_top_right_link_txt" >
                            Store
                        </div>
                    </Link>

                </div>
            </div>

          </div>
      );

}

export default AopHeader;