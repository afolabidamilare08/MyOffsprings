import React,{useContext} from 'react';
import {Link} from 'react-router-dom'; 
import { BsFillCaretLeftFill } from 'react-icons/bs';
import { FiShoppingCart , FiUser , FiUsers } from 'react-icons/fi';
import { BsQuestionSquare , BsHouse } from 'react-icons/bs';
import LogoImage from '../../component/utilities/img/mom1.png';
import Store from '../../store/managementstore/managementstore';

const AdminProfileHeader = (props) => {

    const context = useContext(Store)

      return ( 
          <div className="profile_header" >
               
               <Link to="#" onClick={props.goback} className="profile_header_logo" >
               <img src={LogoImage} alt="" className="main_header_top_logo-img" />

                     <BsFillCaretLeftFill className="profile_header_logo_back"  />

               </Link>

               <div className="profile_header_mid" >
                    {props.title}
               </div>

               <div className="profile_header_right" >

                    <Link to={'/'} className="profile_header_right_link" >
                        <BsHouse className="profile_header_right_link_ic" />
                        <div className="profile_header_right_link_txt" > Home </div>
                    </Link>

                    <Link to={'/my_cart'} className="profile_header_right_link" >
                    { context.User_Cart ? 
                            
                            context.User_Cart.items.length > 0 ?
                                <div className="main_header_top_right_link_dot" > {context.User_Cart.items.length} </div>
                            : null

                            : null }
                        <FiShoppingCart className="profile_header_right_link_ic" />
                        <div className="profile_header_right_link_txt" > Cart </div>
                    </Link>
                    
                    <Link to={'/aop'} className="profile_header_right_link" >
                        <BsQuestionSquare className="profile_header_right_link_ic" />
                        <div className="profile_header_right_link_txt" > AOP </div>
                    </Link>  

                    <Link to={'/referal'} className="profile_header_right_link" >
                        <FiUsers className="profile_header_right_link_ic" />
                        <div className="profile_header_right_link_txt" > Referals </div>
                    </Link>

                    <Link to={'/profile'} className="profile_header_right_link" >
                    { context.Unread_Notification_List ? 
                                
                                context.Unread_Notification_List.length > 0 ?
                                    <div className="main_header_top_right_link_dot2" ></div>
                                : null

                                : null }
                        <FiUser className="profile_header_right_link_ic" />
                        <div className="profile_header_right_link_txt" > Profile </div>
                    </Link>

               </div>

               <div className="profile_header_cart" >
                        <Link to="/my_cart" className="profile_header_cart_link" >
                        { context.User_Cart ? 
                            
                            context.User_Cart.items.length > 0 ?
                                <div className="main_header_top_right_link_dot profile_header_top_right_link_dot" > {context.User_Cart.items.length} </div>
                            : null

                            : null }
                            <FiShoppingCart className="profile_header_cart_link_ic" />
                        </Link>
               </div>

          </div>
      );

}

export default AdminProfileHeader;