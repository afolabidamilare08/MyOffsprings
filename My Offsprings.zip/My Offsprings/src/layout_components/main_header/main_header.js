import React,{ useState,useEffect,useContext } from 'react';
import { FaSearch } from 'react-icons/fa';
import { FiShoppingCart , FiUser } from 'react-icons/fi';
import { BsQuestionSquare } from 'react-icons/bs';
import { MdDehaze } from 'react-icons/md';
import {Link} from 'react-router-dom'; 
import Axios from 'axios'; 
import Store from '../../store/managementstore/managementstore';
import LogoImage from '../../component/utilities/img/all.png';
import LogoImage2 from '../../component/utilities/img/check.png';
// import {AiOutlinePlus} from 'react-icons/ai';
// import BtnSpin from '../../component/utilities/btnSpin/btnSpin';
import CategoryLeft from '../../e_pages/categoy-left/category-left';
import CategoryLeft2 from '../../e_pages/categoy-left/category-left2';

const MainHeader = (props) => { 

    const context = useContext(Store)

    const [ category , setcategory ] = useState(null)
    const [ showallcat , setshowallcat ] = useState(false)

    useEffect( () => {

        Axios.get('/myproduct/rcategory/?limit=1000&offset=0').then(

            response => {
                setcategory(response.data.results)
            }

        ).catch()

    } , [ context.User_Cart ] )


      return ( 
          <div className="main_header" >
            <div className="main_header_top" >
                <Link to='/' className="main_header_top_logo" >
                    <img src={LogoImage} alt="" className="main_header_top_logo-img" />
                    <img src={LogoImage2} alt="" className="main_header_top_logo-img2" />
                </Link>
                <form onSubmit={props.search} className="main_header_top_search" >
                    <input type="search" placeholder="What are you looking for...?" value={ props.searchvalue } onChange={ props.onChangesearchvalue } className="main_header_top_search_input"  />
                    <button className="main_header_top_search_btn"  >
                        <FaSearch className="main_header_top_search_btn_ic" />
                    </button>
                </form>
                <div className="main_header_top_right" >
                    <Link to="/my_cart" className="main_header_top_right_link" >
                        
                        { context.User_Cart ? 
                            
                            context.User_Cart.items.length > 0 ?
                                <div className="main_header_top_right_link_dot" > {context.User_Cart.items.length} </div>
                            : null

                            : null }

                        <FiShoppingCart className="main_header_top_right_link_ic" />
                        <div className="main_header_top_right_link_txt" >
                            Cart
                        </div>
                    </Link>

                    <Link to="/profile" className="main_header_top_right_link main_header_top_right_dont " >

                        { context.Unread_Notification_List ? 
                                
                                context.Unread_Notification_List.length > 0 ?
                                    <div className="main_header_top_right_link_dot2" ></div>
                                : null

                                : null }
                        <FiUser className="main_header_top_right_link_ic" />
                        <div className="main_header_top_right_link_txt" >
                            Profile
                        </div>
                    </Link>

                    <Link to="/aop" className="main_header_top_right_link main_header_top_right_dont" >
                        <BsQuestionSquare className="main_header_top_right_link_ic" />
                        <div className="main_header_top_right_link_txt" >
                            Aop
                        </div>
                    </Link>

                </div>
            </div>
            
            { category ? 
            
                category.length > 0 ?

                    <div className="main_header_btm" >
                        <div className="main_header_btm_more" onClick={ () => setshowallcat(!showallcat) } >
                            Categories  
                            <MdDehaze onClick={ () => setshowallcat(!showallcat) } className="main_header_btm_more_ic" />
                        </div>
                        <div className="main_header_btm_list" id="main_header_btm_list" >
                        { category.map( (category,index) => {
                                return <Link key={index} to={'/products/r_categories/' + category.cat_name + '/' + category.id } className="main_header_btm_list_link" >
                                        {category.cat_name} 
                                        </Link>
                            } )}
                        </div>

                    </div>

 
                : null

            : null}

            <div className="main_header_btm_fix" style={{
                transform: showallcat ? 'translateX(0)' : 'translateX(-80rem)'
            }} >

                { props.our ? <CategoryLeft2/> : <CategoryLeft/> }

            </div>

            <div className="main_header_btm_fix-other" onClick={ () => setshowallcat(false) } style={{
                transform: showallcat ? 'translateX(0)' : 'translateX(-800rem)'
            }} >

            </div>

          </div>
      );

}

export default MainHeader;