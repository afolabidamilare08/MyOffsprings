import React from 'react';
import {Link} from 'react-router-dom';

export const FooterStickyLink = (props) => {

      return ( 
          <div className="footer-div-sticky-link" >
              {props.other}
              <Link to={props.to} className="footer-div-sticky-link-a" >
                    {props.icon}
                    <div className="footer-div-sticky-link-a-txt" > {props.txt} </div>
              </Link>
          </div>
      ); 

}

