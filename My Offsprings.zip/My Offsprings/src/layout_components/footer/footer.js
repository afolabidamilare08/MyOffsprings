import React,{useContext} from 'react';
import {Link} from 'react-router-dom';
import Logo from '../../component/utilities/img/all.png';
import {FooterStickyLink} from './footer-sticky-link';
import {GiWallet} from 'react-icons/gi';
import {FiClipboard, FiShoppingBag,FiUser} from 'react-icons/fi';
import {BsHouse, BsQuestionSquare, BsWallet} from 'react-icons/bs';
import { AiFillHome, AiFillQuestionCircle } from 'react-icons/ai';
import { FaUser , FaFacebookSquare, FaTwitterSquare, FaInstagramSquare, FaLinkedinIn } from 'react-icons/fa';
import Store from '../../store/managementstore/managementstore';



const Footerdiv = (props) => {

    const context = useContext(Store)

      return ( 

        <>

        { props.showlinks ? null : 
        
        <div className="footer-div-sticky" >

        <FooterStickyLink 
            to="/"
            icon={
                <AiFillHome className="footer-div-sticky-link-a-ic"/>
            }
            txt="Home"
        />

        <FooterStickyLink
            icon={
                <AiFillQuestionCircle className="footer-div-sticky-link-a-ic"/>
            }
            to="/aop"
            txt="Aop"
        />

        <FooterStickyLink
            icon={
                <GiWallet className="footer-div-sticky-link-a-ic"/>
            }
            to="/referal"
            txt="Wallet"
        />

        <FooterStickyLink
            icon={
                <FaUser className="footer-div-sticky-link-a-ic"/>
            }
            to="/profile"
            txt="Profile"
            other={ context.Unread_Notification_List ? 
                                
                context.Unread_Notification_List.length > 0 ?
                    <div className="footer-div-sticky-link-a-dot" ></div>
                : null

                : null }
        />

    </div>

        }

        <div className="footer-div" >

            <div className="footer-div-top" >
                <Link to="/" className="footer-div-top-img" >
                        <img alt="" src={Logo} className="footer-div-top-img-img" />
                </Link>
            </div>

            <div className="footer-div-others" >

                <div className="footer-div-others-contact" >

                    <div className="footer-div-others-contact-top" >
                        Follow Us On
                    </div>

                    <div className="footer-div-others-contact-mid" >
                        
                        <a href="https://www.facebook.com/My-Offsprings-103572728194329" className="footer-div-others-contact-mid-link" >

                            <FaFacebookSquare className="footer-div-others-contact-mid-link-ic" />

                            <span className="footer-div-others-contact-mid-link-txt" > Facebook </span>
                        </a>

                        <a href="https://twitter.com/my_offsprings?s=09" className="footer-div-others-contact-mid-link" >

                            <FaTwitterSquare className="footer-div-others-contact-mid-link-ic" />

                            <span className="footer-div-others-contact-mid-link-txt" > Twitter </span>
                        </a>

                        <a href="https://www.instagram.com/myoffspringng" className="footer-div-others-contact-mid-link" >

                            <FaInstagramSquare className="footer-div-others-contact-mid-link-ic" />

                            <span className="footer-div-others-contact-mid-link-txt" > Instagram </span>
                        </a>

                        <a href="https://web.facebook.com/FarmyApp-102367451372172" className="footer-div-others-contact-mid-link" >

                            <FaLinkedinIn className="footer-div-others-contact-mid-link-ic" />

                            <span className="footer-div-others-contact-mid-link-txt" > Linkedin </span>
                        </a>

                    </div>

                </div>

                <div className="footer-div-others-qlinks" >
                    <div className="footer-div-others-contact-top footer-div-others-qlinks-top" >
                        Quick Links 
                    </div>
                    <div className="footer-div-others-qlinks-mid" >
                        
                        <Link to="/" className="footer-div-others-qlinks-mid-link" >
                            <BsHouse className="footer-div-others-qlinks-mid-link-ic" />
                            Home
                        </Link>     

                        <Link to="/profile" className="footer-div-others-qlinks-mid-link" >
                            <FiUser className="footer-div-others-qlinks-mid-link-ic" />
                            Profile
                        </Link>

                        <Link to="/aop" className="footer-div-others-qlinks-mid-link" >
                            <BsQuestionSquare className="footer-div-others-qlinks-mid-link-ic" />
                            Aop
                        </Link>

                        <Link to="/referal" className="footer-div-others-qlinks-mid-link" >
                            <BsWallet className="footer-div-others-qlinks-mid-link-ic" />
                            Wallet
                        </Link>

                        <Link to="/preorder" className="footer-div-others-qlinks-mid-link" >
                            <FiClipboard className="footer-div-others-qlinks-mid-link-ic" />
                            Snap Order
                        </Link>

                        <Link to="/register_as_supplier" className="footer-div-others-qlinks-mid-link" >
                            <FiShoppingBag className="footer-div-others-qlinks-mid-link-ic" />
                            Become A Supplier
                        </Link>

                    </div>
                </div>

                <div className="footer-div-others-deli" >
                    <div className="footer-div-others-deli-top footer-div-others-contact-top" >
                        our Delivery Information
                    </div>
                    <div className="footer-div-others-deli-num" >
                        All products ordered on this platform would
                        be delivered to the stated address,
                        as specified on the order reciept.
                    </div>
                </div>

                <div className="footer-div-others-deli" >
                    <div className="footer-div-others-deli-top footer-div-others-contact-top" >
                        Contact us  
                    </div>
                    <div className="footer-div-others-deli-num" >
                        <a className="footer-div-others-deli-num-a" href="tel:+2347042995949" >
                            07042995949
                        </a>
                        <br/>
                        <a className="footer-div-others-deli-num-a" href="mailto:myoffsprings@gmail.com" >
                            myoffsprings@gmail.com
                        </a>
                    </div>
                </div>

            </div>

        </div>

        </>

      );

}

export default Footerdiv;