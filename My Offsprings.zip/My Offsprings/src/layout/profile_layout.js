import React,{useState,useContext,useEffect} from 'react';
import Axios from 'axios';
import { Switch , Route } from 'react-router-dom/cjs/react-router-dom.min';
import EditProfile from '../e_pages/editprofile/editprofile';
import ProfileHome from '../e_pages/profile/profile_home/profile_home';
import ReferalPage from '../e_pages/referal/referal';
import OrderListPage from '../e_pages/order_page/order_list_page';
import LoginPage from '../e_pages/login_page/login_page';
import Store from '../store/managementstore/managementstore';
import MainHeader from '../layout_components/main_header/main_header';
import FullOrderPage from '../e_pages/order_page/full_order';
import ChangeUserPasswordPage from '../e_pages/change_User_Password/change_user_password';
import CheckoutPreviewPage from '../e_pages/check_out/checkout_preview';
import Footerdiv from '../layout_components/footer/footer';

const ProfileLayoutPage = (props) => {


  const context = useContext(Store)

  useEffect( () => {

      setsearchValue({
          value:context.Search_Value
      })

  } , [context.Search_Value] )

   const [ searchValue , setsearchValue ] = useState({
       value:''
   })

   const searchHandler = (e) => {
       e.preventDefault()
      
       if ( searchValue.value !== '' ) {
          context.set_search_value(searchValue.value)         
          props.history.push('/products/search/query=' + searchValue.value )
       }

   }


     if ( Axios.defaults.headers.common['Authorization'] ) {
        
        var availableroute = <Switch>
            <Route path="/edit_profile" exact component={EditProfile} />
            <Route path="/profile" exact component={ ProfileHome } />
            <Route path="/referal" exact component={ReferalPage} />
            <Route path="/my_orders" exact component={OrderListPage} />
            <Route path="/my_order/:id" exact component={FullOrderPage} />
            <Route path="/profile/password" exact component={ChangeUserPasswordPage} />
            <Route path="/checkout_preview/:id" exact component={CheckoutPreviewPage} />
        </Switch>

     }else{
      availableroute = <Switch>
        <Route path="/edit_profile" exact component={LoginPage} />
        <Route path="/profile" exact component={ LoginPage } />
        <Route path="/referal" exact component={LoginPage} />
        <Route path="/my_orders" exact component={LoginPage} />
        <Route path="/my_order/:id" exact component={LoginPage} />
        <Route path="/profile/password" exact component={LoginPage} />
        <Route path="/checkout_preview/:id" exact component={LoginPage} />
      </Switch>
}

      return ( 

        <div className="main_body" >

            { !Axios.defaults.headers.common['Authorization'] ? 
                          <MainHeader
                          searchvalue={ searchValue.value}
                          onChangesearchvalue={ (event) => setsearchValue({value:event.target.value}) }
                          search={searchHandler}/>
                          : null  
          }

            {availableroute}

            <Footerdiv
                showlinks
            />

        </div>

      );

}

export default ProfileLayoutPage;