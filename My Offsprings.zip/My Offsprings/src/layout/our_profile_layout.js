import React,{useState,useContext,useEffect} from 'react';
import Axios from 'axios';
import { Switch , Route } from 'react-router-dom/cjs/react-router-dom.min';
import LoginPage from '../e_pages/login_page/quick_login_page';
import Store from '../store/managementstore/managementstore';
import MainHeader from '../layout_components/main_header/main_header';
import AllOrderListPage from '../e_pages/All_Order_List/all_order_list';
import EditOrderPage from '../e_pages/All_Order_List/All_Order_Full';
import Footerdiv from '../layout_components/footer/footer';
import AdminProfileHome from '../e_pages/admin_profile/profile_home/admin_profile_home';

const OurProfileLayoutPage = (props) => {


  const context = useContext(Store)

  useEffect( () => {

      setsearchValue({
          value:context.Search_Value
      })

  } , [context.Search_Value] )

   const [ searchValue , setsearchValue ] = useState({
       value:''
   })

   const searchHandler = (e) => {
       e.preventDefault()
      
       if ( searchValue.value !== '' ) {
          context.set_search_value(searchValue.value)         
          props.history.push('/products/search/query=' + searchValue.value )
       }

   }


     if ( Axios.defaults.headers.common['Authorization'] ) {
        
        var availableroute = <Switch>
            <Route path="/our_orders" exact component={AllOrderListPage} />
            <Route path="/our_order/:id" exact component={EditOrderPage} />
            <Route path="/its_admin" exact component={AdminProfileHome} />
        </Switch>

     }else{
      availableroute = <Switch>
            <Route path="/our_orders" exact component={LoginPage} />
            <Route path="/our_order/:id" exact component={LoginPage} />
            <Route path="/its_admin" exact component={LoginPage} />
      </Switch>
}

      return ( 

        <div className="main_body" >

            { !Axios.defaults.headers.common['Authorization'] ? 
                          <MainHeader
                          searchvalue={ searchValue.value}
                          onChangesearchvalue={ (event) => setsearchValue({value:event.target.value}) }
                          search={searchHandler}/>
                          : null  
          }

            {availableroute}

            <Footerdiv
                showlinks
            />

        </div>

      );

}

export default OurProfileLayoutPage;