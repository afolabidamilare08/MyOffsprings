import React,{useState,useContext} from 'react';
import Axios from 'axios';
import { Switch , Route } from 'react-router-dom/cjs/react-router-dom.min';
import AopHeader from '../layout_components/Aop_header/aop_header';
import Store from '../store/managementstore/managementstore';
import AosHomePage from '../a_pages/home/home';
import QuestionDetailPage from '../a_pages/question_detail/question_detail_page';
import {FiShoppingBag,FiUser} from 'react-icons/fi'; 
import {BiDoorOpen} from 'react-icons/bi';
import { BsHouse,BsQuestionSquare,BsPen, BsPersonFill } from 'react-icons/bs';
import { Link } from 'react-router-dom';
import {AopCompose,AopLeftSignIn} from '../component/aop_compose/aop_compose';
import BtnSpin from '../component/utilities/btnSpin/btnSpin';
import { useVerifyimg } from '../component/utilities/checkingforletter';
import AosSearchPage from '../a_pages/question_search/question_search';
import MyQuestionsPage from '../a_pages/my_questions/my_question_list';
import EditQuestions from '../a_pages/edit_questions/edit_questions';
import {BiArrowBack} from 'react-icons/bi';
import {FooterStickyLink} from '../layout_components/footer/footer-sticky-link';
import {GiWallet} from 'react-icons/gi';
import { AiFillHome, AiFillQuestionCircle } from 'react-icons/ai';
import { FaUser } from 'react-icons/fa';



const AopLayoutPage = (props) => {

    const context = useContext(Store)

     const [ searchValue , setsearchValue ] = useState({
         value:null
     })
     const [ openSlider , setopenSlider ] = useState({
         profile:false,
         compose:false
     })

     const amatch = () => {
        setsearchValue({
            value:props.match.params.query
        })
     }


     if( props.match.params.query && !searchValue.value ){
        amatch()
     }else{

     }



     const OpenProfile = () => {
         setopenSlider({
             profile:true,
             compose:false
         })
     }


     const Opencompose = () => {
        setopenSlider({
            profile:false,
            compose:true
        })
    }





     const searchHandler = (e) => {
         e.preventDefault()
        
         if ( searchValue.value !== '' ) {
            context.aset_search_value(searchValue.value)         
            props.history.push('/aop/search/query=' + searchValue.value )
         }

     }






     const [ Userprofile , setUserprofile ] = useState(null)

     const GetUserDetails = (id) => {

        Axios.get('/myaccount/users/' + id + '/' ).then(
            
            response => {
                setUserprofile(response.data)
            }

        ).catch()

     }

     if ( Axios.defaults.headers.common['Authorization'] && !Userprofile ) {
        
        GetUserDetails(context.User_id)

     }else{



     }





     const [ LoginDetails , setLoginDetails] = useState({
        email:'',
        password:''
    })

    const [ Error , setError ] = useState({
        value:false,
        msg:''
    })

    const [ Loading , setLoading ] = useState(false)

    const LoginHandlerform = (e) =>{

        setLoading(true)
        setError({
            value:false,
            msg:''
        })

        e.preventDefault()

        if ( LoginDetails.email === '' || LoginDetails.password === '' ) {
            setError({
                value:true,
                msg:'All Fileds Must Be Filled'
            })
            setLoading(false)
        }else{

            var passwordlength = LoginDetails.password.length

            var usernamelength = LoginDetails.email.length
  
  
            if( LoginDetails.password[passwordlength-1] === ' ' || LoginDetails.email[usernamelength-1] === ' ' ){
              
                setError({
                    value:true,
                    msg:'Please remove the space behind your password or username'
                })
                setLoading(false)
  
            }else{

                var senddata = {
                     username:LoginDetails.email,
                     password:LoginDetails.password
                }

                Axios.post('/myaccount/login/',senddata).then(

                    response => {
                        setLoginDetails({
                            email:'',
                            password:''
                        })
                        Savedata(response.data)
                        props.history.push('/profile')
                    }

                ).catch( (error) => {
                    setLoading(false)
                    if(error.response){
        
                        if(error.response.data.error){
                          setError({
                            value:true,
                            msg:'Invalid Username or password',

                          })
                        }
            
                    }
                } );

            }

        }

    }

    const Savedata = (response) => {
        localStorage.setItem('offspring-token',response.token)
        localStorage.setItem('offspring-userid',response.id)
        context.Loginhandler(response)
    }

















    const [ Addquestion , setAddquestion] = useState({
        title:'',
        description:'',
        img:{
            preview:null,
            image:null
        }
    })







    const AddquestionHandler = (e) => {

        e.preventDefault()

        setError({
            value:false,
            msg:''
        })
        setLoading(true)
        
        if( Addquestion.title === '' || Addquestion.description === '' ){
            setError({
                value:true,
                msg:'All Fileds Must Be Filled'
            })
            setLoading(false)
        }else{

            const Datatosubmit = new FormData();

            Datatosubmit.append('question',Addquestion.title)
            Datatosubmit.append('description',Addquestion.description)
    
            if( Addquestion.img.image && Addquestion.img.preview ){

                Datatosubmit.append('question_img1',Addquestion.img.image,Addquestion.img.image.name)

            }

            Axios.post('/aops/question/',Datatosubmit).then(

                response => {

                    setError({
                        value:false,
                        msg:''
                    })
                    setLoading(false)
                    setAddquestion({
                        title:'',
                        description:'',
                        img:{
                            preview:null,
                            image:null
                        }
                    })

                    props.history.push('/aop/question/' + response.data.slug + '/' + response.data.id )

                }

            ).catch(
                // e => {
                //     setError({
                //         value:true,
                //         msg:'Something Went Wrong'
                //     })
                //     setLoading(false)
                // }
            )

        }

    }




    const PickImage = (event) => {

        setError({
            value:false,
            msg:''
        })

        const [ result ] = useVerifyimg(event.target.files)

        if( result ){

            const currentfile = event.target.files[0] 
            const reader = new FileReader()
            reader.addEventListener("load",()=>{

                  setAddquestion({
                      ...Addquestion,
                      img:{
                          preview:reader.result,
                          image:currentfile
                      }
                  })

            },false)
    
            reader.readAsDataURL(currentfile)

        }else{
            setError({
                value:true,
                msg:' only jpg , jpeg , png and gif files are allowed  .... '
            })
        }

    }









    const logout = () => {
        context.Logouthandler()
        setUserprofile(null)
      }




     var leftside = <>
     
                <div className="aop_profile-img" >
                    { Userprofile ? 

                        Userprofile.pro.profile_picture ? <img src={ Userprofile.pro.profile_picture} className="aop_profile-img-pic" alt="" /> : <BsPersonFill className="aop_profile-img-ic" />

                    : <BsPersonFill className="aop_profile-img-ic" /> }
                </div>

                <div className="aop_profile-name" >
                    { Userprofile ? Userprofile.first_name + ' ' + Userprofile.last_name : 'Welcome' }
                </div>

                <div className="aop_profile-ul" >

                    <Link to="/aop" className="aop_profile-ul-link" > 
                        <BsHouse className="aop_profile-ul-link-ic" /> <div className="aop_profile-ul-link-txt" > Home </div>
                    </Link>

                    { Userprofile ? 
                        <div to="#" onClick={Opencompose} className="aop_profile-ul-link" > 
                            <BsPen className="aop_profile-ul-link-ic" /> <div className="aop_profile-ul-link-txt" > Ask A Question </div>
                        </div>
                    : null }

                    { Userprofile ? 
                        <Link to="/profile" className="aop_profile-ul-link" > 
                            <FiUser className="aop_profile-ul-link-ic" />
                            <div className="aop_profile-ul-link-txt" > My Profile </div>
                            { context.Unread_Notification_List ? 
                                
                                        context.Unread_Notification_List.length > 0 ?
                                        <div className="aop_profile-ul-link-dot" ></div>
                                        : null

                                        : null }
                        </Link>
                    : null }

                    { Userprofile ? 
                        <Link to="/aop/my_questions" className="aop_profile-ul-link" > 
                            <BsQuestionSquare className="aop_profile-ul-link-ic" /> <div className="aop_profile-ul-link-txt" > My Questions </div>
                        </Link>
                    : 
                        <Link to="/quicksignin" className="aop_profile-ul-link" > 
                            <FiUser className="aop_profile-ul-link-ic" /> <div className="aop_profile-ul-link-txt" > Sign In </div>
                        </Link>
                     }

                    <Link to="/" className="aop_profile-ul-link" > 
                        <FiShoppingBag className="aop_profile-ul-link-ic" /> <div className="aop_profile-ul-link-txt" > Store </div>
                    </Link>

                    { Userprofile ? 
                        <Link to="#" onClick={ () => logout() } className="aop_profile-ul-link" > 
                            <BiDoorOpen className="aop_profile-ul-link-ic" /> <div className="aop_profile-ul-link-txt" > Logout </div>
                        </Link>
                    : null }

                </div>

     </>
























     if ( Axios.defaults.headers.common['Authorization'] ) {
        
        var availableroute = <Switch>

            <Route path="/aop" exact component={AosHomePage} />
            <Route path="/aop/question/:slug/:id" exact component={QuestionDetailPage} />
            <Route path="/aop/search/query=:query" exact component={AosSearchPage} /> 
            <Route path="/aop/my_questions" exact component={MyQuestionsPage} />
            <Route path="/aop/my_questions/edit/:slug/:id" exact component={EditQuestions} />

        </Switch>

     }else{
        availableroute = <Switch>

                            <Route path="/aop" exact component={AosHomePage} />
                            <Route path="/aop/question/:slug/:id" exact component={QuestionDetailPage} />
                            <Route path="/aop/search/query=:query" exact component={AosSearchPage} /> 
                            <Route path="/aop/my_questions" exact component={AosHomePage} /> 
                            <Route path="/aop/my_questions/edit/:slug/:id" exact component={AosHomePage} />

                        </Switch>
     }




     const responseGoogle = (response) => {
        console.log(response);  


        Axios.post('/myaccount/google1/',{token:response.profileObj.tokenId}).then(
            response => {

            }
        )

    }


























      return ( 

        <div className="aop_body" >

            <AopHeader
                searchvalue={ searchValue.value}
                onChangesearchvalue={ (event) => setsearchValue({value:event.target.value}) }
                search={searchHandler}
                openit={OpenProfile}
            />

            <div className="aop_backdrop" style={{
                display: openSlider.profile || openSlider.compose ? 'block' : 'none' 
            }} onClick={ () => setopenSlider({profile:false,compose:false}) } ></div>

            <div className="aop_profile" style={{
                transform: openSlider.profile ? 'translateX(0)' : 'translateX(-50rem)' 
            }} >

                {leftside}

            </div>


            <div className="aop_profile">

                {leftside}

            </div>

            


            <div className="aop_comp" >
                {availableroute}
            </div>


            <div className="aop_compose" style={{
                transform: openSlider.compose ? 'translateX(0)' : 'translateX(80rem)' 
            }} >
                { Axios.defaults.headers.common['Authorization'] ?
                
                <AopCompose
                    title_onChange={ (event) => setAddquestion({...Addquestion,title:event.target.value}) }
                    title_value={ Addquestion.title }
                    desc_onChange={ (event) => setAddquestion({...Addquestion,description:event.target.value}) }
                    desc_value={Addquestion.description}
                    submit={AddquestionHandler}
                    error={Error.value}
                    msg={ Error.msg }
                    image={ Addquestion.img.preview }
                    remove_img={ () => setAddquestion({
                        ...Addquestion,
                        img:{
                            preview:null,
                            image:null
                        }
                    }) }
                    image_change={ (event) => PickImage(event) }
                    disabled={Loading}
                    btn_value={ Loading ? <BtnSpin bgColor="white" /> : 'Ask Question' }
                /> :
                
                <AopLeftSignIn
                    submit={LoginHandlerform}
                    error={ Error.value }
                    responseGoogle={responseGoogle}
                    msg={ Error.msg }
                    disabled={ Loading }
                    email_value={LoginDetails.email}
                    emailonChange={ (event) => setLoginDetails({...LoginDetails,email:event.target.value}) }
                    password_value={ LoginDetails.password }
                    passwordonChange={ (event) => setLoginDetails({...LoginDetails,password:event.target.value}) }
                /> }  


            </div>

            <div className="aop_body-back" onClick={ () => props.history.goBack() } >
                <BiArrowBack className="aop_body-back-ic" />
            </div>

            <div className="footer-div-sticky" >

<FooterStickyLink 
    to="/"
    icon={
        <AiFillHome className="footer-div-sticky-link-a-ic"/>
    }
    txt="Home"
/>

<FooterStickyLink
    icon={
        <AiFillQuestionCircle className="footer-div-sticky-link-a-ic"/>
    }
    to="/aop"
    txt="Aop"
/>

<FooterStickyLink
    icon={
        <GiWallet className="footer-div-sticky-link-a-ic"/>
    }
    to="/referal"
    txt="Wallet"
/>

<FooterStickyLink
    icon={
        <FaUser className="footer-div-sticky-link-a-ic"/>
    }
    to="/profile"
    txt="Profile"
    other={ context.Unread_Notification_List ? 
                        
        context.Unread_Notification_List.length > 0 ?
            <div className="footer-div-sticky-link-a-dot" ></div>
        : null

        : null }
/>

</div>

        </div>

      );

}

export default AopLayoutPage;