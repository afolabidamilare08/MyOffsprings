import React,{useState,useContext,useEffect} from 'react';
import MainHeader from '../layout_components/main_header/main_header';
import { Switch , Route } from 'react-router-dom';
import ProductDetailPage from '../e_pages/product_detail_page/product_detail_page';
import Store from '../store/managementstore/managementstore';
import Footerdiv from '../layout_components/footer/footer';
import {BiArrowBack} from 'react-icons/bi';

const ProductLayoutPage = (props) => {

    const context = useContext(Store)

    useEffect( () => {

        setsearchValue({
            value:context.Search_Value
        })

    } , [context.Search_Value] )

     const [ searchValue , setsearchValue ] = useState({
         value:''
     })

     const searchHandler = (e) => {
         e.preventDefault()
        
         if ( searchValue.value !== '' ) {
            context.set_search_value(searchValue.value)         
            props.history.push('/products/search/query=' + searchValue.value )
         }

     }


        var availableroute = <Switch>
            <Route path="/product/:slug/:id" exact component={ProductDetailPage} />
        </Switch>

      return ( 

        <div className="main_body" >

            <MainHeader
                searchvalue={ searchValue.value}
                onChangesearchvalue={ (event) => setsearchValue({value:event.target.value}) }
                search={searchHandler}
            />

            {availableroute}

            <div className="main_body-back" onClick={ () => props.history.goBack() } >
                <BiArrowBack className="main_body-back-ic" />
            </div>

            <Footerdiv
                showlinks
            />

        </div>

      );

}

export default ProductLayoutPage;