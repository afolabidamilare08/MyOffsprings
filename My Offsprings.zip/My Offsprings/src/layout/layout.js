import React,{useState,useContext,useEffect} from 'react';
import Axios from 'axios';
import MainHeader from '../layout_components/main_header/main_header';
import { Switch , Route } from 'react-router-dom/cjs/react-router-dom.min';
// import IndexPage from '../e_pages/home/home';
import IndexMorePage from '../e_pages/home/home_more';
import LoginPage from '../e_pages/login_page/login_page';
import QuickLoginPage from '../e_pages/login_page/quick_login_page';
import RegisterPage from '../e_pages/register_page/register_page';
import ResetPage from '../e_pages/reset_password/reset_password';
import ChangePasswordPage from '../e_pages/reset_password/reset_password';
import EditProfile from '../e_pages/editprofile/editprofile';
import ReferalPage from '../e_pages/referal/referal';
import ReferRegister from '../e_pages/refer_register/refer_register';
import OrderListPage from '../e_pages/order_page/order_list_page';
import CartPage from '../e_pages/cart_page/cart_page';
import RegisterSupplierPage from '../e_pages/register_supplier/register_supplier';
import ProductDetailPage from '../e_pages/product_detail_page/product_detail_page';
import ProductPostingPage from '../e_pages/edit_sell_product/selling_product';
import RegisterSupplierPageFinal from '../e_pages/register_supplier_final/register_supplier_final';
import Store from '../store/managementstore/managementstore';
import SearchPage from '../e_pages/home/search/search';
import SearchMorePage from '../e_pages/home/search/Search_more';
import CategoryPage from '../e_pages/home/category/category';
import CategoryMorePage from '../e_pages/home/category/category_more';
import Footerdiv from '../layout_components/footer/footer';
import {BiArrowBack} from 'react-icons/bi';
import PreOrderPage from '../e_pages/preorder/preorder';
import IndexHome from '../e_pages/Index_folder/indexfile';
import RealCategory from '../e_pages/RealCategory/realcategory';

const LayoutPage = (props) => {

    const context = useContext(Store)

    useEffect( () => {

        setsearchValue({
            value:context.Search_Value
        })

    } , [context.Search_Value] )

     const [ searchValue , setsearchValue ] = useState({
         value:''
     })

     const searchHandler = (e) => {
         e.preventDefault()
        
         if ( searchValue.value !== '' ) {
            context.set_search_value(searchValue.value)         
            props.history.push('/products/search/query=' + searchValue.value )
         }

     }

     if ( Axios.defaults.headers.common['Authorization'] ) {
        
        var availableroute = <Switch>

            <Route path="/" exact component={IndexHome} />
            <Route path="/products/categories/category=:category" exact component={CategoryPage} /> 
            <Route path="/products/categories/category_more=:category/:offset" exact component={CategoryMorePage} /> 
            <Route path="/products/search/query=:query" exact component={SearchPage} /> 
            <Route path="/products/search/query=:query/:offset" exact component={SearchMorePage} /> 
            <Route path="/products/r_categories/:category/:id" exact component={RealCategory} /> 
            <Route path="/products/:offset" exact component={IndexMorePage} />
            <Route path="/signin" exact component={IndexHome} />
            <Route path="/quicksignin" exact component={QuickLoginPage} />
            <Route path="/signup" exact component={IndexHome} />
            <Route path="/reset_password" exact component={IndexHome} />
            <Route path="/change_password/1234" exact component={IndexHome} />
            <Route path="/edit_profile" exact component={EditProfile} />
            <Route path="/profile" exact component={ IndexHome } />
            <Route path="/referal" exact component={ReferalPage} />
            <Route path="/referid:id" exact component={ReferRegister} />
            <Route path="/my_orders" exact component={OrderListPage} />
            <Route path="/my_cart" exact component={CartPage} />
            <Route path="/register_as_supplier" exact component={RegisterSupplierPage} />
            <Route path="/product/:slug/:id" exact component={ProductDetailPage} />
            <Route path="/sell_is_product" exact component={ProductPostingPage} />
            <Route path="/final_supplier" exact component={RegisterSupplierPageFinal} />
            <Route path="/preorder" exact component={PreOrderPage} />
            {/* <Route component={IndexHome} /> */}
        </Switch>

     }else{
        availableroute = <Switch>
                <Route path="/" exact component={IndexHome} />
                <Route path="/signin" exact component={LoginPage} />
                <Route path="/quicksignin" exact component={QuickLoginPage} />
                <Route path="/signup" exact component={RegisterPage} />
                <Route path="/products/categories/category=:category" exact component={CategoryPage} /> 
                <Route path="/products/categories/category_more=:category/:offset" exact component={CategoryMorePage} /> 
                <Route path="/products/search/query=:query" exact component={SearchPage} /> 
                <Route path="/products/search/query=:query/:offset" exact component={SearchMorePage} /> 
                <Route path="/products/r_categories/:category/:id" exact component={RealCategory} /> 
                <Route path="/products/:offset" exact component={IndexMorePage} />
                <Route path="/reset_password" exact component={ResetPage} />
                <Route path="/change_password/1234" exact component={ChangePasswordPage} />
                <Route path="/edit_profile" exact component={LoginPage} />
                <Route path="/profile" exact component={ LoginPage } />
                <Route path="/referal" exact component={LoginPage} />
                <Route path="/referid:id" exact component={ReferRegister} />
                <Route path="/my_orders" exact component={LoginPage} />
                <Route path="/my_cart" exact component={LoginPage} />
                <Route path="/register_as_supplier" exact component={RegisterSupplierPage} />
                <Route path="/product/:slug/:id" exact component={ProductDetailPage} />
                <Route path="/sell_is_product" exact component={ProductPostingPage} />
                <Route path="/final_supplier" exact component={RegisterSupplierPageFinal} />
                <Route path="/preorder" exact component={PreOrderPage} />
            {/* <Route component={IndexHome} /> */}

            </Switch> 
     }

      return ( 

        <div className="main_body" >

            <MainHeader
                searchvalue={ searchValue.value}
                onChangesearchvalue={ (event) => setsearchValue({value:event.target.value}) }
                search={searchHandler}
            />

            {availableroute}

            <div className="main_body-back" onClick={ () => props.history.goBack() } >
                <BiArrowBack className="main_body-back-ic" />
            </div>

            <Footerdiv/>

        </div>

      );

}

export default LayoutPage;