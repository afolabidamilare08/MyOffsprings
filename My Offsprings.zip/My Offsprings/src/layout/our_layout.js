import React,{useState,useContext,useEffect} from 'react';
import Axios from 'axios';
import MainHeader from '../layout_components/main_header/main_header';
import { Switch , Route } from 'react-router-dom/cjs/react-router-dom.min';
import IndexPage from '../e_pages/home/home';
import LoginPage from '../e_pages/login_page/login_page';
import ProductEditPage from '../e_pages/edit_sell_product/edit_product';
import Store from '../store/managementstore/managementstore';
import Footerdiv from '../layout_components/footer/footer';
import OurIndexPage from '../e_pages/our_product/home';
import OurSearchPage from '../e_pages/our_product/search/search';
import OurSearchMorePage from '../e_pages/our_product/search/Search_more';
import OurIndexMorePage from '../e_pages/our_product/home_more';
import {BiArrowBack} from 'react-icons/bi';
import OurCategoryPage from '../e_pages/our_product/category/category';
import OurCategoryMorePage from '../e_pages/our_product/category/category_more';
import NewSupplier from '../e_pages/our_product/new_supplier';
import RSupplier from '../e_pages/our_product/rsupplier copy';

const OurLayoutPage = (props) => {

    const context = useContext(Store)

    useEffect( () => {

        setsearchValue({
            value:context.Search_Value
        })

    } , [context.Search_Value] )

     const [ searchValue , setsearchValue ] = useState({
         value:''
     })

     const searchHandler = (e) => {
         e.preventDefault()
        
         if ( searchValue.value !== '' ) {
            context.set_search_value(searchValue.value)         
            props.history.push('/ourproducts/products/search/query=' + searchValue.value )
         }

     }

     if ( Axios.defaults.headers.common['Authorization'] ) {
        
        var availableroute = <Switch>

            <Route path="/" exact component={IndexPage} />
            <Route path="/ourproducts" exact component={OurIndexPage} />
            <Route path="/ourproducts/products/search/query=:query" exact component={OurSearchPage} /> 
            <Route path="/ourproducts/products/search/query=:query/:offset" exact component={OurSearchMorePage} /> 
            <Route path="/ourproducts/products/:offset" exact component={OurIndexMorePage} />
            <Route path="/editproduct/:slug/:id" exact component={ProductEditPage} />
            <Route path="/ourproducts/categories/category=:category" exact component={OurCategoryPage} /> 
            <Route path="/ourproducts/categories/category_more=:category/:offset" exact component={OurCategoryMorePage} /> 
            <Route path="/new_supplier" exact component={NewSupplier} /> 
            <Route path="/reg_supplier" exact component={RSupplier} /> 
        </Switch>

     }else{
        availableroute = <Switch>
            <Route path="/" exact component={IndexPage} />
            <Route path="/ourproducts" exact component={LoginPage} />
            <Route path="/ourproducts/products/search/query=:query" exact component={LoginPage} /> 
            <Route path="/ourproducts/products/search/query=:query/:offset" exact component={LoginPage} /> 
            <Route path="/ourproducts/products/:offset" exact component={LoginPage} />
            <Route path="/editproduct/:slug/:id" exact component={LoginPage} />
            <Route path="/ourproducts/categories/category=:category" exact component={LoginPage} /> 
            <Route path="/ourproducts/categories/category_more=:category/:offset" exact component={LoginPage} /> 
            <Route path="/reg_supplier" exact component={LoginPage} /> 
            <Route path="/new_supplier" exact component={LoginPage} /> 
        </Switch> 
     }

      return ( 

        <div className="main_body" >

            <MainHeader
                searchvalue={ searchValue.value}
                onChangesearchvalue={ (event) => setsearchValue({value:event.target.value}) }
                search={searchHandler}
                our
            />

            {availableroute}

            <div className="main_body-back" onClick={ () => props.history.goBack() } >
                <BiArrowBack className="main_body-back-ic" />
            </div>

            <Footerdiv/>

        </div>

      );

}

export default OurLayoutPage;