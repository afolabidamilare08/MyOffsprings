import React,{useState,useEffect} from 'react';
import QuestionList from '../../component/questionlist/question_list';
import Axios from 'axios';
import LoadingPage from '../../component/utilities/loading/loading';
import OppsPage from '../../component/utilities/oppspage/oppspage';
import InfiniteScroll from 'react-infinite-scroll-component';
import BtnSpin from '../../component/utilities/btnSpin/btnSpin';
import { EmptyQuestion } from '../../component/utilities/empty/no_product';

const AosHomePage = (props) => {


      const [ Errorpage , setErrorpage ] = useState(false)
      const [ Loading , setLoading ] = useState(false)
      const [ Question , setQuestion ] = useState({
        Questions:null,
        count:10,
        // previous:null,
        // next:null,
        // offset:2,
        limit:4
      })

      useEffect( () => {

        setErrorpage(false)
        setLoading(true)

        Axios.get( '/aops/question/?limit=1111&offset=0' ).then(
          
            response => {

              setQuestion({
                Questions:response.data.results,
                count:response.data.count,
                previous:response.data.previous,
                next:response.data.next,
                offset:2,
                limit:24
              })
              setErrorpage(false)
              setLoading(false)

            }

          ).catch(

            e => {
              setErrorpage(true)
              setLoading(false)
            }

          )

      } , [] )

      useEffect( () => {
        console.log(Question,'useffect')
      },[Question] )

      const GetMore = () => {

        Axios.get( '/aops/question/?limit=' + Question.limit + '&offset=0' ).then(

          response => { 

            setQuestion({
              Questions:response.data.results,
              count:response.data.count,
              // previous:response.data.previous,
              // next:response.data.next,
              // offset: 0,
              limit: parseInt(Question.limit) + 24
            })
            setErrorpage(false)
            setLoading(false)
          }

        ).catch(

          // e => {
          //   setErrorpage(true)
          //   setLoading(false)
          // }

        )

      }



      if( !Question.Questions && Loading && !Errorpage ){
        var whattoshow = <LoadingPage/>
      }else{
        if ( !Question.Questions && !Loading && Errorpage ) {
          whattoshow = <OppsPage/>
        }else{
          if ( Question.Questions && !Loading && !Errorpage ) {
            whattoshow = <>

                              { Question.Questions.length > 0 ? 
                              
                              <InfiniteScroll
                              dataLength={Question.count}
                              next={GetMore}
                              hasMore={true}
                              loader={ <BtnSpin bgColor='white' /> }
                            >
                                  { Question.Questions.map( ( question , index ) => {
                                      return <QuestionList 
                                                title={question.question}
                                                key={index}
                                                img={ question.user.pro.profile_picture }
                                                first_name={ question.user.first_name }
                                                last_name={ question.user.last_name }
                                                time={ question.time_since }
                                                desc={question.description}
                                                status={question.solved}
                                                react={question.answers.length}
                                                to={ '/aop/question/' + question.slug + '/' + question.id }
                                      />
                                    } )  }
                                    
                            </InfiniteScroll>

                            : <EmptyQuestion/> }

                          </>
          }
      }
    }




      return ( 
          <> {whattoshow} </>
      );

}

export default AosHomePage;