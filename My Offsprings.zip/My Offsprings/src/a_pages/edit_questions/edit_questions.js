import React,{useState,useEffect} from 'react';
import TopbannerDiv from '../../component/top-banner-msg/topbannermsg';
import Axios from 'axios';
import LoadingPage from '../../component/utilities/loading/loading';
import OppsPage from '../../component/utilities/oppspage/oppspage';
import BtnSpin from '../../component/utilities/btnSpin/btnSpin';
// import {RiDeleteBin6Line} from 'react-icons/ri';
import {BiImageAdd} from 'react-icons/bi';
import { useVerifyimg } from '../../component/utilities/checkingforletter';




const EditQuestions = (props) => {

    const Qid = props.match.params.id
    // const Qslug = props

    const [ Errorpage , setErrorpage ] = useState(false)
    const [ Loading , setLoading ] = useState(false)
    const [ btn , setbtn ] = useState(false)
    const [ Question , setQuestion ] = useState({
        getit:null,
        question:'',
        description:'',
        img:{
            preview:null,
            img:null
        }
    })

    const [ Msg , setMsg ] = useState({
        bg:'',
        msg:'',
        value:false
      })


    
    useEffect( () => {

        setErrorpage(false)
        setLoading(true)

        Axios.get('/aops/question/' + Qid + '/').then(

            response => {
                setQuestion({
                    getit:true,
                    question:response.data.question,
                    description:response.data.description,
                    img:{
                        preview:response.data.question_img1,
                        img:null
                    }
                })

                setErrorpage(false)
                setLoading(false)
            }

        ).catch(

            e => {
                setErrorpage(false)
                setLoading(false)        
            }

        )


    },[Qid] )





    const SelectImageHandler = (event) => {

        setMsg({
            ...Msg,
            value:false,
            msg:'',
            bg:''
        })

        const [ result ] = useVerifyimg(event.target.files)

        if( result ){

            const currentfile = event.target.files[0] 
            const reader = new FileReader()
            reader.addEventListener("load",()=>{

                  setQuestion({
                      ...Question,
                      img:{
                          preview:reader.result,
                          img:currentfile
                      }
                  })

            },false)
    
            reader.readAsDataURL(currentfile)

        }else{
            setMsg({
                ...Msg,
                value:true,
                msg:' only jpg , jpeg , png and gif files are allowed  .... ',
                bg:'red'
            })
        }


    }





    const SaveQuesionHandler = (e) => {

        e.preventDefault()

        setMsg({
            bg:'orange',
            msg:'Updating Question',
            value:true
        })
        setbtn(true)

        if( Question.question !== '' && 
            Question.description !== '' ){
            


                if( Question.img.img ){
                    const Datatosubmit = new FormData();

                    Datatosubmit.append('question',Question.question)
                    Datatosubmit.append('description',Question.description)
    
                    Datatosubmit.append('question_img1',Question.img.img,Question.img.img.name)
                }

                if( !Question.img.img && !Question.img.preview ){
                    var Datatosubmit = {
                        question:Question.question,
                        description:Question.description,
                        // question_img1:''
                    }
                }

                Axios.patch( '/aops/question/' + Qid + '/' , Datatosubmit ).then(

                    response => {

                        setMsg({
                            bg:'rgb(39, 180, 39)',
                            msg:'Changes Was Successfully Saved',
                            value:true
                        })

                        setbtn(false)

                    }

                ).catch(

                    e => {
                        setMsg({
                            bg:'red',
                            msg:'Something Went Wrong',
                            value:true
                        })
                        setbtn(false)
                    }

                )

        }else{

            setMsg({
                bg:'red',
                msg:'All Fileds Should Be Filled',
                value:true
            })       
            setbtn(false)


        }

    }



















    const gogo = () => {
        props.history.go()
      } 
    
      const goBack = () => {
        props.history.goBack()
      }
    




      if( !Question.getit && Loading && !Errorpage ){
        var whattoshow = <LoadingPage/>
      }else{
        if ( !Question.getit && !Loading && Errorpage ) {
          whattoshow = <OppsPage  tryagain={gogo} goback={goBack}  />
        }else{
          if ( Question.getit && !Loading && !Errorpage ) {
            whattoshow = <>

                                <TopbannerDiv
                                    backgroundcolor={Msg.bg} 
                                    show={Msg.value}
                                    message={Msg.msg}
                                    closeshow={ () => setMsg({...Msg,value:false}) }
                                />

                                <div className="edit_question-page" onSubmit={SaveQuesionHandler} >

                                    <form className="edit_question-page_form" >

                                        <div className="edit_question-page_form-div" >
                                            <label className="edit_question-page_form-div-label" > Question Title </label>
                                            <input type="text" className="edit_question-page_form-div-input" value={Question.question} onChange={ (event) => setQuestion({...Question,question:event.target.value}) } />
                                        </div>

                                        <div className="edit_question-page_form-div" >
                                            <label className="edit_question-page_form-div-label" > Question Description </label>
                                            <textarea className="edit_question-page_form-div-textarea" value={Question.description} onChange={ (event) => setQuestion({...Question,description:event.target.value}) } />
                                        </div>
                                        
                                        <div className="edit_question-page_form-ext" >

                                            <div className="edit_question-page_form-ext-div" > Question Image </div>
                                            <div className="edit_question-page_form-ext-txt" > 
                                                You can add an image if your question requires an image
                                            </div>

                                            <div style={{width:'fit-content'}} >
                                                <label for="img" className="edit_question-page_form-ext-img" >
                                                    
                                                    { Question.img.preview ? 
                                                        <img className="edit_question-page_form-ext-img-img" src={Question.img.preview} alt="" />
                                                    : <BiImageAdd className="edit_question-page_form-ext-img-ic" /> }

                                                </label>

                                                <input type="file" onChange={SelectImageHandler} style={{display:'none'}} id="img" />

                                                {/* { Question.img.preview ? 
                                                
                                                <div onClick={ () => setQuestion({...Question,img:{preview:null,img:null}}) } className="edit_question-page_form-ext-btn" > <RiDeleteBin6Line className="edit_question-page_form-ext-btn-ic" /> </div>

                                                : null  } */}
                                                
                                            </div>


                                        </div>

                                        <div className="edit_question-page_form-sbt" >
                                            <button className="edit_question-page_form-sbt-btn" disabled={btn} >
                                                { btn ? <BtnSpin bgColor="white" /> : 'Save Changes' }
                                            </button>
                                        </div>

                                    </form>

                                </div>

                          </>
          }
      }
    }




      return ( 

        <>
            {whattoshow}
        </>

      );

}

export default EditQuestions;