import React from 'react';
import {LoginBtn} from '../../component/login_components/login_components';
import {AiOutlinePlus,AiFillStar,AiOutlineStar,AiFillLike} from 'react-icons/ai';
import {TiArrowForwardOutline} from 'react-icons/ti';
import { Link } from 'react-router-dom';
import {BsPersonFill} from 'react-icons/bs';


const url = ''


export const QuestionereQuestion = (props) => {

    return (

        <div className="questionere_question" >

            <div className="questionere_question-date" > {props.date} </div>

            <div className="questionere_question-title" > {props.title} </div>
             
             <div className="questionere_question-story" >
                {props.desc}
             </div>

            {props.img ? 
                <div className="questionere_question-img" >
                    <img className="questionere_question-img-img" src={props.img} alt="" />
                </div>
            :null        
            }

            <div className="Question_reply_section" >

                {props.allQreply}

            </div>

            <div className="Question_answer_section" >
                 
                 <div className="Question_answer_section_top" > All Answers ({props.ans_length}) </div>
                
                 {props.all_answers}

            </div>

        </div>

    );

}





export const QuestionComposeAnswer = (props) => {

    return (

        <div className="product_compose_comment" style={{

            transform: !props.show ? "translateX(50rem)" : "translateX(0)"

        }} >

            <div className="product_compose_comment-top" >

                <div className="product_compose_comment-top_title" >
                    Answer Question
                </div>

                <AiOutlinePlus className="addtocart-div_top-cancel" onClick={props.close} />

            </div>

            <div className="product_compose_comment-top-msg" style={{ display: props.comdisplay,color:props.comcolor }} >
                {props.msg}
            </div>

            <form className="product_compose_comment-form" onSubmit={props.post_answer} >

                <textarea className="product_compose_comment-form-text" value={props.answer} onChange={props.onChange} placeholder="Give A Possible Answer To The Question" ></textarea>

                <LoginBtn value={props.sbt} disabled={props.disabled} />

            </form>

        </div>

    );

}




export const ReplyQuestionDiv = (props) => {

    return (

        <div className="product_compose_comment" style={{

            transform: !props.show ? "translateX(50rem)" : "translateX(0)"

        }} >

            <div className="product_compose_comment-top" >

                <div className="product_compose_comment-top_title" >
                    Reply Question
                </div>

                <AiOutlinePlus className="addtocart-div_top-cancel" onClick={props.close} />

            </div>

            <div className="product_compose_comment-top-msg" style={{ display: props.comdisplay,color:props.comcolor }} >
                {props.msg}
            </div>

            <form className="product_compose_comment-form" onSubmit={props.post_answer} >

                <textarea className="product_compose_comment-form-text" value={props.answer} onChange={props.onChange} placeholder="Give A Reply To The Question" ></textarea>

                <LoginBtn value={props.sbt} disabled={props.disabled} />

            </form>

        </div>

    );

}






export const AnswerReplydiv = (props) => {

    return (

        <div className="product_compose_reply" style={{

            transform: !props.show ? "translateY(80rem)" : "translateY(0)"

        }} >

            <div className="product_compose_reply-top" >

                <div className="product_compose_reply-top_title" >
                    Reply To Answer
                </div>

                <AiOutlinePlus className="addtocart-div_top-cancel" onClick={props.close} />

            </div>

            {props.commentToreply}

            <form className="product_compose_reply-form" onSubmit={props.post_reply} >

                <textarea className="product_compose_reply-form-text" placeholder=" Comment On Answer " value={props.reply} onChange={props.onChange} ></textarea>

                <LoginBtn value={props.sbt} disabled={props.disabled} />

            </form>

        </div>

    );

}



export const RateAnswerDiv = (props) => {

    return (

        <div className="product_compose_reply" style={{

            transform: !props.show ? "translateY(80rem)" : "translateY(0)"

        }} >

            <div className="product_compose_reply-top" >

                <div className="product_compose_reply-top_title" >
                    Rate Answer
                </div>

                <AiOutlinePlus className="addtocart-div_top-cancel" onClick={props.close} />

            </div>

            {props.commentToreply}

            <form className="product_compose_reply-form" onSubmit={props.post_reply} >

                {props.allstars}

                <LoginBtn value={props.sbt} disabled={props.disabled} />

            </form>

        </div>

    );

}


export const ReplyAnswerDiv = (props) => {

    return (

        <div className="reply_div" >

            <div className="reply_div-top" >

                <div className="reply_div-top_img" >
                    { props.img ? <img src={ url + props.img} alt="" className="comment_div-top_img-pic" /> : <BsPersonFill className="comment_div-top_img-ic" /> }
                </div>

                <div className="reply_div-top_name" >
                    <span className="reply_div-top_name-top" > {props.name} </span>
                    <br/>
                    <span className="reply_div-top_name-btm" > {props.date} </span>
                </div>

            </div>

            <div className="reply_div-body" >
                {props.reply}
            </div>

        </div>

    );

}




export const AnswerDiv = (props) => {

    return (

        <div className="comment_div" >

            <div className="comment_div-top" >

                <div className="comment_div-top_img" >
                    { props.img ? <img src={ url + props.img} alt="" className="comment_div-top_img-pic" /> : <BsPersonFill className="comment_div-top_img-ic" /> }
                </div>

                <div className="comment_div-top_name" >
                    <span className="comment_div-top_name-top" > {props.name} </span>
                        <br/>
                    <span className="comment_div-top_name-btm" > {props.date} </span>
                    <br/>

                    <div className="comment_div-top_stars" >
                    
                        { props.avg_rating > 0 ?  

                            <AiFillStar className="product_list-dec-rat-ic" />

                            : <AiOutlineStar className="product_list-dec-rat-ic" /> 

                            }

                            { props.avg_rating > 1 ? 

                            <AiFillStar className="product_list-dec-rat-ic" />

                            : <AiOutlineStar className="product_list-dec-rat-ic" /> 

                            }

                            { props.avg_rating > 2 ? 

                            <AiFillStar className="product_list-dec-rat-ic" />

                            : <AiOutlineStar className="product_list-dec-rat-ic" /> 

                            }

                            { props.avg_rating > 3 ? 

                            <AiFillStar className="product_list-dec-rat-ic" />

                            : <AiOutlineStar className="product_list-dec-rat-ic" /> 

                            }

                            { props.avg_rating > 4 ? 

                            <AiFillStar className="product_list-dec-rat-ic" />

                            : <AiOutlineStar className="product_list-dec-rat-ic" /> 

                            }

                    </div>
                    
                </div>

            </div>

            <div className="comment_div-body" >
                {props.comment}
            </div>

            <div style={{
                display: 'flex'
            }} >
                
                <Link to="#" className="comment_div-text" onClick={props.open_reply_box} > Reply To Answer <TiArrowForwardOutline className="comment_div-text-ic" /> </Link>

                { props.AproveAnswer ? 
                    <Link to="#" className="comment_div-text" onClick={props.AproveAnswer} > Approve Answer <AiFillLike className="comment_div-text-ic" /> </Link>
                  : null  }

                <div className="comment_div-text2" style={{color:'orange',cursor:'pointer'}} onClick={props.rateans} > Rate Answer </div>


            </div>

            <div className="comment_div-reply" >

                {props.reply_list}

            </div>

        </div>

    );

}




export const AnswertobeReplied = (props) => {

    return (

        <div className="compose_reply_reply" >

            <div className="compose_reply_reply-top" >

                <div className="compose_reply_reply-top_img" >
                    { props.img ? <img src={ url + props.img} alt="" className="compose_reply_reply-top_img-pic" /> : <BsPersonFill className="compose_reply_reply-top_img-ic" /> }
                </div>

                <div className="compose_reply_reply-top_name" >
                    <span className="compose_reply_reply-top_name-top" > {props.name} </span>
                    <br/>
                    <span className="compose_reply_reply-top_name-btm" > {props.date} </span>
                </div>

            </div>

            <div className="product_compose_comment-top-msg" style={{ display: props.comdisplay,color:props.comcolor,padding:'1rem',textAlign:'center' }} >
                {props.msg}
            </div>

            <div className="compose_reply_reply-body" >
                {props.story}
            </div>

        </div>

    );

}
