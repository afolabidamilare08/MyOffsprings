import React,{useState,useEffect,useContext} from 'react';
import { AnswerReplydiv, AnswertobeReplied , QuestionereQuestion, QuestionComposeAnswer, ReplyQuestionDiv, AnswerDiv, ReplyAnswerDiv, RateAnswerDiv} from './question_detail_template';
import {BiChat} from 'react-icons/bi';
import {TiArrowBackOutline} from 'react-icons/ti';
import {AiFillStar,AiOutlineStar} from 'react-icons/ai';
import Store from '../../store/managementstore/managementstore';
import LoadingPage from '../../component/utilities/loading/loading';
import OppsPage from '../../component/utilities/oppspage/oppspage';
import Axios from 'axios';
import BtnSpin from '../../component/utilities/btnSpin/btnSpin';
import CommentImg from '../../component/utilities/img/Messaging-rafiki.png';
import TopbannerDiv from '../../component/top-banner-msg/topbannermsg';

const QuestionDetailPage = (props) => {

      
    
      const context = useContext(Store)
      const Qid = props.match.params.id
    //   const Qslug = props.match.params.slug

      const [ Question , setQuestion ] = useState(null)
      const [ Loadingpage , setLoadingpage ] = useState(false)
      const [ Errorpage , setErrorpage ] = useState(false)
      const [ open_compose_answer , set_open_compose_answer ] = useState(false)
      const [ open_compose_qreply , set_open_compose_qreply ] = useState(false)
      const [ open_compose_replyanswer , set_open_compose_replyanswer ] = useState(false)
      const [ open_compose_rateanswer , set_open_compose_rateanswer ] = useState(false)
      const [ answer_list , setanswer_list ] = useState({
        list:[],
        pag_number:3
      })
      const [ message , setmessage ] = useState({
        status:false,
        message:'',
        bgcolor:'orange'
      })

      const [ Addanswer , setAddanswer ] = useState({
        value:'',
        error:false,
        loading:false,
        msg:''
      })      

      const [ replyquestion , setreplyquestion ] = useState({
        value:'',
        error:false,
        loading:false,
        msg:''
      })

      const [ answerToreply , setanswerToreply ]=useState({
        answer:null,
        value:'',
        error:false,
        loading:false,
        msg:''
      })

      const [ answerTorate , setanswerTorate ]=useState({
        answer:null,
        value:0,
        error:false,
        loading:false,
        msg:''
      })





      useEffect( () => {

        setLoadingpage(true)
        setErrorpage(false)

        Axios.get('/aops/question/' + Qid + '/' ).then(

            response => {
                setQuestion(response.data)
                setLoadingpage(false)
                setErrorpage(false)    
                setanswer_list({...answer_list,list:response.data.answers})    
            }

        ).catch(

            e => {
                setLoadingpage(false)
                setErrorpage(true)        
            }

        )
        // eslint-disable-next-line
       } , [Qid] )




       const markasanswered = () => {

        setmessage({
          status:true,
          message:'Approving Answer...',
          bgcolor:'orange'
        })
        
        Axios.patch('/aops/question/' + Qid + '/' ,{solved:true} ).then(

          response => {
              setQuestion(response.data)
              setLoadingpage(false)
              setErrorpage(false)    
              setanswer_list({...answer_list,list:response.data.answers})    

              setmessage({
                status:true,
                message:'Answer Was Successfully Aproved',
                bgcolor:'rgb(39, 180, 39)'
              })

          }

          ).catch(

              e => {
                setmessage({
                  status:true,
                  message:'Something Went Wrong',
                  bgcolor:'red'
                })     
              }

          )
        
       }



       const Openanscompose = () => {
            set_open_compose_answer(true)
            set_open_compose_replyanswer(false)
            set_open_compose_rateanswer(false)
       }

       const Openrquecompose = () => {
        set_open_compose_answer(false)
        set_open_compose_replyanswer(false)
        set_open_compose_qreply(true)
        set_open_compose_rateanswer(false)
      }


      const Openreplyanswer = (answer) => {
        setanswerToreply({...answerToreply,answer:answer})
        set_open_compose_answer(false)
        set_open_compose_replyanswer(true)
        set_open_compose_qreply(false)
        set_open_compose_rateanswer(false)
      }

      const Openrateanswer = (answer) => {
        setanswerTorate({...answerTorate,answer:answer})
        set_open_compose_rateanswer(true)
        set_open_compose_answer(false)
        set_open_compose_replyanswer(false)
        set_open_compose_qreply(false)
      }









       const postAnswerHandler = (e) => {

        e.preventDefault()

        setAddanswer({
            ...Addanswer,
            loading:true,
            error:false
        })

        if( Addanswer.value === '' ){
            setAddanswer({
                ...Addanswer,
                loading:false,
                error:false
            })
        }else{

            Axios.post('/aops/question/' + Question.id + '/question_answer/' ,{answer:Addanswer.value}).then(




              response => {

                Axios.get('/aops/question/' + Qid + '/' ).then(

                  response => {
                      setQuestion(response.data)
                      setLoadingpage(false)
                      setErrorpage(false)    
                      setanswer_list({...answer_list,list:response.data.answers}) 
                      setAddanswer({
                        value:'',
                        loading:false,
                        error:false,
                        msg:'Answer Was Succesfully Posted'
                    })
    
                    setTimeout(() => {
                      setAddanswer({
                        value:'',
                        loading:false,
                        error:false,
                        msg:''
                    })
                    }, 2000);
                  }
      
              ).catch(
      
                  e => {
                      setLoadingpage(false)
                      setErrorpage(true)        
                  }
      
              )

              }

            ).catch(
              e => {
                setAddanswer({
                  ...Addanswer,
                  loading:false,
                  error:true,
                  msg:'Something Went Wrong'
              })
              }
            )

        }

       }



       const postQreplyHandler = (e) => {

          e.preventDefault()

          setreplyquestion({
            ...replyquestion,
            error:false,
            loading:true,
            msg:''
          })

          if( replyquestion.value !== '' ){

            Axios.post('/aops/question/' + Qid + '/question_reply/',{reply:replyquestion.value}).then(

                response => {

                  Axios.get('/aops/question/' + Qid + '/' ).then(

                    response => {
                        setQuestion(response.data)
                        setLoadingpage(false)
                        setErrorpage(false)    
                        setanswer_list({...answer_list,list:response.data.answers}) 
                        setreplyquestion({
                          ...replyquestion,
                          value:'',
                          error:false,
                          loading:false,
                          msg:'Your Reply Was Sent Successfully'
                        })
                        setTimeout(() => {
                          setreplyquestion({
                            ...replyquestion,
                            error:false,
                            loading:false,
                            msg:''
                          })
                        }, 2000);   
                    }
        
                ).catch(
        
                    e => {
                        setLoadingpage(false)
                        setErrorpage(true)        
                    }
        
                )
                  
                }

            ).catch(
              e => {
                setreplyquestion({
                  ...replyquestion,
                  error:true,
                  loading:false,
                  msg:'Something Went Wrong'
                })  
              }
            )

          }

       }




       const ReplyToAnswerHandler = (e) => {

          e.preventDefault()
          setanswerToreply({
            ...answerToreply,
            error:false,
            loading:true,
            msg:''
          })

          if ( answerToreply.value !== '' ) {

              Axios.post('/aops/answer/' + answerToreply.answer.id + '/reply_Answer/',{reply:answerToreply.value}).then(

                response => {

                  Axios.get('/aops/question/' + Qid + '/' ).then(

                    response => {
                        setQuestion(response.data)
                        setLoadingpage(false)
                        setErrorpage(false)    
                        setanswer_list({...answer_list,list:response.data.answers})
                        setanswerToreply({
                          ...answerToreply,
                          error:false,
                          loading:false,
                          msg:'Your Reply Was Successfuly Sent',
                          value:''
                        })    
                    }
        
                ).catch(
        
                    e => {
                        setLoadingpage(false)
                        setErrorpage(true)        
                    }
        
                )

                }

              ).catch(

                e => {
                  setanswerToreply({
                    ...answerToreply,
                    error:true,
                    loading:false,
                    msg:'Something Went Wrong'
                  })
                }

              )

          }

       }


       const RateAnswerHandler = (e) => {

        e.preventDefault()
        setanswerTorate({
          ...answerTorate,
          error:false,
          loading:true,
          msg:''
        })

        if ( answerTorate.value !== 0 ) {

            Axios.post('/aops/answer/' + answerTorate.answer.id + '/rate_answer/',{stars:answerTorate.value}).then(

              response => {

                Axios.get('/aops/question/' + Qid + '/' ).then(

                  response => {
                      setQuestion(response.data)
                      setLoadingpage(false)
                      setErrorpage(false)    
                      setanswer_list({...answer_list,list:response.data.answers})
                      setanswerTorate({
                        ...answerTorate,
                        error:false,
                        loading:false,
                        msg:'Answer Was Succesfully Rated',
                        value:''
                      })    
                  }
      
              ).catch(
      
                  e => {
                      setLoadingpage(false)
                      setErrorpage(true)        
                  }
      
              )

              }

            ).catch(

              e => {
                setanswerTorate({
                  ...answerTorate,
                  error:true,
                  loading:false,
                  msg:'Something Went Wrong'
                })
              }

            )

        }

     }



      const gogo = () => {
        props.history.go()
      } 
    
      const goBack = () => {
        props.history.goBack()
      }
    
    
      if( Loadingpage && !Question && !Errorpage ){
        var what_to_return = <LoadingPage/>
      }else{
        if ( !Loadingpage && Errorpage && !Question ) {
          what_to_return = <OppsPage tryagain={gogo} goback={goBack} />
        }else{
          if ( !Loadingpage && !Errorpage && Question ) {
            what_to_return = <>

                                <div className="questiondetailpage" >

                                    {/* QUESTION MODAL */}

                                    <QuestionereQuestion
                                        date={Question.time_since}
                                        title={Question.question}
                                        desc={Question.description}
                                        img={Question.question_img1}
                                        ans_length={answer_list.list.length}

                                        allQreply={

                                          <>

                                            { Question.qreply.length > 0 ?
                                            
                                                  Question.qreply.map( (reply,index) => {
                                                          return <ReplyAnswerDiv
                                                          key={index}
                                                          img={ reply.user.pro.profile_picture }
                                                          name={ reply.user.first_name + ' ' + reply.user.last_name }
                                                          date={ reply.time_since }
                                                          reply={ reply.reply }
                                                      /> 
                                                  } )

                                            : null }

                                          </>

                                        }

                                        all_answers={

                                            <>

                                              { answer_list.list.length > 0 ?  
                                                
                                                  answer_list.list.map( ( answer , index ) => {

                                                    return <AnswerDiv
                                                                key={index}
                                                                comment={answer.answer} 
                                                                name={ answer.user.first_name + ' ' + answer.user.last_name }
                                                                date={ answer.time_since }
                                                                img={ answer.user.pro.profile_picture }
                                                                avg_rating={ answer.avg_rating }
                                                                rateans={ !context.User_token && !context.User_id ? () => props.history.push('/quicksignin') : () => Openrateanswer(answer) }
                                                                AproveAnswer={ parseInt(context.User_id) === parseInt(Question.user.id) ?
                                                                
                                                                  Question.solved ? false : markasanswered
                                                                
                                                                  : null }
                                                                open_reply_box={ !context.User_token && !context.User_id ? () => props.history.push('/quicksignin') : () => Openreplyanswer(answer) }
                                                                reply_list={

                                                                  <>

                                                                      { answer.areply.map( ( reply , index ) => {

                                                                        return <ReplyAnswerDiv
                                                                                    key={index}
                                                                                    img={ reply.user.pro.profile_picture }
                                                                                    name={ reply.user.first_name + ' ' + reply.user.last_name }
                                                                                    date={ reply.time_since }
                                                                                    reply={ reply.reply }
                                                                                />

                                                                      } ) }

                                                                  </>

                                                                }

                                                                // stars={



                                                                // }

                                                            />

                                                  } )

                                              :   <div className="no-comment-div" >

                                                    <img className="no-comment-div-img" src={CommentImg} alt="" />
                  
                                                    <div className="no-comment-div-txt" > Be The First To Leave An Answer </div>
                  
                                                    <button className="no-comment-div-btn" onClick={!context.User_token && !context.User_id ? () => props.history.push('/quicksignin') : Openanscompose } >
                                                        Answer The Question
                                                    </button>
                  
                                                  </div> 
                                                 }

                                            </>

                                        }
                                    />

                                </div>





                                    {/* ANSWER QUESTION MODAL */}

                                    <QuestionComposeAnswer
                                        show={open_compose_answer}
                                        close={ () => set_open_compose_answer(false) }
                                        msg={ Addanswer.msg }
                                        comdisplay={ Addanswer.error || Addanswer.msg !== '' ? 'block' : 'none' }
                                        comcolor={ Addanswer.error ? 'tomato' : 'green' }
                                        post_answer={ postAnswerHandler }
                                        answer={ Addanswer.value }
                                        onChange={ (event) => setAddanswer({...Addanswer,value:event.target.value}) }
                                        sbt={ Addanswer.loading ? <BtnSpin bgColor="white" /> : 'Answer Question' }
                                    />









                                  {/* RATE ANSWER DIV */}

                                      
                                      <RateAnswerDiv
                                        show={open_compose_rateanswer}
                                        close={ () => set_open_compose_rateanswer(false) }
                                        commentToreply={ 
                    
                                          answerTorate.answer ? 
                                          
                                            <AnswertobeReplied
                                              story={answerTorate.answer.answer}
                                              img={ answerTorate.answer.user.pro.profile_picture }
                                              name={ answerTorate.answer.user.first_name + ' ' + answerTorate.answer.user.last_name }
                                              date={ answerTorate.answer.time_since }
                                              msg={ answerTorate.msg }
                                              comdisplay={ answerTorate.msg !== '' ? 'block' : 'none' }
                                              comcolor={ answerTorate.msg !== '' && !answerTorate.error ? 'green' : 'tomato' }     
                                            />
                      
                                          : null
                      
                                          }
                                          allstars={

                                              <div className="rate_product-div-body-stars"  >

                                                  { answerTorate.value > 0 ?
                                                  
                                                      <AiFillStar className="rate_product-div-body-stars-star" onClick={ () => setanswerTorate({...answerTorate,value:1}) } />
                            
                                                    :<AiOutlineStar className="rate_product-div-body-stars-star" onClick={ () => setanswerTorate({...answerTorate,value:1}) } />}
                            
                                                  { answerTorate.value > 1 ?
                                                  
                                                  <AiFillStar className="rate_product-div-body-stars-star" onClick={ () => setanswerTorate({...answerTorate,value:2}) } />
                            
                                                :<AiOutlineStar className="rate_product-div-body-stars-star" onClick={ () => setanswerTorate({...answerTorate,value:2}) } />}
                            
                                                  { answerTorate.value > 2 ?
                                                  
                                                  <AiFillStar className="rate_product-div-body-stars-star" onClick={ () => setanswerTorate({...answerTorate,value:3}) } />
                            
                                                :<AiOutlineStar className="rate_product-div-body-stars-star" onClick={ () => setanswerTorate({...answerTorate,value:3}) } />}
                            
                                                  { answerTorate.value > 3 ?
                                                  
                                                  <AiFillStar className="rate_product-div-body-stars-star" onClick={ () => setanswerTorate({...answerTorate,value:4}) } />
                            
                                                :<AiOutlineStar className="rate_product-div-body-stars-star" onClick={ () => setanswerTorate({...answerTorate,value:4}) } />}
                                                  
                                                  { answerTorate.value > 4 ?
                                                  
                                                  <AiFillStar className="rate_product-div-body-stars-star" onClick={ () => setanswerTorate({...answerTorate,value:5}) } />
                            
                                                :<AiOutlineStar className="rate_product-div-body-stars-star" onClick={ () => setanswerTorate({...answerTorate,value:5}) } />}
                            
                            
                                            </div>

                                          }
                                          sbt={ answerTorate.loading ? <BtnSpin bgColor="white" /> : 'Rate Answer' }
                                          post_reply={RateAnswerHandler}
                                      />




                                    {/* REPLY TO QUESTION MODAL */}

                                    <ReplyQuestionDiv
                                        show={open_compose_qreply}
                                        close={ () => set_open_compose_qreply(false) }
                                        msg={ replyquestion.msg }
                                        comdisplay={ replyquestion.msg !== '' ? 'block' : 'none' }
                                        comcolor={ replyquestion.msg !== '' && replyquestion.error ? 'red' : 'green' }
                                        post_answer={ postQreplyHandler }
                                        answer={ replyquestion.value }
                                        onChange={ (event) => setreplyquestion({...replyquestion,value:event.target.value}) }
                                        sbt={ replyquestion.loading ? <BtnSpin bgColor="white" /> : 'Reply Question' }
                                    />
















                                    {/* ANSWER REPLY MODAL */}



                                    <AnswerReplydiv
                                      show={open_compose_replyanswer}
                                      close={ () => set_open_compose_replyanswer(false) }
                                      commentToreply={ 
                    
                                        answerToreply.answer ? 
                                        
                                          <AnswertobeReplied
                                            story={answerToreply.answer.answer}
                                            img={ answerToreply.answer.user.pro.profile_picture }
                                            name={ answerToreply.answer.user.first_name + ' ' + answerToreply.answer.user.last_name }
                                            date={ answerToreply.answer.time_since }
                                            msg={ answerToreply.msg }
                                            comdisplay={ answerToreply.msg !== '' ? 'block' : 'none' }
                                            comcolor={ answerToreply.msg !== '' && !answerToreply.error ? 'green' : 'tomato' }     
                                          />
                    
                                        : null
                    
                                        }
                                        post_reply={ReplyToAnswerHandler}
                                        reply={ answerToreply.value }
                                        onChange={ (event) => setanswerToreply({...answerToreply,value:event.target.value})  }
                                        sbt={ answerToreply.loading && !answerToreply.error ? <BtnSpin bgColor="white" /> : 'Reply To Answer' }
                                        disabled={ answerToreply.loading && !answerToreply.error ? true : false } 
                                      
                                    />
                                    














                                <div className="aop_pen-qr" onClick={!context.User_token && !context.User_id ? () => props.history.push('/quicksignin') : Openrquecompose} >
                                    <TiArrowBackOutline className="aop_pen-qr-ic " /> Reply Question
                                </div>

                                <div className="aop_pen-ans" onClick={!context.User_token && !context.User_id ? () => props.history.push('/quicksignin') : Openanscompose } >
                                    <BiChat className="aop_pen-ans-ic " /> Answer The Question
                                </div>

                            </>

          }
        }
      } 
    
    


      return ( 

        <>

            <TopbannerDiv
              closeshow={ () => setmessage({
                status:false,
                message:'',
                bgcolor:'orange'
              }) }
              show={ message.status }
              backgroundcolor={ message.bgcolor }
              message={ message.message } 
            />

            {what_to_return}

        </>

      );

}

export default QuestionDetailPage;