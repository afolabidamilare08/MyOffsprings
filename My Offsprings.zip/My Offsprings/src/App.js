import React from 'react';
import './css/main.css';
import { Route } from 'react-router-dom';
// import LayoutPage from './layout/'
import LayoutPage from './layout/layout';
import LogicStore from './store/logicforstore';
import ProfileLayoutPage from './layout/profile_layout';
import AopLayoutPage from './layout/aos_layout';
// import OneSignal from 'react-onesignal';
import OurLayoutPage from './layout/our_layout';
import OurProfileLayoutPage from './layout/our_profile_layout';
import ProductLayoutPage from './layout/product_layout';


const App = (props) => {

// OneSignal.initialize('f805be84-c9e9-4cd6-acdb-9014b49e6929',Option)
// // Check all possible permission states
// const permissions = OneSignal.notificationPermission;
 
// Check current permission state
// const currentState = await OneSignal.getNotificationPermission();
 
// Ask the user for notification permissions, if not granted yet
// await OneSignal.registerForPushNotifications();

    return (

      // currentState()

      <LogicStore>
      {/* {permissions()} */}

            <Route path="/profile" exact component={ProfileLayoutPage} />  
            <Route path="/" exact component={LayoutPage} /> 
            <Route path="/fresh" exact component={LayoutPage} /> 
            <Route path="/products/:offset" exact component={LayoutPage} /> 
            <Route path="/products/categories/category=:category" exact component={LayoutPage} /> 
            <Route path="/products/categories/category_more=:category/:offset" exact component={LayoutPage} /> 
            <Route path="/products/r_categories/:category/:id" exact component={LayoutPage} /> 
            <Route path="/products/search/query=:query" exact component={LayoutPage} /> 
            <Route path="/products/search/query=:query/:offset" exact component={LayoutPage} /> 
            <Route path="/ourproducts" exact component={OurLayoutPage} /> 
            <Route path="/ourproducts/products/:offset" exact component={OurLayoutPage} /> 
            <Route path="/ourproducts/products/search/query=:query" exact component={OurLayoutPage} /> 
            <Route path="/ourproducts/products/search/query=:query/:offset" exact component={OurLayoutPage} /> 
            <Route path="/ourproducts/categories/category=:category" exact component={OurLayoutPage} /> 
            <Route path="/ourproducts/categories/category_more=:category/:offset" exact component={OurLayoutPage} /> 
            <Route path="/new_supplier" exact component={OurLayoutPage} /> 
            <Route path="/reg_supplier" exact component={OurLayoutPage} /> 
            <Route path="/signin" exact component={LayoutPage} />
            <Route path="/quicksignin" exact component={LayoutPage} />
            <Route path="/signup" exact component={LayoutPage} />
            <Route path="/reset_password" exact component={LayoutPage} />
            <Route path="/change_password/1234" exact component={LayoutPage} />
            <Route path="/edit_profile" exact component={ProfileLayoutPage} />
            <Route path="/referal" exact component={ProfileLayoutPage} />
            <Route path="/referid:id" exact component={LayoutPage} />
            <Route path="/preorder" exact component={LayoutPage} />
            <Route path="/my_orders" exact component={ProfileLayoutPage} />
            <Route path="/my_order/:id" exact component={ProfileLayoutPage} />
            <Route path="/our_orders" exact component={OurProfileLayoutPage} />
            <Route path="/our_order/:id" exact component={OurProfileLayoutPage} />
            <Route path="/profile/password" exact component={ProfileLayoutPage} />
            <Route path="/my_cart" exact component={LayoutPage} />
            <Route path="/register_as_supplier" exact component={LayoutPage} />
            <Route path="/checkout_preview/:id" exact component={ProfileLayoutPage} />
            <Route path="/product/:slug/:id" exact component={ProductLayoutPage} />
            <Route path="/editproduct/:slug/:id" exact component={OurLayoutPage} />
            <Route path="/sell_is_product" exact component={LayoutPage} />
            <Route path="/final_supplier" exact component={LayoutPage} />
            <Route path="/aop" exact component={AopLayoutPage} />
            <Route path="/aop/search/query=:query" exact component={AopLayoutPage} /> 
            <Route path="/aop/question/:slug/:id" exact component={AopLayoutPage} />
            <Route path="/aop/my_questions" exact component={AopLayoutPage} />
            <Route path="/aop/my_questions/edit/:slug/:id" exact component={AopLayoutPage} />
            <Route path="/its_admin" exact component={OurProfileLayoutPage} />
            {/* <Route component={IndexPage} /> */}
      </LogicStore>
    );

}

export default App;
