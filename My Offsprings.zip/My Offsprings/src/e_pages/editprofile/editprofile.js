import React,{useState,useContext,useEffect} from 'react';
import ProfileHeader from '../../layout_components/profile_header/profile_header';
import Svg from '../../component/utilities/Svg';
import { InputWithLabel, LoginSelect, LoginBtn } from '../../component/login_components/login_components';
import Store from '../../store/managementstore/managementstore';
import Axios from 'axios';
import {FiCamera} from 'react-icons/fi';
import LoadingPage from '../../component/utilities/loading/loading';
import OppsPage from '../../component/utilities/oppspage/oppspage';
import TopbannerDiv from '../../component/top-banner-msg/topbannermsg';
import {useVerifyimg} from '../../component/utilities/checkingforletter';


const EditProfile = (props) => {

      const context = useContext(Store)
 
      if ( !context.User_id ) {
        props.history.push('/signin')
      }

      const [ User_det , setUser_det ] = useState(null)
      const [ Errorpage , setErrorpage ] = useState(false)
      const [ Loadingpage , setLoadingpage ] = useState(false)
      const [ updatingpicture , setupdatingpicture ] = useState(false)
      const [ Saving , setSaving ] = useState(false)
      const [ Msg , setMsg ] = useState({
        bg:'',
        msg:'',
        value:false
      })
      const [ Ready_det , setReady_det ] = useState({
        first_name:'',
        last_name:'',
        email:'',
        username:'',
        phone_number:'',
        gender:'',
      })

      useEffect( () => {

        setLoadingpage(true)
        setErrorpage(false)
        setSaving(false)

        var userId = context.User_id

        Axios.get('/myaccount/users/' + userId + '/').then(

          response => {
            // console.log(response.data)
            setReady_det({
              first_name:response.data.first_name,
              last_name:response.data.last_name,
              email:response.data.email,
              username:response.data.username,
              phone_number:response.data.pro.phone_number,
              gender:response.data.pro.gender,
              profile_picture:response.data.pro.profile_picture,
            })
            setUser_det(response.data)
            setLoadingpage(false)
            setErrorpage(false)   
            setSaving(false) 
          }

        ).catch(

          e => {
            setLoadingpage(false)
            setErrorpage(true)   
            setSaving(false)
          }

        )

      } , [context.User_id] )














      const UpdateimgHandler = (event) => {

        const [result] = useVerifyimg(event.target.files)
        setupdatingpicture(true)
        setMsg({
          bg:'orange',
          msg:' Updating profile picture ',
          value:true
        }); 

        if( result ){
    
          const fd = new FormData();
          fd.append('profile_picture',event.target.files[0],event.target.files[0].name)

          Axios.patch('/myaccount/myprofile/' + context.User_id + '/',fd).then(

            response => {

              setMsg({
                bg:'rgb(39, 180, 39)',
                msg:' Your profile picture was successfully updated ',
                value:true
              }); 
              setReady_det({...Ready_det,profile_picture:response.data.profile_picture})
              setupdatingpicture(false)

          } 
          ).catch(
            error => {
              setMsg({
                bg:'red',
                msg:' Something Went Wrong ',
                value:true
              }) 
            setupdatingpicture(false)
            }
          );

          }else{
            setMsg({
              bg:'red',
              msg:' only jpg , jpeg , png and gif files are allowed  .... ',
              value:true
            }) 
            setupdatingpicture(false)
          }


      }























  


      const editprofileHandler = (e) => {

        setSaving(true)
        setMsg({
          bg:'',
          msg:'',
          value:false
        })
        e.preventDefault()

        if ( Ready_det.first_name === '' || Ready_det.last_name === '' || Ready_det.email === '' || Ready_det.username === '' || Ready_det.phone_number === '' || Ready_det.gender === '' ) {
          
          setSaving(false)
          setMsg({
            bg:'red',
            msg:'All Fields must be filled',
            value:true
          })

        }else{

          const postdata = {
            first_name:Ready_det.first_name,
            last_name:Ready_det.last_name,
            email:Ready_det.email,
            username:Ready_det.username
          }

          const postdata2 = {
            phone_number:Ready_det.phone_number,
            gender:Ready_det.gender
          }

          Axios.patch('/myaccount/users/' + context.User_id + '/' ,postdata).then(

            response => {

              Axios.patch('/myaccount/myprofile/' + context.User_id + '/' ,postdata2).then(

                response => {
                  setSaving(false)
                  setMsg({
                    bg:'rgb(39, 180, 39)',
                    msg:'Profile Details Saved',
                    value:true
                  })
                }

              ).catch( e => {
                setSaving(false)
                setMsg({
                  bg:'red',
                  msg:'Something Went Wrong',
                  value:true
                })
              } )

            }

          ).catch( e => {
            setSaving(false)
            setMsg({
              bg:'red',
              msg:'Something Went Wrong',
              value:true
            })
          } )

        }

      }


      const gogo = () => {
        props.history.go()
      } 
    
      const goBack = () => {
        props.history.goBack()
      }



      var genderOption = (<>
                            <option value="" > Gender </option>
                            <option value="male" > Male </option>
                            <option value="female" > Female </option>
                            <option value="not-specified" > Not Specified </option>
                          </>
      );


      if( !User_det && Loadingpage && !Errorpage ){
        var what_to_return = <LoadingPage/>
      }else{
        if ( !User_det && !Loadingpage && Errorpage ) {
          what_to_return = <OppsPage tryagain={gogo} goback={goBack} />
        }else{
          if ( User_det && !Loadingpage && !Errorpage ) {
            what_to_return = <div className="main_big_box">

                                  <div className="main_big_box_first">

                                          {/* <div className="main_big_box_first_profilename">
                                                  Edit Profile
                                          </div> */}

                                  <div className="main_big_box_first_profilepicbox">


                                      <div className="main_big_box_first_profilepicbox_circle">

                                          { !Ready_det.profile_picture ?
                                          
                                            <Svg
                                            href="demo2.svg#icon-user1"
                                            className="main_big_box_first_profilepicbox_circle_ic"/>:

                                          <img src={ Ready_det.profile_picture[0] === '/' ? Ready_det.profile_picture : Ready_det.profile_picture } alt="profileImage"  className="main_big_box_first_profilepicbox_circle_profilepics"/>

                                          }

                                      </div>
                                      
                                      <form className="main_big_box_first_profilepicbox_circle2">
                                          <label for="file" className="main_big_box_first_profilepicbox_circle2-emp" >
                                            <FiCamera className="main_big_box_first_profilepicbox_circle2_ic"
                                            />
                                          </label>
                                          <input disabled={updatingpicture} className="main_big_box_first_profilepicbox_circle2-input" id="file" type="file" onChange={UpdateimgHandler} />
                                      </form>

                                  </div>

                                  <div className="main_big_box_first_profilepicbox_name" >
                                          Edit Profile
                                  </div>

                                  <form className="main_big_box_first_profilepicbox_form" onSubmit={editprofileHandler} >
                                      <InputWithLabel
                                        label="First Name"
                                        type="text"
                                        onChange={ (event) => setReady_det({...Ready_det,first_name:event.target.value}) }
                                        value={ Ready_det.first_name !== null ? Ready_det.first_name : '' } />

                                      <InputWithLabel
                                        label="Last Name"
                                        type="text"
                                        onChange={ (event) => setReady_det({...Ready_det,last_name:event.target.value}) }
                                        value={ Ready_det.last_name !== null ? Ready_det.last_name : '' } />

                                      <InputWithLabel
                                        label="Email"
                                        type="email"
                                        onChange={ (event) => setReady_det({...Ready_det,email:event.target.value}) }
                                        value={ Ready_det.email !== null ? Ready_det.email : '' } />

                                      <InputWithLabel
                                        label="Phone Number"
                                        type="text"
                                        onChange={ (event) => setReady_det({...Ready_det,phone_number:event.target.value}) }
                                        value={ Ready_det.phone_number !== null ? Ready_det.phone_number : '' } />

                                      <LoginSelect
                                        label="Gender" 
                                        onChange={ (event) => setReady_det({...Ready_det,gender:event.target.value}) }
                                        value={ Ready_det.gender !== null ? Ready_det.gender : '' }
                                        options={genderOption}
                                        /> 

                                      <LoginBtn
                                      disabled={Saving}
                                      value="Save Changes" /> 

                                  </form>

                                  </div>

                                </div>
          }
        }
      }




      return ( 

          <>
              
              <TopbannerDiv 
                backgroundcolor={Msg.bg} 
                show={Msg.value}
                message={Msg.msg}
                closeshow={ () => setMsg({...Msg,value:false}) }
                />

              <ProfileHeader
                title="Edit Profile"
                goback={ () => props.history.goBack() }
              />

              {what_to_return}

          </>
          
      );

}

export default EditProfile;