import React,{ useState , useEffect } from 'react';
import { ProductsBox, IndexHomeProductList} from './utilities/utilities';
import LoadingPage from '../../component/utilities/loading/loading';
import OppsPage from '../../component/utilities/oppspage/oppspage';
import {EmptyProduct} from '../../component/utilities/empty/no_product'
import Axios from 'axios';
import IndexSlider from './slider/slider';

const IndexHome = (props) => {

    const [ RCategory , setRCategory ] = useState(null)
    const [ Errorpage , setErrorpage ] = useState(false)
    const [ Loading , setLoading ] = useState(false)

    useEffect( () => {

        setErrorpage(false)
        setLoading(true)

        Axios.get('/myproduct/rcategory/?limit=1000&offset=0').then(

            response => {

                setRCategory(response.data.results)
                setErrorpage(false)
                setLoading(false)

            }

        ).catch(

            e => {
                setErrorpage(true)
                setLoading(false)        
            }

        )

    } ,[] )




    const gogo = () => {
        props.history.go()
    } 

    const goBack = () => {
        props.history.goBack()
    }




    if ( !RCategory && !Errorpage && Loading ) {
        var todisplay = <LoadingPage/>
    }else{
        if ( !RCategory && Errorpage && !Loading ) {
            todisplay = <OppsPage tryagain={gogo} goback={goBack} />
        }else{
            if ( RCategory && !Errorpage && !Loading ) {
                 todisplay = <>
                            
                            { RCategory.length > 0 ? <>

                                { RCategory.map( ( rcategory , index ) => {

                                    if ( rcategory.categories.length > 0 ) {
                                        
                                        var Which = []

                                        for (let h = 0; h < rcategory.categories.length; h++) {
                                            
                                            if ( rcategory.categories[h].myproducts.length > 4 ) {
                                                Which.push(rcategory.categories[h])
                                                break
                                            }

                                        }

                                        if( Which.length > 0 ){
                                            var brnit = []

                                            for (let k = 0; k < 6; k++) {
                                                if ( Which[0].myproducts[k] ) {
                                                    brnit.push(Which[0].myproducts[k])
                                                }
                                            }

                                            return  <ProductsBox
                                                        key={index}
                                                        title={rcategory.cat_name}
                                                        to={ '/products/r_categories/' + rcategory.cat_name + '/' + rcategory.id  }
                                                        body={
                                                            <>
                                    
                                                                { brnit.map(( product , index ) => {
                                    
                                                                    return <IndexHomeProductList
                                                                            key={index}
                                                                            productname={product.myproduct_name}   
                                                                            // img={product.product_img1}
                                                                            price={product.selling_price} 
                                                                            avg_rating={product.avg_rating}
                                                                            to={'/product/' + product.slug + '/' +product.id}
                                                                        />
                                                                } ) }
                                    
                                                            </>
                                                        }
                                                    />


                                        }else{
                                            return null
                                        }

                                    }else{
                                        return null
                                    }

                                } ) }

                            </> : <EmptyProduct/> }

                 </>
            }
        }  
    }










    return (
            <>
                
                <div className="grace" >
                    <IndexSlider/>
                </div>

                { todisplay }

            </>
    );
}

export default IndexHome;