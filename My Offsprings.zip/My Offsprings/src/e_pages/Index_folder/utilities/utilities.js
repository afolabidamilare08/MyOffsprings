import React from 'react';
import { Link } from 'react-router-dom/cjs/react-router-dom';
import {AiFillStar,AiOutlineStar} from 'react-icons/ai';

export const ProductsBox = (props) => {

    return (

        <div className="productsbox-div" >

            <div className="productsbox-div-top" >

                <div className="productsbox-div-top-name" >
                    {props.title}
                </div>

                <Link className="productsbox-div-top-link" to={props.to} >
                    View All
                </Link>

            </div>

            <div className="productsbox-div-body" >
                {props.body}
            </div>

        </div>

    );
}




export const IndexHomeProductList = (props) => {

    if( props.productname.length > 20 ){
        var pname = []
        for( var i = 0 ; i < 20 ; i++ ){
            pname.push(props.productname[i])
        } 
        pname.push('...')
    }else{
        pname = props.productname
    }

    return (
        
        <div className="indexhome-productList" >
            
            <div className="indexhome-productList-img" >
                <img src={props.img} alt="" className="indexhome-productList-img-img" />
            </div>

            <Link className="indexhome-productList-name" to={props.to} >
                {pname}
            </Link>

            <div className="indexhome-productList-rat" >

                    { props.avg_rating > 0 ?  

                    <AiFillStar className="indexhome-productList-rat-ic" />

                    : <AiOutlineStar className="indexhome-productList-rat-ic" /> 

                    }

                    { props.avg_rating > 1 ? 

                    <AiFillStar className="indexhome-productList-rat-ic" />

                    : <AiOutlineStar className="indexhome-productList-rat-ic" /> 

                    }

                    { props.avg_rating > 2 ? 

                    <AiFillStar className="indexhome-productList-rat-ic" />

                    : <AiOutlineStar className="indexhome-productList-rat-ic" /> 

                    }

                    { props.avg_rating > 3 ? 

                    <AiFillStar className="indexhome-productList-rat-ic" />

                    : <AiOutlineStar className="indexhome-productList-rat-ic" /> 

                    }

                    { props.avg_rating > 4 ? 

                    <AiFillStar className="indexhome-productList-rat-ic" />

                    : <AiOutlineStar className="indexhome-productList-rat-ic" /> 

                    }

            </div>

            <Link className="indexhome-productList-price" to={props.to} >
                ₦ {new Intl.NumberFormat({ style: 'currency', currency: 'EUR' }).format(props.price) }
            </Link>

            <Link className="indexhome-productList-btn" to={props.to} >
                ADD TO CART 
            </Link>

        </div>

    );
}


export const IndexHomeProductList2 = (props) => {

    if( props.productname.length > 20 ){
        var pname = []
        for( var i = 0 ; i < 20 ; i++ ){
            pname.push(props.productname[i])
        } 
        pname.push('...')
    }else{
        pname = props.productname
    }

    return (
        
        <div className="indexhome-productList indexhome-productList2" >
            
            <div className="indexhome-productList-img indexhome-productList2-img" >
                <img src={props.img} alt="" className="indexhome-productList-img-img indexhome-productList2-img-img" />
            </div>

            <Link className="indexhome-productList-name indexhome-productList2-name" to={props.to} >
                {pname}
            </Link>

            <div className="indexhome-productList-rat indexhome-productList2-rat" >

                    { props.avg_rating > 0 ?  

                    <AiFillStar className="indexhome-productList-rat-ic indexhome-productList2-rat-ic" />

                    : <AiOutlineStar className="indexhome-productList-rat-ic indexhome-productList2-rat-ic" /> 

                    }

                    { props.avg_rating > 1 ? 

                    <AiFillStar className="indexhome-productList-rat-ic indexhome-productList2-rat-ic" />

                    : <AiOutlineStar className="indexhome-productList-rat-ic indexhome-productList2-rat-ic" /> 

                    }

                    { props.avg_rating > 2 ? 

                    <AiFillStar className="indexhome-productList-rat-ic indexhome-productList2-rat-ic" />

                    : <AiOutlineStar className="indexhome-productList-rat-ic indexhome-productList2-rat-ic" /> 

                    }

                    { props.avg_rating > 3 ? 

                    <AiFillStar className="indexhome-productList-rat-ic indexhome-productList2-rat-ic" />

                    : <AiOutlineStar className="indexhome-productList-rat-ic indexhome-productList2-rat-ic" /> 

                    }

                    { props.avg_rating > 4 ? 

                    <AiFillStar className="indexhome-productList-rat-ic indexhome-productList2-rat-ic" />

                    : <AiOutlineStar className="indexhome-productList-rat-ic indexhome-productList2-rat-ic" /> 

                    }

            </div>

            <Link className="indexhome-productList-price indexhome-productList2-price" to={props.to} >
                ₦ {new Intl.NumberFormat({ style: 'currency', currency: 'EUR' }).format(props.price) }
            </Link>

            { props.edit ? 
               <> <Link className="indexhome-productList-btn indexhome-productList2-btn" to={props.to} >
                    EDIT PRODUCT 
                </Link> <button className="indexhome-productList-btn indexhome-productList2-btn" onClick={props.rate} style={{border:'none'}} > RATE PRODUCT </button> </>
            :   <Link className="indexhome-productList-btn indexhome-productList2-btn" to={props.to} >
                    ADD TO CART 
                </Link> }

        </div>

    );
}


export const SliderDiv = (props) => {

    return (

        <div className="slider-div" >
            
            <div className="slider-div-left" >
                <img alt="" src={props.img} className="slider-div-left-img" />
            </div>

            <div className="slider-div-right" >
                Do You Have Any Question
                <br/>
                About Children Bothering
                <br/>
                Your Mind 
                {/* <b>₦ 40,000</b> */}

                <button className="slider-div-right-btn" >Ask Other Parents</button>

            </div>

        </div>

    );

}