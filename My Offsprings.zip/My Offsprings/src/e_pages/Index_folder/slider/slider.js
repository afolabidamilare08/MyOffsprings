import React, { useState, useEffect } from 'react';
import { Link } from 'react-router-dom/cjs/react-router-dom.min';
import Aop from '../../../component/utilities/img/Messages-pana.png';
import Shoe from '../../../component/utilities/img/shoe4.png';
import Referal from '../../../component/utilities/img/5867.jpg';

const IndexSlider = (props) => {

    const [ Index , setIndex ] = useState({num:1})

    useEffect( () => {

        setTimeout(() => {
            var num = {...Index}
            var newb = num.num + 1

            // console.log('num',num)
            // console.log('newb',newb)
    
            if ( newb > 3 ) {
                var lag = 1
            }else{
               lag = newb
            }
    
            setIndex({num:lag})
        }, 7000);
        
    } , [Index] )




 

    if( Index.num === 1 ){
        var linear = 'white'
        var show = <>

            <div className="slider-div" >
                
                <div className="slider-div-left" >
                    <img alt="" src={Aop} className="slider-div-left-img" />
                </div>

                <div className="slider-div-right" >
                    Join The Fastest Growing <br/>
                    Community Of Parents
                    <br/>
                    In Nigeria
                    {/* <b>₦ 40,000</b> */}

                    <Link to="/aop" className="slider-div-right-btn" >Get Started</Link>

                </div>

            </div>

        </>
    }else{

        if ( Index.num === 2 ) {

            linear = 'white'
            show = <>

                    <div className="slider-div" >
                        
                        <div className="slider-div-left" >
                            <img alt="" src={Referal} className="slider-div-left-img" />
                        </div>

                        <div className="slider-div-right" style={{
                            color:'gray'
                        }} >
                            Start Making Money Today
                            <br/>
                            By Refering Someone To Buy
                            <br/> 
                            From Us
                            {/* <b>₦ 40,000</b> */}

                            <Link to="/referal" className="slider-div-right-btn" >Start Refering</Link>

                        </div>

                    </div>   
            </>
        }else{

            if ( Index.num === 3 ) {

                linear = 'white'
                show = <>
    
                        <div className="slider-div" >
                            
                            <div className="slider-div-left" >
                                <img alt="" src={Shoe} className="slider-div-left-img" />
                            </div>
    
                            <div className="slider-div-right" style={{
                                color:'gray'
                            }} >
                                Buy Quality Shoes
                                <br/>
                                At The Cheapest Price At
                                <br/> 
                                Your Comfort
                                {/* <b>₦ 40,000</b> */}
    
                                <Link to="/products/categories/category=shoes" className="slider-div-right-btn" >Get Started</Link>
    
                            </div>
    
                        </div>   
                </>
            }

        }

    }

    return (

        <div className="indexhome-slider" style={{
            background:linear
        }} >

            <div className="indexhome-slider-top" > Limited Deals </div>
            
            {show}


            {/* <div className="indexhome-slider-btm" >
                <div className="indexhome-slider-btm-li" onClick={ () => setIndex(1) } ></div>
                <div className="indexhome-slider-btm-li" onClick={ () => setIndex(2) } ></div>
                <div className="indexhome-slider-btm-li" onClick={ () => setIndex(3) } ></div>
            </div> */}

        </div>

    );
}

export default IndexSlider;