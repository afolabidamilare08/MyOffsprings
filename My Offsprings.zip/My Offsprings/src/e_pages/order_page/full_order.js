import React,{useState,useEffect,useContext} from 'react';
import { CheckoutPreviewTemplate, Orderstatusbtn } from '../check_out/check_out_template';
import LoadingPage from '../../component/utilities/loading/loading';
import OppsPage from '../../component/utilities/oppspage/oppspage';
import Axios from 'axios';
import { OrderItem } from '../cart_page/item';
import Store from '../../store/managementstore/managementstore';
import ProfileHeader from '../../layout_components/profile_header/profile_header';
import {AiOutlinePlus,AiFillStar, AiOutlineStar} from 'react-icons/ai';
import { LoginBtn } from '../../component/login_components/login_components';
import BtnSpin from '../../component/utilities/btnSpin/btnSpin';
import { useMonth } from '../check_out/useMonth';

const FullOrderPage = (props) => {

      const Orid = props.match.params.id
      const context = useContext(Store)
      
      const [ Loadingpage , setLoadingpage ] = useState(false)
      const [ Errorpage , setErrorpage ] = useState(false)  

      const [ Order , setOrder ] = useState(null)
      const [ OrderAddress , setOrderAddress ] = useState(null)
      const [ DeliveryDate , setDeliveryDate ] = useState(null)

      const [ Producttorate , setProducttorate ] = useState(null)
      const [ Ratingproduct , setRatingproduct ] = useState(0)
      const [ ratbtn , setratbtn ] = useState(false)
      const [ ratemsg , setratemsg ] = useState({
        value:'',
        color:''
      })

      



      useEffect( () => {

        setErrorpage(false)
        setLoadingpage(true)


        Axios.get('/myorder/myorder/' + Orid + '/' ).then(

            response => {

                  if ( response.data.status === 'created' ) {
                    props.history.push('/my_order/'+response.data.id)
                  }else{

                    var another_response = response.data

                    Axios.get('/myaccount/users/' + context.User_id + '/').then(

                      response => {
                        setOrder(another_response)
                        setErrorpage(false)
                        setLoadingpage(false)  
                        setOrderAddress(response.data.address)
                      }

                    ).catch(
                      
                      e => {
                        setErrorpage(true)
                        setLoadingpage(false)
                      }

                    )
                    
                     }
                  
                }

        ).catch(

            e => {
                setErrorpage(true)
                setLoadingpage(false)
            }

        )
// eslint-disable-next-line
      },[Orid] )






      const GetMonth = (number) => {
        const [month] = useMonth(number)
        return month
      }


      const Addtodeliv = (fulldate) => {

        setDeliveryDate({
          day:fulldate.day,
          month:fulldate.month,
          year:fulldate.year
        })

      }




      

      if( Order && !DeliveryDate ){

        var longest = 0

        for (let u = 0; u < Order.items.length; u++) {
          
          var day_to = parseInt(Order.items[u].product.days_to)

          if ( day_to > longest ) {
              longest = day_to
          }

        }

        const event = new Date(Order.create_date);

        event.setDate(event.getDate() + longest);

        const first_day = event.getDay()

          if ( first_day === 0 ) {

            var some = new Date(Order.create_date)
            var newlongest = longest + 3

            some.setDate(some.getDate() + newlongest)
  
            const theyear = some.getFullYear()
            const themonth = some.getMonth()
  
            const readymonth = GetMonth(themonth)
        
            
            var Datetosend = {
              day:some.getDate(),
              month:readymonth,
              year:theyear
            }

            Addtodeliv(Datetosend)
          }

          if ( first_day === 1 ) {

             some = new Date(Order.create_date)
            newlongest = longest + 5
            some.setDate(some.getDate() + newlongest)
  
            const theyear = some.getFullYear()
            const themonth = some.getMonth()
  
            const readymonth = GetMonth(themonth)
        
            
             Datetosend = {
              day:some.getDate(),
              month:readymonth,
              year:theyear
            }

            Addtodeliv(Datetosend)
          }

          if ( first_day === 2 ) {

            some = new Date(Order.create_date)

            newlongest = longest + 4

            some.setDate(some.getDate() + newlongest)
  
            const theyear = some.getFullYear()
            const themonth = some.getMonth()
  
            const readymonth = GetMonth(themonth)
        
            
             Datetosend = {
              day:some.getDate(),
              month:readymonth,
              year:theyear
            }

            Addtodeliv(Datetosend)
          }

          if ( first_day === 3 ) {

            some = new Date(Order.create_date)

            newlongest = longest + 3

            some.setDate(some.getDate() + newlongest)
  
            const theyear = some.getFullYear()
            const themonth = some.getMonth()
  
            const readymonth = GetMonth(themonth)
        
            
            Datetosend = {
              day:some.getDate(),
              month:readymonth,
              year:theyear
            }

            Addtodeliv(Datetosend)
          }

          if ( first_day === 4 ) {

            some = new Date(Order.create_date)

            newlongest = longest + 6

            some.setDate(some.getDate() + newlongest)
  
            const theyear = some.getFullYear()
            const themonth = some.getMonth()
  
            const readymonth = GetMonth(themonth)
            
            Datetosend = {
              day:some.getDate(),
              month:readymonth,
              year:theyear
            }

            Addtodeliv(Datetosend)
          }

          if ( first_day === 5 ) {

            some = new Date(Order.create_date)
            
            newlongest = longest + 5

            some.setDate(some.getDate() + newlongest)
  
            const theyear = some.getFullYear()
            const themonth = some.getMonth()
  
            const readymonth = GetMonth(themonth)
        
            
            Datetosend = {
              day:some.getDate(),
              month:readymonth,
              year:theyear
            }

            Addtodeliv(Datetosend)
          }

          if ( first_day === 6 ) {

            some = new Date(Order.create_date)

            newlongest = longest + 4

            some.setDate(some.getDate() + newlongest)
  
            const theyear = some.getFullYear()
            const themonth = some.getMonth()
  
            const readymonth = GetMonth(themonth)
        
            
            Datetosend = {
              day:some.getDate(),
              month:readymonth,
              year:theyear
            }

            Addtodeliv(Datetosend)
          }

        
      }
      
      if ( DeliveryDate ) {
        var date = DeliveryDate.day.toString()
        var number = date[date.length - 1]

        if ( date === '11' || date === '12' || date === '13' || date === '14' || date === '15' || date === '16' || date === '17' || date === '18' || date === '19' ) {
          var back = 'th'
        }else{
          if ( number === '4' || number === '5' || number === '6' || number === '8' || number === '9' || number === '0' ) {
            back = 'th'
          }else{
            if ( number === '1' ) {
              back = 'st'
            }
            if( number === '2' ){
              back = 'nd'
            }
            if ( number === '3' ) {
              back = 'rd'            
            }
          }
        }

      }else{

      }

      const rAteProuctHandler = (e) => {

        e.preventDefault()

        setratbtn(true)
        setratemsg({
          value:'',
          color:''
        })

        if ( Ratingproduct < 1 ) {
          setratbtn(false)
          setratemsg({
            value:'Please rate the product',
            color:'red'
          })
        }else{

          Axios.post('/myproduct/myproduct/' + Producttorate.product.id + '/rate_myproduct/',{stars:Ratingproduct}).then(

            response => {
              setratbtn(false)
              setratemsg({
                value:'You Have Rated The Product Successfully',
                color:'green'
              })

              setRatingproduct(0)

              setTimeout(() => {
                setProducttorate(null)
                setratemsg({
                  value:'',
                  color:''
                })
              }, 2000);

            }

          ).catch(
            e => {
              setratbtn(false)
              setratemsg({
                value:'Something Went Wrong',
                color:'red'
              })
            }
          )
        }

      }
















      if(Order){

        if(Order.items.length > 0){
          
          if( Order.status === 'paid' ){
            var color = 'orange'
            var status = 'Pending'
          }

          if( Order.status === 'created' ){
              color = 'red'
              status = 'Unpaid'
          }

          if( Order.status === 'in_transit' ){
            color = 'rgb(9, 123, 184)'
            status = 'In Transit'
          }

          if( Order.status === 'delivered' ){
            color = 'rgb(39, 180, 39)'
            status = 'Delivered'
          }
        }

      }





      const gogo = () => {
        props.history.go()
      } 
    
      const goBack = () => {
        props.history.goBack()
      }




    
    
      if( Loadingpage && !Order && !Errorpage ){
        var what_to_return = <LoadingPage/>
      }else{
        if ( !Loadingpage && Errorpage && !Order ) {
          what_to_return = <OppsPage tryagain={gogo} goback={goBack} />
        }else{
          if ( !Loadingpage && !Errorpage && Order ) {
            what_to_return = <>



                                    <CheckoutPreviewTemplate

                                        items={ 

                                            <> 
                                                
                                                { Order.items.length > 0 ? 



                                                    Order.items.map( ( item , index ) => {              

                                                        return <OrderItem
                                                                    key={index}
                                                                    img={ item.product.product_img1 }
                                                                    product_name={ item.product.myproduct_name }
                                                                    size={ item.size ? item.size.size : null }
                                                                    color={ item.colour ? item.colour.colour : null }
                                                                    quantity={ item.quantity }
                                                                    rate_product={ () => setProducttorate(item) }
                                                                    to={'/product/'+item.product.slug+'/'+item.product.id}
                                                                    unit_price={ item.product.selling_price }
                                                                    sub_total={ item.product.selling_price * item.quantity }
                                                                />
                                                    } )

                                                : null }

                                            </>

                                         } 
                                        items_length={ Order.items.length }
                                        address_to_show={false}
                                        address={ OrderAddress ? OrderAddress.address : null }
                                        lga={ OrderAddress ? OrderAddress.lga : null }
                                        state={ OrderAddress ? OrderAddress.state : null }
                                        delivery_date={ DeliveryDate ? DeliveryDate.day + back + ' of ' + DeliveryDate.month + ' ' + DeliveryDate.year : null }

                                    > 

                                                <Orderstatusbtn

                                                transport_cost={ Order.get_tfare }
                                                all_total={ Order.total_cost }
                                                status={status}
                                                backgroundcolor={color}/>

                                    </CheckoutPreviewTemplate>




                            </>
          }
        }
      }
    

      return (
        
        <>

            <ProfileHeader
              title="Order"
              goback={goBack}
            />

            <div className="rate_product-div" style={{
                transform: Producttorate ? 'translateY(0)' : 'translateY(50rem)'
            }} >

                <div className="rate_product-div-top" >
                    Rate Product

                    <AiOutlinePlus className="rate_product-div-top-close" onClick={ () => setProducttorate(null) } />

                </div>

                <div className="rate_product-div-msg" style={{
                  color:ratemsg.color
                }} >
                    {ratemsg.value}
                </div>

                <form className="rate_product-div-body" onSubmit={ rAteProuctHandler } >

                    <div className="rate_product-div-body-product" >
                        { Producttorate ? Producttorate.product.myproduct_name : null }
                    </div>


                    <div className="rate_product-div-body-stars"  >

                      { Ratingproduct > 0 ?
                      
                          <AiFillStar className="rate_product-div-body-stars-star" onClick={ () => setRatingproduct(1) } />

                         :<AiOutlineStar className="rate_product-div-body-stars-star" onClick={ () => setRatingproduct(1) } />}

                      { Ratingproduct > 1 ?
                      
                      <AiFillStar className="rate_product-div-body-stars-star" onClick={ () => setRatingproduct(2) } />

                     :<AiOutlineStar className="rate_product-div-body-stars-star" onClick={ () => setRatingproduct(2) } />}

                      { Ratingproduct > 2 ?
                      
                      <AiFillStar className="rate_product-div-body-stars-star" onClick={ () => setRatingproduct(3) } />

                     :<AiOutlineStar className="rate_product-div-body-stars-star" onClick={ () => setRatingproduct(3) } />}

                      { Ratingproduct > 3 ?
                      
                      <AiFillStar className="rate_product-div-body-stars-star" onClick={ () => setRatingproduct(4) } />

                     :<AiOutlineStar className="rate_product-div-body-stars-star" onClick={ () => setRatingproduct(4) } />}
                      
                      { Ratingproduct > 4 ?
                      
                      <AiFillStar className="rate_product-div-body-stars-star" onClick={ () => setRatingproduct(5) } />

                     :<AiOutlineStar className="rate_product-div-body-stars-star" onClick={ () => setRatingproduct(5) } />}


                    </div>

                    <LoginBtn value={ ratbtn ? <BtnSpin bgColor="white" /> : "Rate Product" } disabled={ratbtn} />

                </form>

            </div>

            {what_to_return}

        </>

      );

}

export default FullOrderPage;