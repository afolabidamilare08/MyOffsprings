import React from 'react';
import {AiOutlinePlus} from 'react-icons/ai';

export const Comp = (props) => {

      return ( 
        <div className="reg_as_sup_back-div" >

            <div className="reg_as_sup_back-div-top" >

                <div className="reg_as_sup_back-div-top-left" >
                    Supplier Terms And Conditons
                </div>

                <AiOutlinePlus className="reg_as_sup_back-div-top-right" onClick={ props.cancel } />

            </div>

            <div className="reg_as_sup_back-div-body" >

                <div className="reg_as_sup_back-div-body-title" > TERMS OF PAYMENT </div>
                
                <div className="reg_as_sup_back-div-body-body" >
                  Invoices shall be dated no earlier than date of shipment or delivery of service. 
                  The discount period begins upon receipt of invoice, 
                  required delivery date, or date any applicable discrepancy 
                  is resolved, whichever date is later. 
                </div>

                <div className="reg_as_sup_back-div-body-title" > ATTACHMENTS </div>
                
                <div className="reg_as_sup_back-div-body-body" >
                    Documents designated by MyOffsprings in the body of the Purchase Order,
                    including supplemental terms and conditions, 
                    if any, are incorporated by reference the same as if set out in full therein.
                </div>

                <div className="reg_as_sup_back-div-body-title" > CHANGES </div>
                
                <div className="reg_as_sup_back-div-body-body" >
                    MyOffsprings reserves the right at any time to issue 
                    a written change order or amendment to the Purchase 
                    Order concerning any of the following: 

                      <li className="reg_as_sup_back-div-body-body-ul-li" > Quantity </li>
                      <li className="reg_as_sup_back-div-body-body-ul-li" > Methods of shipment or packaging </li>
                      <li className="reg_as_sup_back-div-body-body-ul-li" > Place of delivery </li>
                      <li className="reg_as_sup_back-div-body-body-ul-li" > Time of delivery </li>
                      <li className="reg_as_sup_back-div-body-body-ul-li" > Any other matters affecting this Purchase Order </li>
                      <li className="reg_as_sup_back-div-body-body-ul-li" > Specifications, drawings, and data incorporated in the Purchase Order </li>

                </div>

                <div className="reg_as_sup_back-div-body-title" > TERMINATION </div>
                
                <div className="reg_as_sup_back-div-body-body" >
                      MyOffsprings may terminate the Purchase Order for its convenience,
                      in whole or in part, at any time prior to shipment by (written or electronic) notice to Seller/Supplier. 
                      Upon receipt of such termination notice, Seller shall promptly comply with the directions 
                      contained in such notice and shall, as required 

                      <li className="reg_as_sup_back-div-body-body-ul-li" > Take action necessary to terminate the work as provided in the notice, minimizing costs and liabilities for the terminated work  </li>
                      <li className="reg_as_sup_back-div-body-body-ul-li" > Continue the performance of any part of the work not terminated by Buyer </li>

                </div>

                <div className="reg_as_sup_back-div-body-title" > ASSIGNMENT </div>
                
                <div className="reg_as_sup_back-div-body-body" >
                    Seller may not assign, transfer, 
                    or subcontract this Purchase Order 
                    or any right or obligation hereunder 
                    without MyOffsprings' written consent
                </div>

                <div className="reg_as_sup_back-div-body-title" > EXCUSABLE DELAY </div>
                
                <div className="reg_as_sup_back-div-body-body" >
                    Fires, floods, strikes, accidents, shortages, 
                    or other causes beyond the reasonable control 
                    of the parties, which prevent Seller from delivering, 
                    or MyOffsprings from receiving, any of the goods and 
                    services covered by this Purchase Order, shall suspend 
                    deliveries until the cause is removed
                </div>

                <div className="reg_as_sup_back-div-body-title" > PACKAGING, PACKING LIST, AND BILL OF LADING AND DELIVERY </div>
                
                <div className="reg_as_sup_back-div-body-body" >
                    Seller shall be responsible for proper packaging, 
                    loading, and tie-down to prevent damage during transportation.
                </div>

                <div className="reg_as_sup_back-div-body-title" > INSPECTION </div>
                
                <div className="reg_as_sup_back-div-body-body" >
                    All goods and services furnished hereunder will be subject to inspection 
                    and test by MyOffsprings at all times and places and will be subject to 
                    MyOffspring's final inspection and approval within a reasonable time after delivery. 
                    It is the supplier’s responsibility to ensure that all product, assembly, material and 
                    process specifications reflect the latest revision levels. If Seller delivers non-conforming 
                    goods, MyOffsprings may at its option and at Seller’s expense: 

                      <li className="reg_as_sup_back-div-body-body-ul-li" >	Reject and return the goods for credit or refund </li>
                      <li className="reg_as_sup_back-div-body-body-ul-li" > Require Seller to promptly correct or replace the goods </li>
                      <li className="reg_as_sup_back-div-body-body-ul-li" > Correct the goods </li>
                      <li className="reg_as_sup_back-div-body-body-ul-li" > 
                        Obtain replacement goods from another source.
                        Seller shall not redeliver corrected or rejected 
                        goods without disclosing the former rejection or requirement 
                        for correction. Seller shall disclose any corrective action taken. 
                        Repair, replacement and other correction and redelivery shall be 
                        completed within the original delivery schedule or such later time as. 
                        All costs, expenses and loss of value incurred as a result of or in 
                        connection with nonconformance and repair, replacement or other correction 
                        may be recovered from Seller by equitable price reduction or credit against 
                        any amounts that may be owed to Seller under this purchase order or another.
                      </li>


                </div>
            
            </div>

            <div className="reg_as_sup_back-div-btm" >

              <button className="reg_as_sup_back-div-btm-btn reg_as_sup_back-div-btm-cancel" onClick={ props.cancel } > Cancel </button>
              <button className="reg_as_sup_back-div-btm-btn reg_as_sup_back-div-btm-accept" onClick={ props.accept } > I Accept </button>

            </div>

        </div>
      );

}