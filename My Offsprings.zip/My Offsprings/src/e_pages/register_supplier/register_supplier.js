import React,{useState} from 'react';
import { InputWithLabel, LoginBtn, LoginTextarea, BoxMessage } from '../../component/login_components/login_components';
import Axios from 'axios';
import { Comp } from './comp';

const RegisterSupplierPage = (props) => {
 
    const [ RegDetails , setRegDetails] = useState({
        name:'',
        description:'',
        email:'',
        city:'',
        address:'',
        phone_number:'',
    })

    const [ Error , setError ] = useState({
        value:false,
        msg:''
    })

    const [ successful , setsuccessful ] = useState(false)

    const [ Loading , setLoading ] = useState(false)

    const [ openterms , setopenterms ] = useState(false)


    const RegistrationHandler = () => {

        setopenterms(false)

        setLoading(true)

        setError({
            value:false,
            msg:''
        })

        if ( RegDetails.name === '' || RegDetails.description === '' || RegDetails.email === '' || RegDetails.phone_number === '' || RegDetails.city === '' || RegDetails.address === '' ) {
            setError({
                value:true,
                msg:'All Fields Must Be Filled'
            })
            setLoading(false)
        }else{

            Axios.post('/suppliers/rsupplier/',RegDetails).then(

                response => {
                    setLoading(false)
                    setRegDetails({
                        name:'',
                        description:'',
                        email:'',
                        city:'',
                        address:'',
                        phone_number:'',
                    })
                    setsuccessful(true)
                }

            ).catch( e => {
                setError({
                    value:true,
                    msg:'All Fields Must Be Filled'
                })
            } )

        }

    }


    const openTermsHandler = (e) => {

        e.preventDefault()
        setopenterms(true)

    }

      return ( 
        <>

        { openterms ? 
        
            <div className="reg_as_sup_back" >
                <Comp 
                    cancel={ () => setopenterms(false) }
                    accept={ RegistrationHandler }
                />
            </div>

        : null }

        <div className="register_as_sup_mid" >

            { !successful ? 
            
            <div className="login_page_template_right" >
            <div className="login_page_template_mid" >
                <div className="login_page_template_mid_top" >
                    Request
                    <br/>
                    To be a Supplier
                </div>

                { Error ? 
                    <div className="login_page_template_mid_error" >
                        {Error.msg}
                    </div> : null }

                <form className="login_page_template_mid_form" onSubmit={openTermsHandler} >

                    <InputWithLabel label="Full Name" type="text" 
                        value={RegDetails.name} 
                        onChange={ (event) => setRegDetails({...RegDetails,name:event.target.value}) } />


                    <InputWithLabel label="Email" type="email" 
                        value={RegDetails.email} 
                        onChange={ (event) => setRegDetails({...RegDetails,email:event.target.value}) }/>

                    <InputWithLabel label="Phone Number" type="text"
                        value={RegDetails.phone_number} 
                        onChange={ (event) => setRegDetails({...RegDetails,phone_number:event.target.value}) }/>
                    
                    <LoginTextarea label="What Do You Sell?"
                         value={RegDetails.description} 
                         onChange={ (event) => setRegDetails({...RegDetails,description:event.target.value}) }/>                    

                    <InputWithLabel label="State" type="text"
                        value={RegDetails.city} 
                        onChange={ (event) => setRegDetails({...RegDetails,city:event.target.value}) }/>

                    <LoginTextarea label="Shop Address" 
                        value={RegDetails.address} 
                        onChange={ (event) => setRegDetails({...RegDetails,address:event.target.value}) }/>
                    

                    <LoginBtn value="Submit Request" disabled={Loading} />

                </form>

            </div>
            </div>

            : <BoxMessage 
                title="Request To Be A Supplier"        
                story="Your request to be a supplier was recieved succesfully. We would contact you after 
                reviewing your request via email or phone number , to tell you when we would come and inspect your shop or store"
                />
            
            }

        </div>

         </>
      );

}

export default RegisterSupplierPage;