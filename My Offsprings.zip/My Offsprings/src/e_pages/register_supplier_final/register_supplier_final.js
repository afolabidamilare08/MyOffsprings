import React,{useState} from 'react';
import { InputWithLabel, LoginBtn, LoginTextarea, BoxMessage } from '../../component/login_components/login_components';
import Axios from 'axios';

const RegisterSupplierPageFinal = (props) => {
 
    const [ RegDetails , setRegDetails] = useState({
        supplier_name:'',
        description:'',
        phone_no:'',
        city:'',
        address:'',
        account_no:'',
        account_name:'',
        bank_name:'',
    })

    const [ Error , setError ] = useState({
        value:false,
        msg:''
    })

    const [ successful , setsuccessful ] = useState(false)

    const [ Loading , setLoading ] = useState(false)


    const RegistrationHandler = (e) => {

        e.preventDefault()

        setLoading(true)

        setError({
            value:false,
            msg:''
        })

        if ( RegDetails.supplier_name === '' 
        || RegDetails.description === '' 
        || RegDetails.phone_no === '' 
        || RegDetails.city === '' 
        || RegDetails.address === ''
        || RegDetails.account_no === ''
        || RegDetails.account_name === ''
        || RegDetails.bank_name === '' ) {
            setError({
                value:true,
                msg:'All Fields Must Be Filled'
            })
            setLoading(false)
        }else{

            Axios.post('/suppliers/mysuppliers/',RegDetails).then(

                response => {
                    setLoading(false)
                    setRegDetails({
                        supplier_name:'',
                        description:'',
                        phone_no:'',
                        city:'',
                        address:'',
                        account_no:'',
                        account_name:'',
                        bank_name:'',
                    })
                    setsuccessful(true)
                }

            ).catch( e => {
                setError({
                    value:true,
                    msg:'Something Went Wrong'
                })
            } )

        }

    }

      return ( 
        <>

        <div className="register_as_sup_mid" >

            { !successful ? 
            
            <div className="login_page_template_right" >
            <div className="login_page_template_mid" >
                <div className="login_page_template_mid_top" >
                    Register
                    <br/>
                    as a Supplier
                </div>

                { Error ? 
                    <div className="login_page_template_mid_error" >
                        {Error.msg}
                    </div> : null }

                <form className="login_page_template_mid_form" onSubmit={RegistrationHandler} >

                    <InputWithLabel label="Full Name" type="text" 
                        value={RegDetails.supplier_name} 
                        onChange={ (event) => setRegDetails({...RegDetails,supplier_name:event.target.value}) } />

                    <InputWithLabel label="Phone Number" type="text"
                        value={RegDetails.phone_no} 
                        onChange={ (event) => setRegDetails({...RegDetails,phone_no:event.target.value}) }/>
                    
                    <LoginTextarea label="What Do You Sell?"
                         value={RegDetails.description} 
                         onChange={ (event) => setRegDetails({...RegDetails,description:event.target.value}) }/>                    

                    <InputWithLabel label="City" type="text"
                        value={RegDetails.city} 
                        onChange={ (event) => setRegDetails({...RegDetails,city:event.target.value}) }/>

                    <LoginTextarea label="Shop Address" 
                        value={RegDetails.address} 
                        onChange={ (event) => setRegDetails({...RegDetails,address:event.target.value}) }/>

                    <InputWithLabel label="Account Number" 
                        value={RegDetails.account_no} 
                        onChange={ (event) => setRegDetails({...RegDetails,account_no:event.target.value}) }/>
                    
                    <InputWithLabel label="Account Name" 
                        value={RegDetails.account_name} 
                        onChange={ (event) => setRegDetails({...RegDetails,account_name:event.target.value}) }/>

                        
                    <InputWithLabel label="Bank Name" 
                        value={RegDetails.bank_name} 
                        onChange={ (event) => setRegDetails({...RegDetails,bank_name:event.target.value}) }/>

                    <LoginBtn value="Register" disabled={Loading} />

                </form>

            </div>
            </div>

            : <BoxMessage 
                title="Request To Be A Supplier"        
                story="You have succesfully registered as a supplier"
                />
            
            }

        </div>

      </>
      );

}

export default RegisterSupplierPageFinal;