import React , {useEffect,useState} from 'react';
import LoadingPage from '../../component/utilities/loading/loading';
import OppsPage from '../../component/utilities/oppspage/oppspage';
import Axios from 'axios';

const RSupplier = (props) => {

    const [ RSupplier , setRSupplier ] = useState(null)
    const [ Errorpage , setErrorpage ] = useState(false)
    const [ Loading , setLoading ] = useState(false)

    useEffect( () => {

        setErrorpage(false)
        setLoading(true)

        Axios.get( '/suppliers/mysuppliers/?limit=1000&offset=0' ).then(

            response => {
                setRSupplier(response.data.results)
                setErrorpage(false)
                setLoading(false)
            }

        ).catch(
            e => {
                setErrorpage(true)
                setLoading(false)        
            }
        )

    },[] )


    const gogo = () => {
        props.history.go()
    } 

    const goBack = () => {
        props.history.goBack()
    }

    
    if ( !RSupplier && !Errorpage && Loading ) {
        var todisplay = <LoadingPage/>
    }else{
        if ( !RSupplier && Errorpage && !Loading ) {
            todisplay = <OppsPage tryagain={gogo} goback={goBack} />
        }else{
            if ( RSupplier && !Errorpage && !Loading ) {
                 todisplay = <>

                    { RSupplier.length > 0 ? 
                    
                        RSupplier.map((sup,index) => {

                            return <div key={index} className="new_supplier-div-list" >

                                        <div className="new_supplier-div-list-part" >
                                            <span className="new_supplier-div-list-part-1" >Supplier Name:</span>
                                            <span className="new_supplier-div-list-part-2" > { sup.supplier_name } </span>
                                        </div>

                                        <div className="new_supplier-div-list-part" >
                                            <span className="new_supplier-div-list-part-1" >Product Selling:</span>
                                            <span className="new_supplier-div-list-part-2" > { sup.description } </span>
                                        </div>

                                        <div className="new_supplier-div-list-part" >
                                            <span className="new_supplier-div-list-part-1" >Email:</span>
                                            <span className="new_supplier-div-list-part-2" > { sup.email } </span>
                                        </div>

                                        <div className="new_supplier-div-list-part" >
                                            <span className="new_supplier-div-list-part-1" >Phone Number:</span>
                                            <span className="new_supplier-div-list-part-2" > { sup.phone_number } </span>
                                        </div>

                                        <div className="new_supplier-div-list-part" >
                                            <span className="new_supplier-div-list-part-1" >State:</span>
                                            <span className="new_supplier-div-list-part-2" > { sup.city } </span>
                                        </div>

                                        <div className="new_supplier-div-list-part" >
                                            <span className="new_supplier-div-list-part-1" >Address:</span>
                                            <span className="new_supplier-div-list-part-2" > { sup.address } </span>
                                        </div>

                                        <div className="new_supplier-div-list-part" >
                                            <span className="new_supplier-div-list-part-1" >Approved On:</span>
                                            <span className="new_supplier-div-list-part-2" > { sup.approved_on } </span>
                                        </div>

                                        <div className="new_supplier-div-list-part" >
                                            <span className="new_supplier-div-list-part-1" >Account Name:</span>
                                            <span className="new_supplier-div-list-part-2" > { sup.account_name } </span>
                                        </div>

                                        <div className="new_supplier-div-list-part" >
                                            <span className="new_supplier-div-list-part-1" >Account Number:</span>
                                            <span className="new_supplier-div-list-part-2" > { sup.account_no } </span>
                                        </div>

                                        <div className="new_supplier-div-list-part" >
                                            <span className="new_supplier-div-list-part-1" >Bank Name:</span>
                                            <span className="new_supplier-div-list-part-2" > { sup.bank_name } </span>
                                        </div>

                                    </div>

                        } )

                    : <div style={{
                        textAlign:'center'
                    }} > No One Has Registered To Be A Supplier </div> }

                 </>    
            }
        }  
    }


    return (

            <div className="new_supplier-div" >

                {todisplay}

            </div>
    );
}

export default RSupplier;