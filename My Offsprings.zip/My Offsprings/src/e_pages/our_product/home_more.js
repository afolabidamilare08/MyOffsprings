import React,{useState,useEffect} from 'react';
import LoadingPage from '../../component/utilities/loading/loading';
import OppsPage from '../../component/utilities/oppspage/oppspage';
import { BsArrowLeftShort, BsArrowRightShort } from 'react-icons/bs';
import Axios from 'axios';
import {EmptyProduct} from '../../component/utilities/empty/no_product';
import { Link } from 'react-router-dom';
import { IndexHomeProductList2 } from '../Index_folder/utilities/utilities';
import CategoryLeft2 from '../categoy-left/category-left2';
import {AiOutlinePlus,AiFillStar,AiOutlineStar} from 'react-icons/ai';
import { LoginBtn } from '../../component/login_components/login_components';
import BtnSpin from '../../component/utilities/btnSpin/btnSpin';

const OurIndexMorePage = (props) => {

    const offset = props.match.params.offset
    var newoffset = parseInt(props.match.params.offset) + 24
    var oldoffset = parseInt(props.match.params.offset) - 24

    const [ Allproduct , setAllproduct ] = useState(null)
    const [ Errorpage , setErrorpage ] = useState(false)
    const [ Loading , setLoading ] = useState(false)
    const [ productcount , setproductcount ] = useState({
        count:null,
        previous:null,
        next:null
    })

    const [ openModal , setopenModal ] = useState({
        value:false,
        star:0,
        loading:false,
        product:'',
        msg:{
            color:'',
            value:''
        }
    })

    useEffect( () => {

        setErrorpage(false)
        setLoading(true)

        Axios.get('myproduct/allproduct/?limit=24&offset=' + offset ).then(

            response => {
                setAllproduct(response.data.results)
                setErrorpage(false)
                setLoading(false)
                setproductcount({
                    count:response.data.count,
                    previous:response.data.previous,
                    next:response.data.next
                })
            }

        ).catch(
            e => {
                setErrorpage(true)
                setLoading(false)        
            }
        )

    },[offset] )

    const gogo = () => {
        props.history.go()
    } 

    const goBack = () => {
        props.history.goBack()
    }

    
    if ( !Allproduct && !Errorpage && Loading ) {
        var todisplay = <LoadingPage/>
    }else{
        if ( !Allproduct && Errorpage && !Loading ) {
            todisplay = <OppsPage tryagain={gogo} goback={goBack} />
        }else{
            if ( Allproduct && !Errorpage && !Loading ) {
                 todisplay = <>
                            
                            { Allproduct.length > 0 ? <>

                                { Allproduct.map( ( product , index ) => {

                                    return (
                                        <IndexHomeProductList2
                                            key={index}
                                            productname={product.myproduct_name}
                                            img={product.product_img1}
                                            price={product.selling_price}
                                            avg_rating={product.avg_rating}
                                            to={'/editproduct/' + product.slug + '/' + product.id}
                                            edit
                                            rate={ () => setopenModal({
                                                ...openModal,
                                                value:true,
                                                product:product.id,
                                            }) }
                                        />
                                    );

                                } ) }

                            </> : <EmptyProduct/> }

                            <div className="pagination-div" >
                                
                                { productcount.previous ?
                                
                                    <Link 
                                    className="pagination-div-link pagination-div-link2"
                                    to={oldoffset === 0 ? '/ourproducts'  : '/ourproducts/products/' + oldoffset  } > <BsArrowLeftShort 
                                    className="pagination-div-link2-ic" /> Previous page </Link>

                                    : null

                                }

                                { productcount.next ? 

                                    <Link 
                                    className="pagination-div-link" 
                                    to={'/ourproducts/products/' + newoffset } > Next page 
                                    <BsArrowRightShort 
                                    className="pagination-div-link-ic" /> </Link>
                                    : null

                                }

                            </div>

                 </>
            }
        }  
    }


    const rAteProuctHandler = (e) => {

        e.preventDefault()

        setopenModal({
            ...openModal,
            loading:true,
            msg:{
                value:'',
                color:''
            }
        })

        if ( openModal.star < 1 ) {
            setopenModal({
                ...openModal,
                loading:false,
                msg:{
                    value:'Rate Product',
                    color:''
                }
            })
        }else{

          Axios.post('/myproduct/myproduct/' + openModal.product + '/rate_myproduct/',{stars:openModal.star}).then(

            response => {
                setopenModal({
                    ...openModal,
                    loading:false,
                    msg:{
                        value:'Product Rated',
                        color:'green'
                    }
                })

            }

          ).catch(
            e => {
                setopenModal({
                    ...openModal,
                    loading:false,
                    msg:{
                        value:'Something Went Wrong',
                        color:'red'
                    }
                })
            }
          )
        }

      }


      return ( 

            <>

            <div className="home-div" >

                <div className="for-category" > 
                    <CategoryLeft2/>
                </div>

                <div className="product_container" >
                    {todisplay}
                </div>

            </div>

            <div className="add-star-black" style={{

display: openModal.value ? 'block' : 'none'

}} onClick={ () => setopenModal({
...openModal,
value:false
}) } >

</div>


            <div className="add-star-black-mid" style={{

            display: openModal.value ? 'block' : 'none'

            }}  >

            <div className="add-star-black-mid-top" >
            <div className="add-star-black-mid-top-left" > Rate Product </div>

            <AiOutlinePlus className="add-star-black-mid-top-right" onClick={ () => setopenModal({
                ...openModal,
                value:false
            }) } />
            </div>

            <form className="add-star-black-mid-form" onSubmit={rAteProuctHandler} >

            <div className="add-star-black-mid-form-msg" style={{color:openModal.msg.color}} > { openModal.msg.value } </div>

            <div className="add-star-black-mid-form-top" >
            { openModal.star > 0 ?
                
                <AiFillStar className="rate_product-div-body-stars-star" onClick={ () => setopenModal({
                    ...openModal,
                    value:true,
                    star:1
                }) } />

                :<AiOutlineStar className="rate_product-div-body-stars-star" onClick={ () => setopenModal({
                    ...openModal,
                    value:true,
                    star:1
                }) } />

                }

            { openModal.star > 1 ?

                <AiFillStar className="rate_product-div-body-stars-star" onClick={ () => setopenModal({
                    ...openModal,
                    star:2
                }) } />

                :<AiOutlineStar className="rate_product-div-body-stars-star" onClick={ () => setopenModal({
                    ...openModal,
                    star:2
                }) } />}

            { openModal.star > 2 ?

                <AiFillStar className="rate_product-div-body-stars-star" onClick={ () => setopenModal({
                    ...openModal,
                    star:3
                }) } />

                :<AiOutlineStar className="rate_product-div-body-stars-star" onClick={ () => setopenModal({
                    ...openModal,
                    star:3
                }) } />}

            { openModal.star > 3 ?

                <AiFillStar className="rate_product-div-body-stars-star" onClick={ () => setopenModal({
                    ...openModal,
                    star:4
                }) } />

                :<AiOutlineStar className="rate_product-div-body-stars-star" onClick={ () => setopenModal({
                    ...openModal,
                    star:4
                }) } />}

            { openModal.star > 4 ?

                <AiFillStar className="rate_product-div-body-stars-star" onClick={ () => setopenModal({
                    ...openModal,
                    star:5
                }) } />

                :<AiOutlineStar className="rate_product-div-body-stars-star" onClick={ () => setopenModal({
                    ...openModal,
                    star:5
                }) } />}
            </div>

            <LoginBtn value={
                                    openModal.loading ? <BtnSpin bgColor="white" /> : 'Rate Product'
                                } />

            </form>

            </div>



            </>
        
      );

}

export default OurIndexMorePage;