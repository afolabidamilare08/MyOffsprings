import React,{useState} from 'react';
import { InputWithLabel, LoginBtn } from '../../component/login_components/login_components';

const ChangePasswordPage = (props) => {


    const [ ResetDetail , setResetDetail] = useState({
        password:'',
        repeat_password:''
    })

    const [ Error , setError ] = useState({
        value:false,
        msg:''
    })

    const [ Loading , setLoading ] = useState(false)

    const ResetHandler = (e) =>{

        setLoading(true)
        setError({
            value:false,
            msg:''
        })

        e.preventDefault()

        if ( ResetDetail.password === '' || ResetDetail.repeat_password === '' ) {
            setError({
                value:true,
                msg:'All Fileds Must Be Filled'
            })
            setLoading(false)
        }else{

            if ( ResetDetail.password !== ResetDetail.repeat_password ) {
                setError({
                    value:true,
                    msg:"Password And Reapet Password Don't March"
                })
                setLoading(false)
            }

        }

    }

      return ( 
        <>

        <div className="login_page_template" >

            <div className="login_page_template_left" >
                {/* <img src={Babyimg} className="login_page_template_left_img" alt="" /> */}
            </div>

            <div className="login_page_template_right" >

            <div className="login_page_template_mid" >
                <div className="login_page_template_mid_top" >
                    Change Password
                </div>

                { Error ? 
                    <div className="login_page_template_mid_error" >
                        {Error.msg}
                    </div> : null }

                <form onSubmit={ResetHandler} className="login_page_template_mid_form" >

                    <InputWithLabel label="New Password" type="password"
                         value={ResetDetail.email}
                         onChange={ (event) => setResetDetail({...ResetDetail, password:event.target.value }) } 
                         />

                    <InputWithLabel label="Repeat Password" type="passwprd"
                         value={ResetDetail.email}
                         onChange={ (event) => setResetDetail({...ResetDetail, repeat_password:event.target.value }) } 
                         />   

                    
                    <LoginBtn value="Change Password" disabled={Loading} />

                </form>
            </div>


            </div>

        </div>

      </>
      );

}

export default ChangePasswordPage;