import React,{useState} from 'react';
import { InputWithLabel, LoginBtn } from '../../component/login_components/login_components';

const ResetPage = (props) => {


    const [ ResetDetail , setResetDetail] = useState({
        email:'',
    })

    const [ Error , setError ] = useState({
        value:false,
        msg:''
    })

    const [ Loading , setLoading ] = useState(false)

    const ResetHandler = (e) =>{

        setLoading(true)
        setError({
            value:false,
            msg:''
        })

        e.preventDefault()

        if ( ResetDetail.email === '' ) {
            setError({
                value:true,
                msg:'Please Enter Your Email'
            })
            setLoading(false)
        }else{

        }

    }

      return ( 
        <>

        <div className="login_page_template" >

            <div className="login_page_template_left" >
                {/* <img src={Babyimg} className="login_page_template_left_img" alt="" /> */}
            </div>

            <div className="login_page_template_right" >

            <div className="login_page_template_mid" >
                <div className="login_page_template_mid_top" >
                    Reset Password
                </div>

                { Error ? 
                    <div className="login_page_template_mid_error" >
                        {Error.msg}
                    </div> : null }

                <form onSubmit={ResetHandler} className="login_page_template_mid_form" >

                    <InputWithLabel label="Email" type="email"
                         value={ResetDetail.email}
                         onChange={ (event) => setResetDetail({...ResetDetail, email:event.target.value }) } 
                         />

                    <div className="login_page_template_mid_form_reset-narrations" >
                        The link to the password reset page would be sent to the email provided above
                    </div>     

                    
                    <LoginBtn value="Send Link To Email" disabled={Loading} />

                </form>
            </div>


            </div>

        </div>

      </>
      );

}

export default ResetPage;