import React,{useState,useContext} from 'react';
import {Link} from 'react-router-dom';
import Axios from 'axios';
import { InputWithLabel, LoginBtn } from '../../component/login_components/login_components';
import Store from '../../store/managementstore/managementstore';
import BtnSpin from '../../component/utilities/btnSpin/btnSpin';
// import {GoogleLogin} from 'react-google-login';

const LoginPage = (props) => {

    const context = useContext(Store)

    const [ LoginDetails , setLoginDetails] = useState({
        email:'',
        password:''
    })

    const [ Error , setError ] = useState({
        value:false,
        msg:''
    })

    const [ Loading , setLoading ] = useState(false)
    // const GOOGLE_API_KEY = process.env.REACT_APP_GOOGLE_LOGIN_KEY

    const LoginHandlerform = (e) =>{

        setLoading(true)
        setError({
            value:false,
            msg:''
        })

        e.preventDefault()

        if ( LoginDetails.email === '' || LoginDetails.password === '' ) {
            setError({
                value:true,
                msg:'All Fileds Must Be Filled'
            })
            setLoading(false)
        }else{

            var passwordlength = LoginDetails.password.length

            var usernamelength = LoginDetails.email.length
  
  
            if( LoginDetails.password[passwordlength-1] === ' ' || LoginDetails.email[usernamelength-1] === ' ' ){
              
                setError({
                    value:true,
                    msg:'Please remove the space behind your password or username'
                })
                setLoading(false)
  
            }else{

                var senddata = {
                     username:LoginDetails.email,
                     password:LoginDetails.password
                }

                Axios.post('/myaccount/login/',senddata).then(

                    response => {
                        setLoginDetails({
                            email:'',
                            password:''
                        })
                        Savedata(response.data)
                        props.history.goBack()
                    }

                ).catch( (error) => {
                    setLoading(false)
                    if(error.response){
        
                        if(error.response.data.error){
                          setError({
                            value:true,
                            msg:'Invalid Username or password',

                          })
                        }
            
                    }
                } );

            }

        }

    }

    const Savedata = (response) => {
        localStorage.setItem('offspring-token',response.token)
        localStorage.setItem('offspring-userid',response.id)
        context.Loginhandler(response)
    }

    // const responseGoogle = (response) => {
    //     console.log(response);  


    //     Axios.post('/myaccount/google1/',{token:response.profileObj.tokenId}).then(
    //         response => {

    //         }
    //     )v

    // }

      return ( 
        <>

        <div className="login_page_template" >

            <div className="login_page_template_left" >
                {/* <img src={Babyimg} className="login_page_template_left_img" alt="" /> */}
            </div>

            <div className="login_page_template_right" >

            <div className="login_page_template_mid" >
                <div className="login_page_template_mid_top" >
                    Sign In
                </div> 

                { Error ? 
                    <div className="login_page_template_mid_error" >
                        {Error.msg}
                    </div> : null }

                <form onSubmit={LoginHandlerform} className="login_page_template_mid_form" >

                    <InputWithLabel label="Email/Username" type="text"
                         value={LoginDetails.email}
                         onChange={ (event) => setLoginDetails({...LoginDetails, email:event.target.value }) } 
                         />

                    <InputWithLabel label="Password" type="password"
                         value={LoginDetails.password}
                         onChange={ (event) => setLoginDetails({...LoginDetails, password:event.target.value }) } 
                         />

                    <Link className="login_page_template_mid_form_forgot" to="/" > Forgot Password ? </Link>     
                    
                    { Loading ? <><br/><BtnSpin bgColor="rgb(9, 123, 184)" /></> :
                        
                        <LoginBtn value="Sign In" disabled={Loading} /> 

                    }

                </form>
                <div className="login_page_template_mid_or" >
                    <div className="login_page_template_mid_or_line" ></div>
                    <div className="login_page_template_mid_or_text" > or </div>
                    <div className="login_page_template_mid_or_line" ></div>
                </div>
                {/* <div className="login_page_template_mid_social" >
                    <div className="login_page_template_mid_social_top" > Sign in with </div>
                    <div className="login_page_template_mid_social_list" >
                        <button className="login_page_template_mid_social_list_link" >
                            <FaGoogle className="login_page_template_mid_social_list_link-ic"/>
                        </button>
                        <Link to="/" className="login_page_template_mid_social_list_link" ></Link>
                        <Link to="/" className="login_page_template_mid_social_list_link" ></Link>
                                <GoogleLogin
                                    clientId={GOOGLE_API_KEY}
                                    onSuccess={responseGoogle}
                                    onFailure={responseGoogle}
                                    isSignedIn={false}
                                />
                   </div>
                </div> */}

                <Link className="login_page_template_mid_already" to="/signup" > I Don't Have An Account Yet </Link>

            </div>


            </div>

        </div>

      </>
      );

}

export default LoginPage;