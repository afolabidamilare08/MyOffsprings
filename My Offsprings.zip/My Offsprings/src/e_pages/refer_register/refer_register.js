import React,{useState,useContext} from 'react';
import {Link} from 'react-router-dom';
import { InputWithLabel, LoginBtn } from '../../component/login_components/login_components';
import Axios from 'axios';
import Store from '../../store/managementstore/managementstore';

const ReferRegister = (props) => {

    const context = useContext(Store)

    const [ RegDetails , setRegDetails] = useState({
        first_name:'',
        last_name:'',
        user_name:'',
        email:'',
        password:'',
        password_repeat:''
    })

    const [ Error , setError ] = useState({
        value:false,
        msg:''
    })

    const [ Loading , setLoading ] = useState(false)


    const RegistrationHandler = (e) => {

        e.preventDefault()

        setLoading(true)

        setError({
            value:false,
            msg:''
        })

        if ( RegDetails.first_name === '' || RegDetails.last_name === '' || RegDetails.email === '' || RegDetails.user_name === '' || RegDetails.password === '' || RegDetails.password_repeat === '' ) {
            setError({
                value:true,
                msg:'All Fields Must Be Filled'
            })
            setLoading(false)
        }else{

            if ( RegDetails.password !== RegDetails.password_repeat ) {
                setError({
                    value:true,
                    msg:"Repeat Password And Password Don't Match"
                })
                setLoading(false)
            }

            else{

                var senddata = {
                    first_name:RegDetails.first_name,
                    last_name:RegDetails.last_name,
                    email:RegDetails.email,
                    username:RegDetails.user_name,
                    password:RegDetails.password,
                }

                Axios.post('/myaccount/user/',senddata).then(
                    response => {

                        var new_userId = response.data.id;

                            Axios.post('/myaccount/login/',{username:senddata.username,password:senddata.password}).then(

                                response => {

                                    Savedata(response.data)

                                    Axios.patch('/myaccount/myprofile/' + new_userId + '/' , {referer:props.match.params.id} ).then(

                                        response => {
                                            setRegDetails({
                                                first_name:'',
                                                last_name:'',
                                                user_name:'',
                                                email_address:'',
                                                password:'',
                                                confirm_password:''
                                            })
            
                                            setLoading(false)
            
                                            props.history.push('/signin')
                                        }).catch( 
                                            e => {
                                            setError({
                                                value:true,
                                                msg:'Something Went Wrong'
                                            })
                                        })
                                            
                                            
                                }).catch(
                                    e => {
                                        setError({
                                            value:true,
                                            msg:'Something Went Wrong'
                                        })
                                    })

                } ).catch( 
                    
                    (error) => {
                        setLoading(false)
                        if(error.response){
                
                            if(error.response.data.email){
                            setError({
                                value:true,
                                msg:error.response.data.email[0]
                            })
                            }
                
                            if(error.response.data.username){
                            setError({
                                value:true,
                                msg:error.response.data.username[0]
                            })
                                }
                
                        }else{
                            setError({
                                value:true,
                                msg:'Something Went Wrong Please Try Again'
                            })
                        }
                    } );

                 }

        }

    }

    const Savedata = (response) => {
        localStorage.setItem('offspring-token',response.token)
        localStorage.setItem('offspring-userid',response.id)
        context.Loginhandler(response)
    }

      return ( 
        <>

        <div className="login_page_template" >

            <div className="login_page_template_right" >
            <div className="login_page_template_mid" >
                <div className="login_page_template_mid_top" >
                    Sign Up
                </div>

                { Error ? 
                    <div className="login_page_template_mid_error" >
                        {Error.msg}
                    </div> : null }

                <form className="login_page_template_mid_form" onSubmit={RegistrationHandler} >

                    <InputWithLabel label="First Name" type="text" 
                             value={RegDetails.first_name} 
                             onChange={ (event) => setRegDetails({...RegDetails,first_name:event.target.value}) } />

                    <InputWithLabel label="Last Name" type="text" 
                             value={RegDetails.last_name} 
                             onChange={ (event) => setRegDetails({...RegDetails,last_name:event.target.value}) }/>

                    <InputWithLabel label="Username" type="text" 
                             value={RegDetails.username} 
                             onChange={ (event) => setRegDetails({...RegDetails,user_name:event.target.value}) }/>

                    <InputWithLabel label="Email" type="email" 
                             value={RegDetails.email} 
                             onChange={ (event) => setRegDetails({...RegDetails,email:event.target.value}) }/>

                    <InputWithLabel label="Password" type="password"
                             value={RegDetails.password} 
                             onChange={ (event) => setRegDetails({...RegDetails,password:event.target.value}) } />

                    <InputWithLabel label="Repeat Password" type="password" 
                             value={RegDetails.password_repeat} 
                             onChange={ (event) => setRegDetails({...RegDetails,password_repeat:event.target.value}) }/>
                    
                    <LoginBtn value="Sign Up" disabled={Loading} />

                </form>
                {/* <div className="login_page_template_mid_or" >
                    <div className="login_page_template_mid_or_line" ></div>
                    <div className="login_page_template_mid_or_text" > or </div>
                    <div className="login_page_template_mid_or_line" ></div>
                </div>
                <div className="login_page_template_mid_social" >
                    <div className="login_page_template_mid_social_top" > Sign up with your social media account </div>
                    <div className="login_page_template_mid_social_list" >
                        <Link to="/" className="login_page_template_mid_social_list_link" ></Link>
                        <Link to="/" className="login_page_template_mid_social_list_link" ></Link>
                        <Link to="/" className="login_page_template_mid_social_list_link" ></Link>
                    </div>
                </div> */}
                <Link className="login_page_template_mid_already" to="/signin" > Already Have An Account </Link> 

            </div>
            </div>

        </div>

      </>
      );

}

export default ReferRegister;