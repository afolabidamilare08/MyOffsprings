import React,{useState,useEffect,useContext} from 'react';
import {CartItem} from './item';
import LoadingPage from '../../component/utilities/loading/loading';
import OppsPage from '../../component/utilities/oppspage/oppspage';
import Axios from 'axios';
import TopbannerDiv from '../../component/utilities/top-banner-msg/topbannermsg';
import { EmptyCartDiv } from '../../component/utilities/empty/no_product';
import Store from '../../store/managementstore/managementstore';

const CartPage = (props) => {

    const context = useContext(Store)

    const [ myCart , setmyCart ] = useState(null)
    const [ Loadingpage , setLoadingpage ] = useState(false)
    const [ Errorpage , setErrorpage ] = useState(false)
    const [ message , setmessage ] = useState({
        status:false,
        message:'',
        bgcolor:'orange'
      })
  

    useEffect( () => {

        setLoadingpage(true)
        setErrorpage(false)

        Axios.get( '/mycart/mycart/' ).then(

            response => {
                setLoadingpage(false)
                setErrorpage(false)
                setmyCart(response.data.results[0])
                console.log(response.data)
            }

        ).catch(

            e => {
                setLoadingpage(false)
                setErrorpage(true)        
            }

        )

    } , [] )













    const change_item_quantity = ( event , id ) => {

        const itemIndex = myCart.items.findIndex( i => {
          return i.product.id === id
        } )
    
          const item = {...myCart.items[itemIndex]}
    
          item.quantity = event.target.value
    
          const newlist = [...myCart.items]
    
          newlist[itemIndex] = item
    
          setmyCart({...myCart,items:newlist})    
  
      }









      const UpdateCartdetails = (id) => {

        setmessage({
          status:true,
          message:'Updating Cart .....',
          bgcolor:'orange'
        })
  
          const itemIndex = myCart.items.findIndex( i => {
            return i.product.id === id
          } )
    
          const item = {...myCart.items[itemIndex]}
  
  
          if( item.quantity < 1 ){
            setmessage({
              status:true,
              message:' Quantity Field Must Be Filled ' ,
              bgcolor:'red'
            })
          }else{
  
            const quantityChange = { quantity:item.quantity , myproduct_id: id }
  
    
          Axios.put( '/mycart/mycart/' + myCart.id + '/add_to_cart/' , quantityChange ).then(
            response => {
                  Axios({ method: 'GET',url:'mycart/mycart/' })
                  .then( response => {
                      setmyCart({...myCart,get_total_cost:response.data.results[0].get_total_cost})
                      setmessage({
                        status:true,
                        message:'Your Cart Was Successfully Updated',
                        bgcolor:'rgb(39, 180, 39)'
                      })
                      } ).catch( e => {
                          setmessage({
                            status:true,
                            message:'something went wrong , try reloading the page and try again',
                            bgcolor:'red'
                          })
                      } )
            }
          ).catch( e => {
              setmessage({
                status:true,
                message:'something went wrong , try reloading the page and try again',
                bgcolor:'red'
              })
          } )
  
          }
  
      }







      const  remove_from_cart = ( productIndex , itemid ) => {
  
        setmessage({
          status:true,
          message:'Removing item.....',
          bgcolor:'orange'
        })
  
    
          const prodId = { myproduct_id: itemid }  
          Axios.post( '/mycart/mycart/' + myCart.id + '/remove_from_cart/' , prodId ).then(
            response => {
                // setmyCart({...myCart,get_total_cost:response.data.get_total_cost})

                const item = [ ...myCart.items ]

    
                item.splice(productIndex,1);
               setmyCart({...myCart,get_total_cost:response.data.get_total_cost,items:item})

              context.Refresh_Cart()

                setmessage({
                    status:true,
                    message:' One Item In Your Cart Was removed',
                    bgcolor:'rgb(39, 180, 39)'
                })
                
            }
           )
    
      }










      const moveForward = () => {

        if ( myCart.items.length > 0 ) {

          Axios.post( 'myorder/myorder/' , ''  ).then(

            response => {

              context.Refresh_Cart()
              props.history.push('/checkout_preview/' + response.data.id ) 

            }

          ).catch()

        }

      }







      const gogo = () => { 
        props.history.go()
      } 
    
      const goBack = () => {
        props.history.goBack()
      }
    
    
      if( Loadingpage && !myCart && !Errorpage ){
        var what_to_return = <LoadingPage/>
      }else{
        if ( !Loadingpage && Errorpage && !myCart ) {
          what_to_return = <OppsPage tryagain={gogo} goback={goBack} />
        }else{
          if ( !Loadingpage && !Errorpage && myCart ) {
            what_to_return = <>

        <TopbannerDiv
          closeshow={ () => setmessage({
            status:false,
            message:'',
            bgcolor:'orange'
          }) }
          show={ message.status }
          backgroundcolor={ message.bgcolor }
          message={ message.message } />
            
            <div className="cartpage_div" >

                    <div className="cartpage_div-top" > 
                        <div className="cartpage_div-top-1" > My Cart ({myCart.items.length}) </div>
                    </div>

                    { myCart.items.length > 0 ?  myCart.items.map( (item,index) => {

                        return <CartItem
                                key={index}
                                img={item.product.product_img1}
                                product_name={item.product.myproduct_name}
                                to={ '/product/' + item.product.slug + '/' + item.product.id } 
                                unit_price={ item.product.selling_price }
                                sub_total={ item.quantity * item.product.selling_price }  
                                changequantity={ (event) => change_item_quantity(event,item.product.id) }
                                product_quantity={ item.quantity }
                                updateItemquty={ () => UpdateCartdetails(item.product.id) }
                                removeItem={ () => remove_from_cart(index,item.product.id) }
                                color={ item.colour ? item.colour.colour : null }
                                size={ item.size ? item.size.size : null } 
                                disabled={ message.message === 'Updating Cart .....' || message.message === 'Removing item.....' ? true : false } />

                    } ) : <EmptyCartDiv/> }

                    { myCart ? 
                                
                            myCart.items.length > 0 ? 

                            <div className="cartpage-bttom-top" >

                                <div className="cartpage-bttom-top-right" >
                                    <div className="cartpage-bttom-top-right-det" >
                                        <div className="cartpage-bttom-top-right-det-1" >
                                            <span className="cartpage-bttom-top-right-det-1-total" >Total: </span> 
                                            <span className="cartpage-bttom-top-right-det-1-value" > ₦{new Intl.NumberFormat({ style: 'currency', currency: 'EUR' }).format(myCart.get_total_cost)}</span>
                                        </div>
                                        <div className="cartpage-bttom-top-right-det-2" >
                                            Transport fee not included yet
                                        </div>
                                    </div>
                                    <button className="cartpage-bttom-top-right-procced" onClick={ moveForward } > checkout</button>
                                </div>

                            </div>

                            : null

                            : null }
       
            </div>


            </>
          }
        }
      }

      return ( 
 
          <>

            {what_to_return}

          </>

      );

}

export default CartPage;