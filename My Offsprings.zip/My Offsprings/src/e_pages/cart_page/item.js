import React from 'react';
import {Link} from 'react-router-dom';
import Svg from '../../component/utilities/Svg';

const url = ''


export const CartItem = (props) => {

      return ( 

            <div className="cartitem-ind-div-details" >
                        
                <div className="cartitem-ind-div-details-first" >

                    <div className="cartitem-ind-div-details-first-picture" >
                        <img src={url+props.img} alt="" className="cartitem-ind-div-details-first-picture-img" />
                    </div>

                    <div className="cartitem-ind-div-details-first-info" >
                    
                        <div className="cartitem-ind-div-details-first-info-prodname" > 
                
                            <Link to={props.to} className="cartitem-ind-div-details-first-info-prodname-1" > {props.product_name} </Link>

                            { props.size ? 
                            
                                <div className="cartitem-ind-div-details-first-info-prodname-qty" >
                                    <span className="cartitem-ind-div-details-first-info-prodname-qty-1" > size : </span> 
                                    <span className="cartitem-ind-div-details-first-info-prodname-qty-2" > {props.size} </span>
                                </div>
                            
                            : null }

                            { props.color ? 
                            
                                <div className="cartitem-ind-div-details-first-info-prodname-qty" >
                                    <span className="cartitem-ind-div-details-first-info-prodname-qty-1" > color : </span> 
                                    <span className="cartitem-ind-div-details-first-info-prodname-qty-2" > {props.color} </span>
                                </div>
                            
                            : null }

                        </div>

                        <div className="cartitem-ind-div-details-first-info-remove" > 

                            <button disabled={props.disabled} className="cartitem-ind-div-details-first-info-remove-btn" onClick={props.removeItem} >
                                <Svg
                                className="cartitem-ind-div-details-first-info-remove-btn-ic"
                                href="sprite3.svg#icon-delete" />
                                remove
                            </button>

                        </div>

                    </div>

                </div>

                <div className="cartitem-ind-div-details-second" >
            
                    <div className="cartitem-ind-div-details-second-qty" >

                        <div className="cartitem-ind-div-details-second-qty-1" >
                            Quantity
                        </div>

                        <div className="cartitem-ind-div-details-second-qty-2" >
                            <input className="cartitem-ind-div-details-second-qty-2-input" value={props.product_quantity} onChange={props.changequantity}  />
                        </div>

                        <button disabled={props.disabled} onClick={ props.updateItemquty } className="cartitem-ind-div-details_update_button" >
                            Update
                        </button>

                    </div>
            
                    <div className="cartitem-ind-div-details-second-price" >
                        <div className="cartitem-ind-div-details-second-price-1" > price </div>
                        <div className="cartitem-ind-div-details-second-price-2" > ₦{new Intl.NumberFormat({ style: 'currency', currency: 'EUR' }).format(props.unit_price)} </div>
                    </div>

                    <div className="cartitem-ind-div-details-second-subtotal" >
                        <div className="cartitem-ind-div-details-second-subtotal-1" > subtotal </div>
                        <div className="cartitem-ind-div-details-second-subtotal-2" > ₦{new Intl.NumberFormat({ style: 'currency', currency: 'EUR' }).format(props.sub_total)} </div>
                    </div>

                </div>

            </div>

      );

}
























export const OrderItem = (props) => {

    return ( 

          <div className="orderititem-ind-div-details" style={{
              width:'100%'
          }} >
                      
              <div className="orderititem-ind-div-details-first" >

                  <div className="orderititem-ind-div-details-first-picture" >
                      <img src={url+props.img} alt="" className="orderititem-ind-div-details-first-picture-img" />
                  </div>

                  <div className="orderititem-ind-div-details-first-info" >
                  
                      <div className="orderititem-ind-div-details-first-info-prodname" > 
              
                          <Link to={props.to} className="orderititem-ind-div-details-first-info-prodname-1" > {props.product_name} </Link>

                          { props.size ? 
                          
                              <div className="orderititem-ind-div-details-first-info-prodname-qty" >
                                  <span className="orderititem-ind-div-details-first-info-prodname-qty-1" > size : </span> 
                                  <span className="orderititem-ind-div-details-first-info-prodname-qty-2" > {props.size} </span>
                              </div>
                          
                          : null }

                          { props.color ? 
                          
                              <div className="orderititem-ind-div-details-first-info-prodname-qty" >
                                  <span className="orderititem-ind-div-details-first-info-prodname-qty-1" > color : </span> 
                                  <span className="orderititem-ind-div-details-first-info-prodname-qty-2" > {props.color} </span>
                              </div>
                          
                          : null }

                            { props.rate_product ? 
                            
                                <div className="orderititem-ind-div-details-first-info-prodname-rate" onClick={props.rate_product} >
                                    Rate Product
                                    {/* <AiFillStar className="orderititem-ind-div-details-first-info-prodname-rate-ic" />
                                    <AiFillStar className="orderititem-ind-div-details-first-info-prodname-rate-ic" />
                                    <AiFillStar className="orderititem-ind-div-details-first-info-prodname-rate-ic" />
                                    <AiOutlineStar className="orderititem-ind-div-details-first-info-prodname-rate-ic" />
                                    <AiOutlineStar className="orderititem-ind-div-details-first-info-prodname-rate-ic" /> */}
                                </div>

                            : null}

                      </div>

                  </div>

              </div>

              <div className="orderititem-ind-div-details-second" >
          
                  <div className="orderititem-ind-div-details-second-qty" >

                      <div className="orderititem-ind-div-details-second-qty-1" >
                          Quantity
                      </div>

                      <div className="orderititem-ind-div-details-second-qty-2">
                          {props.quantity}
                      </div>


                  </div>
          
                  <div className="orderititem-ind-div-details-second-price" >
                      <div className="orderititem-ind-div-details-second-price-1" > price </div>
                      <div className="orderititem-ind-div-details-second-price-2" > ₦{new Intl.NumberFormat({ style: 'currency', currency: 'EUR' }).format(props.unit_price)} </div>
                  </div>

                  <div className="orderititem-ind-div-details-second-subtotal" >
                      <div className="orderititem-ind-div-details-second-subtotal-1" > subtotal </div>
                      <div className="orderititem-ind-div-details-second-subtotal-2" > ₦{new Intl.NumberFormat({ style: 'currency', currency: 'EUR' }).format(props.sub_total)} </div>
                  </div>

              </div>

          </div>

    );

}
