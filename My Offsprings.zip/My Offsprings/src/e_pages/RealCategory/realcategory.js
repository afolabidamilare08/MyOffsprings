import React, { useState , useEffect } from 'react';
import Axios from 'axios';
import { ProductsBox, IndexHomeProductList } from '../Index_folder/utilities/utilities';
import LoadingPage from '../../component/utilities/loading/loading';
import OppsPage from '../../component/utilities/oppspage/oppspage';
import {EmptyProduct} from '../../component/utilities/empty/no_product';
import IndexSlider from '../Index_folder/slider/slider';

const RealCategory = (props) => {

    const CategoryId = props.match.params.id

    const [ RCategory , setRCategory ] = useState(null)
    const [ Errorpage , setErrorpage ] = useState(false)
    const [ Loading , setLoading ] = useState(false)

    useEffect( () => {

        setErrorpage(false)
        setLoading(true)

        Axios.get('/myproduct/rcategory/' + CategoryId + '/' ).then(

            response => {

                setRCategory(response.data)
                setErrorpage(false)
                setLoading(false)

            }

        ).catch(

            e => {
                setErrorpage(true)
                setLoading(false)        
            }

        )

    } ,[CategoryId] )




    const gogo = () => {
        props.history.go()
    } 

    const goBack = () => {
        props.history.goBack()
    }




    if ( !RCategory && !Errorpage && Loading ) {
        var todisplay = <LoadingPage/>
    }else{
        if ( !RCategory && Errorpage && !Loading ) {
            todisplay = <OppsPage tryagain={gogo} goback={goBack} />
        }else{
            if ( RCategory && !Errorpage && !Loading ) {
                 todisplay = <>
                            
                            { RCategory ? <>

                                { RCategory.categories.map( ( rcategory , index ) => {

// console.log(rcategory)

                                    if ( rcategory.myproducts.length > 0 ) {
                                       
                                        var produce = []

                                        for (let r = 0; r < 5; r++) {
                                            if(rcategory.myproducts[r]){
                                                produce.push(rcategory.myproducts[r])
                                            }
                                        }

                                        return <ProductsBox
                                                    key={index}
                                                    title={rcategory.category_name}
                                                    to={ '/products/categories/category=' + rcategory.category_name  }
                                                    body={
                                                        <>
                                
                                                            { produce.map(( product , index ) => {
                                
                                                                return <IndexHomeProductList
                                                                        key={index}
                                                                        productname={product.myproduct_name}   
                                                                        img={product.product_img1}
                                                                        price={product.selling_price} 
                                                                        avg_rating={product.avg_rating}
                                                                        to={'/product/' + product.slug + '/' +product.id}
                                                                    />
                                                            } ) }
                                
                                                        </>
                                                    }
                                                />
                                        
                                    }else{
                                        return null
                                    }

                                } ) }

                            </> : <EmptyProduct/> }

                 </>
            }
        }  
    }










    return (
            <>
                
                <div className="grace" >
                    <IndexSlider/>
                </div>

                { todisplay }

            </>
    );

}

export default RealCategory;