import React, { useState } from 'react';

const Toggleit = (props) => {

    const [ show_members , setshow_members ] = useState(true)

    return (
            <>
                <div className="toggleit" style={props.style} >
                    <div className="toggleit_rot" >
                        <div className="toggleit_rot_div" 
                            onClick={ () => setshow_members(!show_members) }
                        style={{
                            transform: show_members ? 'rotate(180deg)' : 'rotate(90deg)'
                        }}  ></div>
                    </div>
                    <div className="toggleit_title" onClick={ () => setshow_members(!show_members) }
                        >
                        {props.title}
                    </div>
                </div>

                <div className="toggleit-others" 

                        style={{
                            display: show_members ? 'block' : 'none'
                        }}

                    >
                        {props.members}
                </div>

            </>
    );
}

export default Toggleit;