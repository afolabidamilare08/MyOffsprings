import React, { useEffect , useState } from 'react';
import {Link} from 'react-router-dom';
import Toggleit from './toggle';
import Axios from 'axios';


const CategoryLeft2 = (props) => {

    const [ category , setcategory ] = useState(null)

    useEffect( () => {

        Axios.get('/myproduct/rcategory/?limit=1000&offset=0').then(

            response => {
                setcategory(response.data.results)
            }

        ).catch()

    } ,[] )

    return (
            <>

                <div className="category-left-div" >


                        { category ? 
                        
                            category.map( ( cat , index ) => {

                                return <Toggleit
                                            key={ index }
                                            title={cat.cat_name}
                                            members={

                                                cat.categories.map( ( cat , index ) => {

                                                    return  <Link key={index} to={'/ourproducts/categories/category=' + cat.category_name } className="toggleit-others-li" >
                                                                { cat.category_name }
                                                            </Link>

                                                } )

                                            }
                                        />

                            } )

                        : null }

                </div>

            </>
    );
}

export default CategoryLeft2;