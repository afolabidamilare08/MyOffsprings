import React,{useState,useEffect,useContext} from 'react';
import { Productgallery } from '../../component/sell_product/sell_product';
import { InputWithLabel, LoginBtn,LoginTextarea,LoginSelect } from '../../component/login_components/login_components';
import Axios from 'axios';
import TopbannerDiv from '../../component/top-banner-msg/topbannermsg';
import { useVerifyimg } from '../../component/utilities/checkingforletter';
import LoadingPage from '../../component/utilities/loading/loading';
import OppsPage from '../../component/utilities/oppspage/oppspage';
import Store from '../../store/managementstore/managementstore';
import {AiOutlinePlus} from 'react-icons/ai';



const ProductEditPage  = (props) => {

      const productId = props.match.params.id
      const productSlug = props.match.params.slug
      const context = useContext(Store)

      const [ Allcategories , setAllcategories ] = useState(null)
      const [ Allsuppliers , setAllsuppliers ] = useState(null)
      const [ Loadingpage , setLoadingpage ] = useState(false)
      const [ Errorpage , setErrorpage ] = useState(false)
      const [ Categoriestoadd , setCategoriestoadd ] = useState({
        categories:[]
      })
      const [ product_specs , setproduct_specs ] = useState([
      ])
      const [ Addcolor , setAddcolor ] = useState({
        value:'',
        status:false
      })
      const [ Addsize , setAddsize ] = useState({
        value:'',
        status:false
      })
      const [ product_detail , setproduct_detail ] = useState({
        product_name:'',
        product_desc:'',
        product_category:'',
        price:'',
        supplier:'',
        fragile:'',
        carriage:'',
        available:'',
        availability:'',
        days_to:'',
        color:null,
        size:null,
        status:false,
        gotten:null
      })

      const [ product_image , setproduct_image ] = useState({
        image_1:{
          preview:'',
          image:null
        },
        image_2:{
          preview:'',
          image:null
        },
        image_3:{
          preview:'',
          image:null
        }
      })

      const [ catmodel , setcatmodel ] = useState({
        error:false,
        loading:false,
        value:false
      })

      const [ catsearch , setcatsearch ] = useState({
        query:''
      })


      const [ Topbannerdet , setTopbannerdet ] = useState({
        status:false,
        msg:'',
        bgColor:''
      })
      
      const getcategoryhandler = () => {
        Axios.get('/myproduct/category/?limit=1000&offset=0').then(

          response => {
            setAllcategories(response.data.results)
          }

        ).catch()
      }


      useEffect( () => {

        setErrorpage(false)
        setLoadingpage(true)

        Axios.get('/myproduct/allproduct/' + productId + '/' ).then(

          response => {

            setErrorpage(false)
            setLoadingpage(false)
            
            setproduct_detail({

              product_name:response.data.myproduct_name,
              product_desc:response.data.description,
              product_category:response.data.category,
              price:response.data.price,
              supplier:response.data.supplier,
              fragile:response.data.fragile,
              carriage:response.data.carriage,
              available:response.data.available,
              availability:response.data.availability,
              color:response.data.colors,
              size:response.data.sizes,      
              days_to:response.data.days_to,
              status:false,
              gotten:true
            })

            setproduct_specs(response.data.specs)

            setCategoriestoadd({
              categories:response.data.category
            })

            // var cati = []

            // for (let i = 0; i < array.length; i++) {
            //   const element = array[i];
              
            // }

            setproduct_image({
              image_1:{
                preview:response.data.product_img1,
                image:null
              },
              image_2:{
                preview:response.data.product_img2,
                image:null
              },
              image_3:{
                preview:response.data.product_img3,
                image:null
              }
            })

          }

        ).catch(
          e => {
            setErrorpage(true)
            setLoadingpage(false)
          }
        )

        getcategoryhandler()

        Axios.get('/suppliers/mysuppliers/').then(
          
          response => {
            setAllsuppliers(response.data.results)
          }

        ).catch(
          e => {
            setTopbannerdet({
              status:true,
              msg:'Something Went Wrong',
              bgColor:'red'
            })
            console.log(e)
          }
        )

      } ,[productId,productSlug])



      const addtocategorieshandler = (category) => {

        var fomerfull = [...Categoriestoadd.categories]
  
        fomerfull.push(category)
  
        setCategoriestoadd({
          categories:fomerfull
        })
  
      }
  
  
  
      const removecategorieshandler = (index) => {
  
        var fomerfull = [...Categoriestoadd.categories]
      
        fomerfull.splice(index,1);
        setCategoriestoadd({
          categories:fomerfull
        })
      }



    const PostProduct = () => {

      setproduct_detail({...product_detail,status:true})
      setTopbannerdet({
        status:true,
        msg:'Updating Product',
        bgColor:'orange'
      })


      if ( 
        product_detail.product_name === '' ||
        product_detail.product_desc === '' ||
        Categoriestoadd.categories.length < 1 ||
        product_detail.price === '' ||
        product_detail.supplier === '' ||
        product_detail.fragile === '' ||
        product_detail.carriage === ''
       ) {
        
        setproduct_detail({...product_detail,status:false})
        setTopbannerdet({
          status:true,
          msg:'All fileds must be filled',
          bgColor:'red'
        })

      }else{

        var newprice = parseInt(product_detail.price)

        const Datatosubmit = new FormData();



        Datatosubmit.append('myproduct_name',product_detail.product_name)
        Datatosubmit.append('description',product_detail.product_desc)
        Datatosubmit.append('price',newprice)
        Datatosubmit.append('supplier',product_detail.supplier)
        Datatosubmit.append('fragile',product_detail.fragile)
        Datatosubmit.append('carriage',product_detail.carriage)        
        Datatosubmit.append('available',product_detail.available)
        Datatosubmit.append('availability',product_detail.availability)
        Datatosubmit.append('days_to',product_detail.days_to)

        for (let l = 0; l < Categoriestoadd.categories.length; l++) {
          Datatosubmit.append('category',Categoriestoadd.categories[l].id)          
        }

        if ( product_image.image_1.image ) {
          Datatosubmit.append('product_img1',product_image.image_1.image,product_image.image_1.image.name)
        }

        if ( product_image.image_2.image ) {
          Datatosubmit.append('product_img2',product_image.image_2.image,product_image.image_2.image.name)
        }

        if ( product_image.image_3.image ) {
          Datatosubmit.append('product_img3',product_image.image_3.image,product_image.image_3.image.name)
        }

        Axios.patch('/myproduct/myproduct/' + productId + '/' ,Datatosubmit).then(

          response => {
            setTopbannerdet({
              status:true,
              msg:'Product Was Successfully Updated',
              bgColor:'rgba(13, 194, 94, 0.986)'
            })
            setproduct_detail({...product_detail,status:false})
          }

        ).catch( 
          e => {
            setTopbannerdet({
              status:true,
              msg:'Something Went Wrong',
              bgColor:'red'
            })
            setproduct_detail({...product_detail,status:false})
          }
         )

      }

    }





    const AddcolorHandler = (e) => {
      
      e.preventDefault()
      setAddcolor({...Addcolor,status:true})
      setTopbannerdet({
        status:true,
        msg:'Adding A Color',
        bgColor:'orange'
      })

      if( setAddcolor.value === '' ){
        setAddcolor({...Addcolor,status:false})
        setTopbannerdet({
          status:true,
          msg:'color Cannot Be Empty',
          bgColor:'red'
        })
      }else{

        Axios.post('/myproduct/color/',{colour:Addcolor.value,product:productId}).then(

          response => {
            // Addtocat(Addcategories.value)
            setAddcolor({value:'',status:false})
            setTopbannerdet({
              status:true,
              msg:'Color Successfully Added',
              bgColor:'rgba(13, 194, 94, 0.986)'
            })
            // gogo()

            var oldshit = [...product_detail.color]

            oldshit.push(response.data)

            setproduct_detail({
              ...product_detail,
              color:oldshit
            })

          }

        ).catch( e => {
          setAddcolor({...Addcolor,status:false})
          setTopbannerdet({
            status:true,
            msg:'Something Went Wrong',
            bgColor:'red'
          })
        } )

      }

    }



    const [ colortodelete , setcolortodelete ] = useState({
      value:'',
      status:false
    })

    const Deletecolor = (e) => {

      e.preventDefault()
      setcolortodelete({...colortodelete,status:true})
      setTopbannerdet({
        status:true,
        msg:'Adding A Color',
        bgColor:'orange'
      })

      if( setcolortodelete.value === '' ){
        setcolortodelete({...colortodelete,status:false})
        setTopbannerdet({
          status:true,
          msg:'color Cannot Be Empty',
          bgColor:'red'
        })
      }else{

        Axios.delete('/myproduct/color/' + colortodelete.value + '/' , {user:context.User_id} ).then(

          response => {
            setcolortodelete({value:'',status:false})
            setTopbannerdet({
              status:true,
              msg:'Color Successfully deleted',
              bgColor:'rgba(13, 194, 94, 0.986)'
            })

            const ColorIndex = product_detail.color.findIndex( i => {
              return i.id === colortodelete.value
            } )

            // console.log(ColorIndex)

            var oldshit = [...product_detail.color]

            oldshit.splice(ColorIndex,1)

            setproduct_detail({
              ...product_detail,
              color:oldshit
            })
      
            
          }

        ).catch( e => {
          setTopbannerdet({
            status:true,
            msg:'Something Went Wrong',
            bgColor:'red'
          })
          setcolortodelete({...colortodelete,status:false})
        } )

      }

    }





    const [ sizetodelete , setsizetodelete ] = useState({
      value:'',
      status:false
    })

    const Deletesize = (e) => {

      e.preventDefault()
      setsizetodelete({...sizetodelete,status:true})
      setTopbannerdet({
        status:true,
        msg:'Deleting A Size',
        bgColor:'orange'
      })

      if( setsizetodelete.value === '' ){
        setsizetodelete({...sizetodelete,status:false})
        setTopbannerdet({
          status:true,
          msg:'Size Cannot Be Empty',
          bgColor:'red'
        })
      }else{

        Axios.delete('/myproduct/size/' + sizetodelete.value + '/' , {user:context.User_id} ).then(

          response => {
            setsizetodelete({value:'',status:false})
            setTopbannerdet({
              status:true,
              msg:'Size Successfully deleted',
              bgColor:'rgba(13, 194, 94, 0.986)'
            })
            // gogo()

            const SizeIndex = product_detail.size.findIndex( i => {
              return i.id === sizetodelete.value
            } )

            var oldshit = [...product_detail.size]

            oldshit.splice(SizeIndex,1)

            setproduct_detail({ 
              ...product_detail,
              size:oldshit
            })

          }

        ).catch( e => {
          setTopbannerdet({
            status:true,
            msg:'Something Went Wrong',
            bgColor:'red'
          })
          setsizetodelete({...sizetodelete,status:false})
        } )

      }

    }









    const AddsizeHandler = (e) => {
      
      e.preventDefault()
      setAddsize({...Addsize,status:true})
      setTopbannerdet({
        status:true,
        msg:'Adding A Size',
        bgColor:'orange'
      })

      if( setAddsize.value === '' ){
        setAddsize({...Addsize,status:false})
        setTopbannerdet({
          status:true,
          msg:'Size Cannot Be Empty',
          bgColor:'red'
        })
      }else{

        Axios.post('/myproduct/size/',{size:Addsize.value,product:productId}).then(

          response => {
            // Addtocat(Addcategories.value)
            setAddsize({value:'',status:false})
            setTopbannerdet({
              status:true,
              msg:'Size Successfully Added',
              bgColor:'rgba(13, 194, 94, 0.986)'
            })
            // gogo()
            
            var oldshit = [...product_detail.size]

            oldshit.push(response.data)

            setproduct_detail({
              ...product_detail,
              size:oldshit
            })

          }

        ).catch( e => {
          setTopbannerdet({
            status:true,
            msg:'Something Went Wrong',
            bgColor:'red'
          })
        } )

      }

    }













    const Pickingimage = (event,number) =>{
      
      const [ result ] = useVerifyimg(event.target.files)

      if( result ){

        const currentfile = event.target.files[0] 
        const reader = new FileReader()
        reader.addEventListener("load",()=>{
            if(number === 1){
                setproduct_image({...product_image,image_1:{
                    preview:reader.result,
                    image:currentfile
                }})
            }
            if(number === 2){
                setproduct_image({...product_image,image_2:{
                  preview:reader.result,
                  image:currentfile
              }})
            }
            if(number === 3){
                setproduct_image({...product_image,image_3:{
                  preview:reader.result,
                  image:currentfile
              }})
            }
        },false)

        reader.readAsDataURL(currentfile)

      }else{
        setTopbannerdet({
          status:true,
          msg:' only jpg , jpeg , png and gif files are allowed  .... ',
          bgColor:'red'
        })
      }

    }







    const SearchCategoryHandler = (e) => {

      e.preventDefault()

      if ( catsearch.query !== '' ) {
        
          Axios.get('/myproduct/category/?limit=1000000&offset=0&search=' + catsearch.query ).then(

            response => {
              setAllcategories(response.data.results)
            }

          ).catch()

      }else{
        getcategoryhandler()
      }

    }




    const Changespecstitle = ( index , event ) => {

      var oldspecs = [...product_specs]
      var thatspecs = oldspecs[index]
      thatspecs = {...thatspecs,title:event}
      oldspecs[index] = thatspecs

      setproduct_specs([...oldspecs])

    }

    const Changespecsesponse = ( index , event ) => {

      var oldspecs = [...product_specs]
      var thatspecs = oldspecs[index]
      thatspecs = {...thatspecs,response:event}
      oldspecs[index] = thatspecs

      setproduct_specs([...oldspecs])

    }

    const Removespecs = (index,specs) => {

      var oldspecs = [...product_specs]


      if ( oldspecs[index].id ) {
        
        Axios.delete('/myproduct/Specs/' + specs.id + '/' ).then(

          response => {

            oldspecs.splice(index,1)
            setproduct_specs([...oldspecs])

            setTopbannerdet({
              status:true,
              msg:' Specifications Successfully Removed ',
              bgColor:'rgba(13, 194, 94, 0.986)'
            })

          }

        ).catch()

      }else{
        oldspecs.splice(index,1)
        setproduct_specs([...oldspecs])

        setTopbannerdet({
          status:true,
          msg:' Specifications Successfully Removed ',
          bgColor:'rgba(13, 194, 94, 0.986)'
        })
      }


    }

    const savespescs = (index,specs) => {

      setTopbannerdet({
        status:true,
        msg:' Saving Specifications ',
        bgColor:'orange'
      })

      var oldspecs = [...product_specs]

      if ( oldspecs[index].id ) {
          Axios.patch('/myproduct/Specs/' + specs.id + '/' , {...oldspecs[index]} ).then(

            response => {
    
              setTopbannerdet({
                status:true,
                msg:' Specifications Successfully saved ',
                bgColor:'rgba(13, 194, 94, 0.986)'
              })
    
            }
    
          ).catch(
    
            e => {
    
              setTopbannerdet({
                status:true,
                msg:' Something Went Wrong ',
                bgColor:'red'
              })
    
            }
    
          )
      }else{

        Axios.post('/myproduct/Specs/',{...oldspecs[index],product:productId}).then(

          response => {
            oldspecs[index] = response.data
            setproduct_specs([...oldspecs])

            setTopbannerdet({
              status:true,
              msg:' Specifications Successfully saved ',
              bgColor:'rgba(13, 194, 94, 0.986)'
            })
  
          }

        ).catch(

          e => {
    
            setTopbannerdet({
              status:true,
              msg:' Something Went Wrong ',
              bgColor:'red'
            })
  
          }

        )

      }

    }




    const gogo = () => {
      props.history.go()
    } 
  
    const goBack = () => {
      props.history.goBack()
    }
  


    if( Loadingpage && !product_detail.gotten && !Errorpage ){
      var what_to_return = <LoadingPage/>
    }else{
      if ( !Loadingpage && Errorpage && !product_detail.gotten ) {
        what_to_return = <OppsPage tryagain={gogo} goback={goBack} />
      }else{
        if ( !Loadingpage && !Errorpage && product_detail.gotten ) {
          what_to_return = <>

                              <TopbannerDiv

                              closeshow={ () => setTopbannerdet({...Topbannerdet,status:false})}
                              backgroundcolor={Topbannerdet.bgColor}
                              show={Topbannerdet.status}
                              message={Topbannerdet.msg}

                              />



                              

        <div className="addcat_back" style={{
          display: catmodel.value ? 'flex' : 'none'
        }} >

            <div className="addcat_back-div" >

              <div className="addcat_back-div_top" >

                  <div className="addcat_back-div_top-title" > Add Category </div>

                  <form className="addcat_back-div_top-form" onSubmit={SearchCategoryHandler} > 

                      <input className="addcat_back-div_top-form_input" value={catsearch.query} onChange={ (event) => setcatsearch({query:event.target.value}) } />

                      <button className="addcat_back-div_top-form_btn" > Search </button>

                  </form>

                  <div>
                    <AiOutlinePlus onClick={ () => setcatmodel({...catmodel,value:false}) } className="addcat_back-div_top-close" />
                  </div>

              </div>

              <div className="addcat_back-div_body" >

                  { Allcategories ? Allcategories.map(( category , index ) => {
                      return  <div className="addcat_back-div_body-cat" style={{
                        // border: !acceptedfilesarray.includes(category.category_name) ? '1px solid lightgray' : '1px solid tomato'
                      }} onClick={ () => addtocategorieshandler(category) } key={index} > {category.category_name} </div>      
                  } ) : null }

              </div>

              <div className="addcat_back-div_foot" >

                 <div className="addcat_back-div_foot_left" id="addcat_back-div_foot_left" >

                    {Categoriestoadd.categories.map(( category , index ) => {
                          return  <div className="addcat_back-div_body-cat" style={{
                            // border: !acceptedfilesarray.includes(category.category_name) ? '1px solid lightgray' : '1px solid tomato'
                          }} onClick={ () => removecategorieshandler(index) } key={index} > {category.category_name} </div>      
                      } )}

                 </div>   

                 <div className="addcat_back-div_foot_right" >
                      
                    {/* <button className="addcat_back-div_foot_right-btn" onClick={getcategoryhandler} >
                      Refresh Categories 
                    </button> */}

                 </div>
                 
              </div>
 
            </div>

        </div>
         




                            <div className="product_sell_page" >

                                  <div className="selling-product-all-div" >

                                      <div className="selling-product-all-div-top" >
                                          Edit Product
                                      </div>

                                      <div className="selling-product-all-div-form" >

                                          <div className="selling-product-all-div-form-left" >

                                                <InputWithLabel
                                                    label="Product Name"
                                                    value={ product_detail.product_name }
                                                    onChange={ (event) => setproduct_detail({...product_detail,product_name:event.target.value}) }
                                                />

                                                <LoginTextarea
                                                    label="Product Description"
                                                    value={ product_detail.product_desc }
                                                    onChange={ (event) => setproduct_detail({...product_detail,product_desc:event.target.value}) }
                                                />

                                                  <InputWithLabel
                                                      label="Price"
                                                      value={ product_detail.price }
                                                      // type="number"
                                                      onChange={ (event) => setproduct_detail({...product_detail,price:event.target.value}) }
                                                  />

                                                  <div className="sell_prouct-div_form-gal" >

                                                      <Productgallery
                                                        pickimage={ (event) => Pickingimage(event,1) }
                                                        label="img1"
                                                        placeholder={ product_image.image_1.preview ? <img alt="" className="sell_prouct-div_form-gal_div-img-img" src={product_image.image_1.preview} /> : null }
                                                      />

                                                      <Productgallery
                                                        label="img2"
                                                        pickimage={ (event) => Pickingimage(event,2) }
                                                        placeholder={ product_image.image_2.preview ? <img alt="" className="sell_prouct-div_form-gal_div-img-img" src={product_image.image_2.preview} /> : null }
                                                      />

                                                      <Productgallery
                                                        label="img3"
                                                        pickimage={ (event) => Pickingimage(event,3) }
                                                        placeholder={ product_image.image_3.preview ? <img alt="" className="sell_prouct-div_form-gal_div-img-img" src={product_image.image_3.preview} /> : null }
                                                      />

                                                  </div>

                                                  {Allsuppliers?
                                                      <LoginSelect
                                                      label="Supplier"
                                                      value={ product_detail.supplier }
                                                      onChange={ (event) => setproduct_detail({...product_detail,supplier:event.target.value}) }
                                                      options={

                                                        <>
                                                        <option value="" > Supplier </option>
                                                          { Allsuppliers.map( category => {
                                                              return <option key={category.id} value={category.id} > {category.supplier_name} </option>
                                                            } )
                                                          }
                                                        </>

                                                      }
                                                    />:null}

                                                    <LoginSelect
                                                        label="Fragile"
                                                        value={ product_detail.fragile }
                                                        onChange={ (event) => setproduct_detail({...product_detail,fragile:event.target.value}) }
                                                        options={
                                                          <>
                                                          {/* <option value="" > Fragile </option> */}
                                                          {/* <option value="unknown" > Unknown </option> */}
                                                          <option value="true" > Yes </option>
                                                          <option value="false" > No </option>
                                                          </>
                                                        }
                                                    />

                                                    <LoginSelect
                                                        label="Carriage"
                                                        value={ product_detail.carriage }
                                                        onChange={ (event) => setproduct_detail({...product_detail,carriage:event.target.value}) }
                                                        options={
                                                          <>
                                                          <option value="" > Carriage </option>
                                                          <option value="small" > Small </option>
                                                          <option value="large" > Large </option>
                                                          <option value="xlarge" > XLarge </option>
                                                          </>
                                                        }
                                                    />

                                                    <LoginSelect
                                                        label="Available"
                                                        value={ product_detail.available }
                                                        onChange={ (event) => setproduct_detail({...product_detail,available:event.target.value}) }
                                                        options={
                                                          <>
                                                          <option value="" > Available </option>
                                                          <option value="true" > Yes </option>
                                                          <option value="false" > No </option>
                                                          </>
                                                        }
                                                    />

                                                    <LoginSelect
                                                        label="Availability"
                                                        value={ product_detail.availability }
                                                        onChange={ (event) => setproduct_detail({...product_detail,availability:event.target.value}) }
                                                        options={
                                                          <>
                                                          <option value="" > Availability </option>
                                                          <option value="common" > Common </option>
                                                          <option value="highend" > Highend </option>
                                                          <option value="scarce" > Scarce </option>
                                                          </>
                                                        }
                                                    />

                                                    <InputWithLabel
                                                        label="Days Before Available"
                                                        value={ product_detail.days_to }
                                                        type="number"
                                                        onChange={ (event) => setproduct_detail({...product_detail,days_to:event.target.value}) }
                                                    />

                                          </div>
                                          
                                          <div className="selling-product-all-div-form-cat" >

                                              <div className="selling-product-all-div-form-cat-top" > 

                                                <form onSubmit={AddcolorHandler} className="" >

                                                    <InputWithLabel
                                                      label="Add Color "
                                                      value={ Addcolor.value }
                                                      onChange={ (event) => setAddcolor({ ...Addcolor,value:event.target.value })} 
                                                    />

                                                    <LoginBtn
                                                      value="Add Color"
                                                    />

                                                  </form>

                                                  <form onSubmit={Deletecolor} style={{
                                                    marginTop:'1rem'
                                                  }} >

                                                      <LoginSelect
                                                        label="Remove Color"
                                                        value={ colortodelete.value }
                                                        onChange={ (event) => setcolortodelete({...colortodelete,value:event.target.value}) }
                                                        options={
                                                                <>
                                                                  <option> color </option>
                                                                  { product_detail.color.map( ( color , index ) => {

                                                                      return <option key={index} value={color.id}> {color.colour} </option>

                                                                  } ) }

                                                                </>
                                                        }
                                                      />

                                                      <LoginBtn
                                                      value="Remove Color"
                                                      />

                                                  </form>

                                                  <form onSubmit={AddsizeHandler} style={{
                                                    marginTop:'4rem'
                                                  }} >

                                                        <InputWithLabel
                                                          label="Add Size"
                                                          value={ Addsize.value }
                                                          onChange={ (event) => setAddsize({ ...Addsize,value:event.target.value })} 
                                                        />

                                                        <LoginBtn
                                                          value="Add Size"
                                                        />

                                                  </form>

                                                  <form onSubmit={Deletesize} style={{
                                                    marginTop:'2rem'
                                                  }} >

                                                      <LoginSelect
                                                        label="Size"
                                                        value={ sizetodelete.value }
                                                        onChange={ (event) => setsizetodelete({...sizetodelete,value:event.target.value}) }
                                                        options={
                                                                <>
                                                                  
                                                                  <option> size </option>
                                                                  { product_detail.size.map( ( size , index ) => {

                                                                      return <option key={index} value={size.id}> {size.size} </option>

                                                                  } ) }

                                                                </>
                                                        }
                                                      />

                                                      <LoginBtn
                                                        value="Remove Size"
                                                      />

                                                </form>

                                                <div className="product_sell_page_cat_form" >
                                    <button className="login_btn" onClick={ () => setcatmodel({...catmodel,value:true}) } >
                                        Pick Category
                                    </button>
                                  </div>

                                              </div>


                                                              
                                              <div className="selling-product-all-div-form-cat-btm" >
                                                  
                                                  <div className="selling-product-all-div-form-cat-btm-top" >
                                                      Product Specificaions
                                                  </div>

                                                    {

                                                      product_specs.map( ( specs , index ) => {

                                                        return  <div key={index} className="selling-product-all-div-form-cat-btm-div" >
                                                                    <input type="text"
                                                                      value={ specs.title } 
                                                                      onChange={ (event) => Changespecstitle(index,event.target.value) }
                                                                      className="selling-product-all-div-form-cat-btm-div-input1"
                                                                      placeholder="Title" />
                                                                      --
                                                                    <input type="text" 
                                                                      value={ specs.response }
                                                                      onChange={ (event) => Changespecsesponse(index,event.target.value) }
                                                                      className="selling-product-all-div-form-cat-btm-div-input2"
                                                                      placeholder="Specification" />

                                                                      <button className="selling-product-all-div-form-cat-btm-div-btn" onClick={ () => Removespecs(index,specs) } >
                                                                        {/* - */}
                                                                      </button>

                                                                      <button className="selling-product-all-div-form-cat-btm-div-btn" style={{background:'green'}} onClick={ () => savespescs(index,specs) } >
                                                                        {/* - */}
                                                                      </button>

                                                                </div>

                                                      } )
                                                      
                                                    }

                                                    <button className="selling-product-all-div-form-cat-btm-btn" onClick={

                                                      () => setproduct_specs([
                                                        ...product_specs,
                                                        {title:'',response:''}
                                                      ])

                                                    } >
                                                        Add Specs
                                                    </button>

                                              </div>
 

                                          </div>

                                      </div>

                                      <button className="selling-product-all-div-btn" onClick={PostProduct} >
                                        Edit Product 
                                      </button>

                                  </div>



                                  </div>



                           </>
        }
      }
    }


      return ( 

        <>
          {what_to_return}
        </>

      );

}

export default ProductEditPage ;