import React,{useContext,useState,useEffect} from 'react';
import ProfileHomeTemplates from './profile_home_templates';
import ProfileHeader from '../../../layout_components/profile_header/profile_header';
import Store from '../../../store/managementstore/managementstore';
import Axios from 'axios';
import LoadingPage from '../../../component/utilities/loading/loading';
import BtnSpin from '../../../component/utilities/btnSpin/btnSpin';
import OppsPage from '../../../component/utilities/oppspage/oppspage';

const ProfileHome = (props) => {

  const context = useContext(Store)

  const [ Loadingpage , setLoadingpage ] = useState(false)
  const [ Errorpage , setErrorpage ] = useState(false)
  const [ MyOrders , setMyOrders ] = useState(null)
  const [ UserProfile , setUserProfile ] = useState(null)

  useEffect( () => {
    setLoadingpage(true)
    setErrorpage(false)
    var user_id = context.User_id;

    Axios.get('/myaccount/users/' + user_id + '/').then(
      response => {
        setUserProfile(response.data)
        setErrorpage(false)
        setLoadingpage(false)
      }
    ).catch(
      e => {
        setErrorpage(true)
        setLoadingpage(false)
      }
    )

    Axios.get('/myorder/myorderk/').then(

      response => {
        setMyOrders(response.data.results)
        setErrorpage(false)
        setLoadingpage(false)
      }

    ).catch(
      e => {
        setErrorpage(true)
        setLoadingpage(false)
        setUserProfile(null)
      }
    )


  }, [context.User_id] )


  const logout = (props) => {
    context.Logouthandler()
    props.history.push('/signin')
  }

  // if( !context.User_token ){
  //   props.history.push('/signin')
  // }



  const gogo = () => {
    props.history.go()
  } 

  const goBack = () => {
    props.history.goBack()
  }


  if( Loadingpage && !UserProfile && !Errorpage ){
    var what_to_return = <LoadingPage/>
  }else{
    if ( !Loadingpage && Errorpage && !UserProfile ) {
      what_to_return = <OppsPage tryagain={gogo} goback={goBack} />
    }else{
      if ( !Loadingpage && !Errorpage && UserProfile ) {
        what_to_return = <ProfileHomeTemplates
                            first_name={UserProfile.first_name}
                            last_name={UserProfile.last_name}
                            referee={UserProfile.referees}
                            my_orders={ MyOrders ? MyOrders : <BtnSpin bgColor="gray" /> }
                            logout_btn={ () => logout(props)}
                            evry={props}
                            profile_img={ UserProfile.pro.profile_picture ? UserProfile.pro.profile_picture : null }
                          />
      }
    }
  }


      return ( 
          <>

            <ProfileHeader
              title="My Profile"
              goback={ goBack }
            />

            {what_to_return}

          </>
      );

}

export default ProfileHome;