import React,{useState, useEffect,useContext} from 'react';
import ProfileHeader from '../../layout_components/profile_header/profile_header';
import { InputWithLabel, LoginBtn } from '../../component/login_components/login_components';
import TopbannerDiv from '../../component/top-banner-msg/topbannermsg';
import Axios from 'axios';
import Store from '../../store/managementstore/managementstore';
import BtnSpin from '../../component/utilities/btnSpin/btnSpin';

const ChangeUserPasswordPage = (props) => {


    const context = useContext(Store)

    const [ Msg , setMsg ] = useState({
        bg:'',
        msg:'',
        value:false
    })

    const [ Userdetail , setUserdetail ] = useState(null)

    const [ updating , setupdating ] = useState(false)

    const [ passwords , setpasswords ] = useState({
        old_password:'',
        new_password:'',
        rpt_password:''
    })



    useEffect( () => {

        Axios.get('/myaccount/users/' + context.User_id + '/').then(

            response => {
                setUserdetail(response.data)
            }

        ).catch()

    },[context.User_id] )


    const PasswordSendHandler = (e) => {

        e.preventDefault()

        setMsg({
            bg:'orange',
            msg:'Updating Password...',
            value:true
        })
        setupdating(true)
        
        if( passwords.old_password === '' || passwords.new_password === '' || passwords.rpt_password === '' ){
            setMsg({
                bg:'red',
                msg:'All Fileds Must Be Filled',
                value:true
            })
            setupdating(false)
        }else{

            if( passwords.new_password !== passwords.rpt_password ){
                setMsg({
                    bg:'red',
                    msg:'New password And repeat password should be the same',
                    value:true
                })
                setupdating(false)
            }else{

              var AllpasswordDetails = {
                old_password:passwords.old_password,
                new_password1:passwords.new_password,
                new_password2:passwords.new_password
              }
      
                    Axios.post('/myaccount/rest-auth/password/change/',AllpasswordDetails,   {
      
                      auth:{
                        username: Userdetail.username, 
                        password: passwords.old_password
                      }
      
                    }).then(
                      response=>{

                        setMsg({
                            bg:'rgb(39, 180, 39)',
                            msg:'You have successfully updated your password!!',
                            value:true
                        })
                        setpasswords({
                            old_password:'',
                            new_password:'',
                            rpt_password:''
                        })
                        setupdating(false)

                      }
                    ).catch( (error) => {

                        setupdating(false)
                        console.log(error.response)

                      if(error.response){
                          if(error.response.data.new_password2){
                            setMsg({
                              value:true,
                              msg:error.response.data.new_password2[0],
                              bg:'red'
                            })
                          }

                          if(error.response.data.detail){
                            setMsg({
                                value:true,
                                msg:'Invalid Old Password',
                                bg:'red'
                              })
                          }

                      }else{
                        setMsg({
                            value:true,
                            msg:'Something Went Wrong',
                            bg:'red'
                          })  
                      }
                  } )
            }

        }

    }






    const goBack = () => {
        props.history.goBack()
    }
    
      return ( 

        <>

            <ProfileHeader
                title="Change Password"
                goback={ goBack }
            />        
            
            <TopbannerDiv 
                backgroundcolor={Msg.bg} 
                show={Msg.value}
                message={Msg.msg}
                closeshow={ () => setMsg({...Msg,value:false}) }
            />

            <div className="change_password-page" >

                <form className="change_password-page-form" onSubmit={PasswordSendHandler} >

                    <div className="change_password-page-form-top" >
                        Change Password
                    </div>

                    <InputWithLabel
                        type="password"
                        label="Old Password"
                        value={ passwords.old_password }
                        onChange={ (event) => setpasswords({...passwords,old_password:event.target.value}) }
                    />

                    <InputWithLabel
                        type="password"
                        label="New Password"
                        value={ passwords.new_password }
                        onChange={ (event) => setpasswords({...passwords,new_password:event.target.value}) }
                    />

                    <InputWithLabel
                        type="password"
                        label="Repeat Password"
                        value={ passwords.rpt_password }
                        onChange={ (event) => setpasswords({...passwords,rpt_password:event.target.value}) }
                    />

                    <LoginBtn
                        disabled={updating}
                        value={ updating ? <BtnSpin bgColor="white" /> : 'Change Password' }
                    />

                </form>

            </div>

        </>

      );

}

export default ChangeUserPasswordPage;