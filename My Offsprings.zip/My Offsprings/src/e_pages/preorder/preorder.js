import React,{useState, useContext} from 'react';
import { InputWithLabel, LoginBtn, LoginTextarea, BoxMessage2 } from '../../component/login_components/login_components';
import Axios from 'axios';
import BtnSpin from '../../component/utilities/btnSpin/btnSpin';
import { useVerifyimg } from '../../component/utilities/checkingforletter';
import {BiImageAdd} from 'react-icons/bi';
import Store from '../../store/managementstore/managementstore';

const PreOrderPage = (props) => {

    const context = useContext(Store)
 
    const [ RegDetails , setRegDetails] = useState({
        product_name:'',
        description:'',
        img:{
            img:null,
            preview:null
        }
    })

    const [ Error , setError ] = useState({
        value:false,
        msg:''
    })

    const [ successful , setsuccessful ] = useState(false)

    const [ Loading , setLoading ] = useState(false)






    const RegistrationHandler = (e) => {

        e.preventDefault()

        setLoading(true)

        setError({
            value:false,
            msg:''
        })

        if ( RegDetails.product_name === '' 
        || RegDetails.description === '' 
        || !RegDetails.img.img 
        || !RegDetails.img.preview ) {
            setError({
                value:true,
                msg:'All Fields Must Be Filled'
            })
            setLoading(false)
        }else{

            const Datatosubmit = new FormData();

            Datatosubmit.append('name',RegDetails.product_name)
            Datatosubmit.append('description',RegDetails.description)
            Datatosubmit.append('img',RegDetails.img.img,RegDetails.img.img.name)
            Datatosubmit.append('user',context.User_id)

            Axios.post('/suppliers/preorder/',Datatosubmit).then(

                response => {
                    setLoading(false)
                    setRegDetails({
                        product_name:'',
                        description:'',
                        img:{
                            img:null,
                            preview:null
                        }
                    })
                    setsuccessful(true)
                }

            ).catch( e => {
            setLoading(false)

                setError({
                    value:true,
                    msg:'Somthing Went Wrong'
                })
            } )

        }

    }




    const SelectImageHandler = (event) => {

        setError({
            value:false,
            msg:''
        })

        const [ result ] = useVerifyimg(event.target.files)

        if( result ){

            const currentfile = event.target.files[0] 
            const reader = new FileReader()
            reader.addEventListener("load",()=>{
                  setRegDetails({
                      ...RegDetails,
                      img:{
                        preview:reader.result,
                        img:currentfile
                      }
                  })

            },false)
    
            reader.readAsDataURL(currentfile)

        }else{
            setError({
                value:false,
                msg:' only jpg , jpeg , png and gif files are allowed  .... '
            })
        }


    }


      return ( 
        <>

        <div className="register_as_sup_mid" >

            { !successful ? 
            
            <div className="login_page_template_right" >
            <div className="login_page_template_mid" >
                <div className="login_page_template_mid_top" >
                    Snap Order
                    {/* <br/>
                    as a Supplier */}
                </div>

                { Error ? 
                    <div className="login_page_template_mid_error" >
                        {Error.msg}
                    </div> : null }

                <form className="login_page_template_mid_form" onSubmit={RegistrationHandler} >

                    <InputWithLabel label="Product Name" type="text" 
                        value={RegDetails.product_name} 
                        onChange={ (event) => setRegDetails({...RegDetails,product_name:event.target.value}) } />
                    
                    <LoginTextarea label="Give a description about the product"
                         value={RegDetails.description} 
                         onChange={ (event) => setRegDetails({...RegDetails,description:event.target.value}) }/>                    


                    <div className="preorder_img-div" >

                        <div className="preorder_img-div-top" >
                            Product Image
                        </div>

                        <label for="pic" className="preorder_img-div-label" >

                            <div className="preorder_img-div-label-img" >
                                { RegDetails.img.img && RegDetails.img.preview ? 
                                    <img alt="" src={RegDetails.img.preview} className="preorder_img-div-label-img-img" />
                                : <BiImageAdd className="preorder_img-div-label-img-ic" /> }
                            </div>

                            <div className="preorder_img-div-label-btn" > Pick Image </div>

                        </label>

                        <input type="file" id='pic' onChange={SelectImageHandler} style={{
                            display:'none'
                        }} />

                    </div>

                    <LoginBtn value={ Loading ? <BtnSpin bgColor="white" /> : 'Submit Snap Order Request' } disabled={Loading} />

                </form>

            </div>
            </div>

            : <BoxMessage2 
                title="Request To Be A Supplier"        
                story="You have succesfully registered as a supplier"
                />
            
            }

        </div>

      </>
      );

}

export default PreOrderPage;