import React,{useEffect,useState} from 'react';
import ProfileHeader from '../../layout_components/profile_header/profile_header';
import { LoginBtn } from '../../component/login_components/login_components';
import Axios from 'axios';
import {FaSearch} from 'react-icons/fa';
import LoadingPage from '../../component/utilities/loading/loading';
import OppsPage from '../../component/utilities/oppspage/oppspage';
import {Link} from 'react-router-dom';
import { EmptyOrder } from '../../component/utilities/empty/no_product';


const AllOrderListPage = (props) => { 
 
        const [ Loadingpage , setLoadingpage ] = useState(false)
        const [ Errorpage , setErrorpage ] = useState(false)
        const [ AllOrders , setAllOrders ] = useState(null)
        const [ status , setstatus ] = useState('all')
        const [ Orderstoshow , setOrderstoshow ] = useState(null)
        const [ Query , setQuery ] = useState('')

    useEffect( () => {

        setErrorpage(false)
        setLoadingpage(true)

        Axios.get('/myorder/myorder/?limit=121317676&offset=0').then(

            response => {

                setAllOrders(response.data.results)
                setOrderstoshow(response.data.results)
                setErrorpage(false)
                setLoadingpage(false)
            }

        ).catch(

            e => {
                setErrorpage(true)
                setLoadingpage(false)
                setAllOrders(null)
                setOrderstoshow(null)
              }

        )

    },[] )






    const submitQueryHandler = (e) => {

        e.preventDefault()

        // if( Query !== '' ){

            var nweit = []
            var oldSambers = [...AllOrders]
            console.log(oldSambers)

            for (let k = 0; k < oldSambers.length; k++) {
                
                var pacitem = oldSambers[k].id
                console.log(oldSambers[k])

                if ( parseInt(pacitem) === parseInt(Query) ) {
                    nweit.push(oldSambers[k])
                }

            }

            Setitout(nweit)            

    }



    const filterOrderHandler = (e) => {

        e.preventDefault()

        var oldOrders = [...AllOrders]

        if( status === 'pending' ){

            var oldit = []

            for (let p = 0; p < oldOrders.length; p++) {
                
                if ( oldOrders[p].status === 'paid' ) {
                    oldit.push(oldOrders[p])
                }

            }

            Setitout(oldit)

        }


        if( status === 'in-transit' ){

            oldit = []

            for (let k = 0; k < oldOrders.length; k++) {
                
                if ( oldOrders[k].status === 'in_transit' ) {
                    oldit.push(oldOrders[k])
                }

            }

            Setitout(oldit)

        }

        if( status === 'delivered' ){

            oldit = []

            for (let k = 0; k < oldOrders.length; k++) {
                
                if ( oldOrders[k].status === 'delivered' ) {
                    oldit.push(oldOrders[k])
                }

            }

            Setitout(oldit)

        }

        if( status === 'all' ){

            Setitout(AllOrders)

        }


    }

    const Setitout = (lists) => {
        setOrderstoshow(lists)
    }













    const gogo = () => {
        props.history.go()
      } 
    
      const goBack = () => {
        props.history.goBack()
      }
    










    
      if( Loadingpage && !Orderstoshow && !Errorpage ){
        var what_to_return = <LoadingPage/>
      }else{
        if ( !Loadingpage && Errorpage && !Orderstoshow ) {
          what_to_return = <OppsPage tryagain={gogo} goback={goBack} />
        }else{
          if ( !Loadingpage && !Errorpage && Orderstoshow ) {
            what_to_return = <>

                                <div className="orderlistpage-div" >
                                            
                                            <div className="orderlistpage-div_right" >

                                            <form className="orderlistpage-div_right_search" onSubmit={submitQueryHandler} >
                                                    <input type="text" 
                                                        value={Query}
                                                        onChange={ (event) => setQuery(event.target.value) }
                                                        placeholder="Search For Order Id" 
                                                        className="orderlistpage-div_right_search_input" 
                                                    />
                                                    <button className="orderlistpage-div_right_search_btn" >
                                                        <FaSearch className="orderlistpage-div_right_search_btn_ic" />
                                                    </button>
                                                </form>

                                                <div className="orderlistpage-div_right_filter" >

                                                    <div className="orderlistpage-div_right_filter_top" >
                                                        Filter Orders
                                                    </div>

                                                    <form className="orderlistpage-div_right_filter_form" onSubmit={ filterOrderHandler } >

                                                        <div className="orderlistpage-div_right_filter_form_div" >

                                                            <label className="orderlistpage-div_right_filter_form_div-label" >Status</label>

                                                            <select className="orderlistpage-div_right_filter_form_div-select" value={status} onChange={ (event) => setstatus(event.target.value) } >
                                                            <option value="" >status</option>
                                                                <option value="all" >All</option>
                                                                <option value="pending" >Pending</option>
                                                                <option value="in-transit">In-Transit</option>
                                                                <option value="delivered">Delivered</option>
                                                            </select>

                                                        </div>

                                                        <LoginBtn value="Filter Result" disabled={false} />

                                                    </form>

                                                </div>

                                            </div>

                                            <div className="orderlistpage-div_left" >
                                            
                                                <div className="orderlistpage-div_left_top" >
                                                    Order List
                                                </div>

                                                { Orderstoshow.length > 0 ? Orderstoshow.map( (order,index) => {

                                                    if ( order.status === 'created' ) {
                                                        var color = 'red'
                                                        var status = 'Unpaid'

                                                        return  <div key={index} className="profiletemplate_div_middle_main_list" >
                                                                    <div className="profiletemplate_div_middle_main_list_id" > {'TF'+order.id+'T56T6789E' +  order.id} </div>
                                                                    <div className="profiletemplate_div_middle_main_list_date" > {order.created_at} </div>
                                                                    <div className="profiletemplate_div_middle_main_list_status" style={{color:color}} > {status} </div>
                                                                </div>

                                                    }

                                                    if ( order.status === 'delivered' ) {
                                                        color = 'green'
                                                        status = 'Delivered'

                                                        return  <Link to={'/our_order/' + order.id } key={index} className="profiletemplate_div_middle_main_list" >
                                                                    <div className="profiletemplate_div_middle_main_list_id" > {'TF'+order.id+'T56T6789E' +  order.id} </div>
                                                                    <div className="profiletemplate_div_middle_main_list_date" > {order.created_at} </div>
                                                                    <div className="profiletemplate_div_middle_main_list_status" style={{color:color}} > {status} </div>
                                                                </Link>

                                                    }

                                                    if ( order.status === 'paid' ) {
                                                        color = 'orange'
                                                        status = 'Pending'

                                                        return  <Link to={'/our_order/' + order.id } key={index} className="profiletemplate_div_middle_main_list" >
                                                                    <div className="profiletemplate_div_middle_main_list_id" > {'TF'+order.id+'T56T6789E' +  order.id} </div>
                                                                    <div className="profiletemplate_div_middle_main_list_date" > {order.created_at} </div>
                                                                    <div className="profiletemplate_div_middle_main_list_status" style={{color:color}} > {status} </div>
                                                                </Link>

                                                    }

                                                    if ( order.status === 'in_transit' ) {
                                                        color = 'rgb(9, 123, 184)'
                                                        status = 'In Transit'

                                                        return  <Link to={'/our_order/' + order.id } key={index} className="profiletemplate_div_middle_main_list" >
                                                                    <div className="profiletemplate_div_middle_main_list_id" > {'TF'+order.id+'T56T6789E' +  order.id} </div>
                                                                    <div className="profiletemplate_div_middle_main_list_date" > {order.created_at} </div>
                                                                    <div className="profiletemplate_div_middle_main_list_status" style={{color:color}} > {status} </div>
                                                                </Link>

                                                    }

                                                    else{
                                                        return null
                                                    }

                                                })
                                                
                                                : <EmptyOrder/>

                                            }

                                            </div>

                                        </div>

                             </>

          }
        }
      }

















      return ( 
        
        <>

          <ProfileHeader
            title="All Orders"
            goback={ goBack }
            />

            {what_to_return}

        </>  

      );

}

export default AllOrderListPage;