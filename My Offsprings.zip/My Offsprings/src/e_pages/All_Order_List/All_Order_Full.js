import React,{useState,useEffect} from 'react';
import { CheckoutPreviewTemplate,OrderChangestatusbtn } from '../check_out/check_out_template';
import LoadingPage from '../../component/utilities/loading/loading';
import OppsPage from '../../component/utilities/oppspage/oppspage';
import Axios from 'axios';
import { OrderItem } from '../cart_page/item';
import ProfileHeader from '../../layout_components/profile_header/profile_header';
import TopbannerDiv from '../../component/top-banner-msg/topbannermsg';
import BtnSpin from '../../component/utilities/btnSpin/btnSpin';
import { useMonth } from '../check_out/useMonth';



const EditOrderPage = (props) => {

      const Orid = props.match.params.id


      const [ Loadingpage , setLoadingpage ] = useState(false)
      const [ Errorpage , setErrorpage ] = useState(false)  
      const [ Msg , setMsg ] = useState({
        bg:'',
        msg:'',
        value:false
      })
      const [ OrderAddress , setOrderAddress ] = useState(null)
      const [ DeliveryDate , setDeliveryDate ] = useState(null)

      const [ Order , setOrder ] = useState(null)
      const [ Disabled , setDisabled ] = useState(false)




      



      useEffect( () => {

        setErrorpage(false)
        setLoadingpage(true)


        Axios.get('/myorder/myorder/' + Orid + '/' ).then(

          response => {

            var another_response = response.data

            Axios.get('/myaccount/users/' + response.data.user.id + '/').then(

              response => {
                setOrder(another_response)
                setErrorpage(false)
                setLoadingpage(false)  
                setOrderAddress(response.data.address)
              }

            ).catch(
              
              e => {
                setErrorpage(true)
                setLoadingpage(false)
              }

            )
            

          }

      ).catch(

          e => {
              setErrorpage(true)
              setLoadingpage(false)
          }

      )


      },[Orid] )




    const change_to_intransit = (status) => {

      setMsg({
        bg:'orange',
        msg:'Changing Order Status to ' + status ,
        value:true
      })
      setDisabled(true)

      Axios.patch( '/myorder/myorder/' + Order.id + '/' , { status: status } 
      ).then( response => {

        setOrder({
          ...Order,
          status:status
        })

        setMsg({
          bg:'rgb(39, 180, 39)',
          msg:'Order Status Changed Successfully to ' + status ,
          value:true
        })
        setDisabled(false)

      } ).catch(

        e => {
          setMsg({
            bg:'red',
            msg:'Something Wrong' ,
            value:true
          })
          setDisabled(false)
        }

      )

    }








    const GetMonth = (number) => {
      const [month] = useMonth(number)
      return month
    }


    const Addtodeliv = (fulldate) => {

      setDeliveryDate({
        day:fulldate.day,
        month:fulldate.month,
        year:fulldate.year
      })

    }




    

    if( Order && !DeliveryDate ){

      var longest = 0

      for (let u = 0; u < Order.items.length; u++) {
        
        var day_to = parseInt(Order.items[u].product.days_to)

        if ( day_to > longest ) {
            longest = day_to
        }

      }

      const event = new Date(Order.create_date);

      event.setDate(event.getDate() + longest);

      const first_day = event.getDay()

        if ( first_day === 0 ) {

          var some = new Date(Order.create_date)
          var newlongest = longest + 3

          some.setDate(some.getDate() + newlongest)

          const theyear = some.getFullYear()
          const themonth = some.getMonth()

          const readymonth = GetMonth(themonth)
      
          
          var Datetosend = {
            day:some.getDate(),
            month:readymonth,
            year:theyear
          }

          Addtodeliv(Datetosend)
        }

        if ( first_day === 1 ) {

           some = new Date(Order.create_date)
          newlongest = longest + 5
          some.setDate(some.getDate() + newlongest)

          const theyear = some.getFullYear()
          const themonth = some.getMonth()

          const readymonth = GetMonth(themonth)
      
          
           Datetosend = {
            day:some.getDate(),
            month:readymonth,
            year:theyear
          }

          Addtodeliv(Datetosend)
        }

        if ( first_day === 2 ) {

          some = new Date(Order.create_date)

          newlongest = longest + 4

          some.setDate(some.getDate() + newlongest)

          const theyear = some.getFullYear()
          const themonth = some.getMonth()

          const readymonth = GetMonth(themonth)
      
          
           Datetosend = {
            day:some.getDate(),
            month:readymonth,
            year:theyear
          }

          Addtodeliv(Datetosend)
        }

        if ( first_day === 3 ) {

          some = new Date(Order.create_date)

          newlongest = longest + 3

          some.setDate(some.getDate() + newlongest)

          const theyear = some.getFullYear()
          const themonth = some.getMonth()

          const readymonth = GetMonth(themonth)
      
          
          Datetosend = {
            day:some.getDate(),
            month:readymonth,
            year:theyear
          }

          Addtodeliv(Datetosend)
        }

        if ( first_day === 4 ) {

          some = new Date(Order.create_date)

          newlongest = longest + 6

          some.setDate(some.getDate() + newlongest)

          const theyear = some.getFullYear()
          const themonth = some.getMonth()

          const readymonth = GetMonth(themonth)
          
          Datetosend = {
            day:some.getDate(),
            month:readymonth,
            year:theyear
          }

          Addtodeliv(Datetosend)
        }

        if ( first_day === 5 ) {

          some = new Date(Order.create_date)
          
          newlongest = longest + 5

          some.setDate(some.getDate() + newlongest)

          const theyear = some.getFullYear()
          const themonth = some.getMonth()

          const readymonth = GetMonth(themonth)
      
          
          Datetosend = {
            day:some.getDate(),
            month:readymonth,
            year:theyear
          }

          Addtodeliv(Datetosend)
        }

        if ( first_day === 6 ) {

          some = new Date(Order.create_date)

          newlongest = longest + 4

          some.setDate(some.getDate() + newlongest)

          const theyear = some.getFullYear()
          const themonth = some.getMonth()

          const readymonth = GetMonth(themonth)
      
          
          Datetosend = {
            day:some.getDate(),
            month:readymonth,
            year:theyear
          }

          Addtodeliv(Datetosend)
        }

      
    }
    
    if ( DeliveryDate ) {
      var date = DeliveryDate.day.toString()
      var number = date[date.length - 1]

      if ( date === '11' || date === '12' || date === '13' || date === '14' || date === '15' || date === '16' || date === '17' || date === '18' || date === '19' ) {
        var back = 'th'
      }else{
        if ( number === '4' || number === '5' || number === '6' || number === '8' || number === '9' || number === '0' ) {
           back = 'th'
        }else{
          if ( number === '1' ) {
            back = 'st'
          }
          if( number === '2' ){
            back = 'nd'
          }
          if ( number === '3' ) {
            back = 'rd'            
          }
        }
      }

    }else{

    }








      const gogo = () => {
        props.history.go()
      } 
    
      const goBack = () => {
        props.history.goBack()
      }







      if ( Order ) {
        
          if ( Order.status === 'paid' ) {
            var btntoshow = <button className="real_checkout_btn-sbt-btn" style={{background:'orange',textTransform:'uppercase'}} disabled={Disabled} onClick={ () => change_to_intransit('in_transit') } > { Disabled ? <BtnSpin bgColor="white" /> : 'Change To In-Transit' } </button>
          }

          if( Order.status === 'created' ){
               btntoshow = <button className="real_checkout_btn-sbt-btn" style={{background:'red'}} disabled={Disabled} > { Disabled ? <BtnSpin bgColor="white" /> : 'Change To In-Transit' } </button>
          }

          if( Order.status === 'in_transit' ){
            btntoshow = <button className="real_checkout_btn-sbt-btn" style={{background:'rgb(9, 123, 184)'}} disabled={Disabled}  onClick={ () => change_to_intransit('delivered') } > { Disabled ? <BtnSpin bgColor="white" /> : 'Change To Delivered' } </button> 
          }

          if( Order.status === 'delivered' ){
            btntoshow = <button className="real_checkout_btn-sbt-btn" style={{background:'rgb(39, 180, 39)'}} disabled={Disabled}  > Delivered </button>          
          }
      }












    
    
      if( Loadingpage && !Order && !Errorpage ){
        var what_to_return = <LoadingPage/>
      }else{
        if ( !Loadingpage && Errorpage && !Order ) {
          what_to_return = <OppsPage tryagain={gogo} goback={goBack} />
        }else{
          if ( !Loadingpage && !Errorpage && Order ) {
            what_to_return = <>



                                    <CheckoutPreviewTemplate
                                        items={ 

                                            <> 
                                                
                                                { Order.items.length > 0 ? 



                                                    Order.items.map( ( item , index ) => {              

                                                        return <OrderItem
                                                                    key={index}
                                                                    img={ item.product.product_img1 }
                                                                    product_name={ item.product.myproduct_name }
                                                                    size={ item.size ? item.size.size : null }
                                                                    color={ item.colour ? item.colour.colour : null }
                                                                    quantity={ item.quantity }
                                                                    unit_price={ item.product.selling_price }
                                                                    sub_total={ item.product.selling_price * item.quantity }
                                                                />
                                                    } )

                                                : null }

                                            </>

                                         } 
                                        items_length={ Order.items.length }
                                        address_to_show={false}    
                                        address={ OrderAddress ? OrderAddress.address : null }
                                        lga={ OrderAddress ? OrderAddress.lga : null }
                                        state={ OrderAddress ? OrderAddress.state : null }
                                        delivery_date={ DeliveryDate ? DeliveryDate.day + back + ' of ' + DeliveryDate.month + ' ' + DeliveryDate.year : null }
                                    > 
                                    
                                        <OrderChangestatusbtn
                                          transport_cost={ Order.get_tfare }
                                          all_total={ Order.total_cost }> 

                                            {btntoshow}

                                        </OrderChangestatusbtn>

                                    </CheckoutPreviewTemplate>




                            </>
          }
        }
      }
    

      return (
        
        <>

              <TopbannerDiv 
                backgroundcolor={Msg.bg} 
                show={Msg.value}
                message={Msg.msg}
                closeshow={ () => setMsg({...Msg,value:false}) }
                />

            <ProfileHeader
              title="Order"
              goback={goBack}
            />

            {what_to_return}

        </>

      );

}

export default EditOrderPage;