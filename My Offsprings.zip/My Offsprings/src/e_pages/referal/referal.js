import React,{useContext,useEffect,useState} from 'react';
import ProfileHeader from '../../layout_components/profile_header/profile_header';
import RefImg from '../../component/utilities/img/317.jpg';
import HandiImg from "../../component/utilities/img/hand.png";
import { CopyToClipboard } from "react-copy-to-clipboard";
import Store from '../../store/managementstore/managementstore';
import Axios from 'axios';
import TopbannerDiv from '../../component/top-banner-msg/topbannermsg';
import LoadingPage from '../../component/utilities/loading/loading';
import OppsPage from '../../component/utilities/oppspage/oppspage';
import {AiOutlinePaperClip } from 'react-icons/ai';
import {GiWallet} from 'react-icons/gi';
import { FaWhatsappSquare, FaFacebookSquare, FaTwitterSquare, FaLinkedinIn, FaTelegram } from 'react-icons/fa';
import {
    FacebookShareButton,
    LinkedinShareButton,
    TelegramShareButton,
    TwitterShareButton,
    WhatsappShareButton
  } from "react-share";



const ReferalPage = (props) => { 

    const context = useContext(Store)

    const [ referal_list , setreferal_list ] = useState(null)
    const [ Loadingpage , setLoadingpage ] = useState(false)
    const [ Errorpage , setErrorpage ] = useState(false)
    const [ Wallet , setWallet ] = useState(0)
  
    const [ CopyToClipboardState , setCopyToClipboardState ] = useState({
        status:false,
        message:'Referal Link Has Been Copied To Clipboard',
        bgColor:'rgba(13, 194, 94, 0.986)',
        btn:false
    })
    const CopyingToClipboard = () => {
        setCopyToClipboardState({ ...CopyToClipboardState , message:'Referal Link Has Been Copied To Clipboard', status:true , bgColor:'rgba(13, 194, 94, 0.986)' })
    }

    useEffect( () => {

        setErrorpage(false)
        setLoadingpage(true)

        Axios.get('/myaccount/users/' + context.User_id + '/' ).then(

            response => {

                setreferal_list(response.data.referees)
                setErrorpage(false)
                setLoadingpage(false)
                setWallet(response.data.pro.balance)
        
            }

        ).catch(
            e => {
                setErrorpage(true)
                setLoadingpage(false)        
            }
        )

    } , [context.User_id] )



    const gogo = () => {
        props.history.go()
      } 
    
      const goBack = () => {
        props.history.goBack()
      }


    if( Loadingpage && !referal_list && !Errorpage ){
        var what_to_return = <LoadingPage/>
      }else{
        if ( !Loadingpage && Errorpage && !referal_list ) {
          what_to_return = <OppsPage tryagain={gogo} goback={goBack} />
        }else{
          if ( !Loadingpage && !Errorpage && referal_list ) {
            what_to_return = <>

            <TopbannerDiv
                backgroundcolor={CopyToClipboardState.bgColor}
                closeshow={
                    () => setCopyToClipboardState({
                        ...CopyToClipboardState,status:false
                    })
                }
                message={CopyToClipboardState.message}
                show={CopyToClipboardState.status}
            />

            <div className="main_referal_div">

                <div className="main_referal_div_first">


                    <div className="main_referal_div_first_wallet">

                        <GiWallet
                            href="contact.svg#icon-wallet" 
                            className="main_referal_div_first_wallet_ic"
                        />

                        <div className="main_referal_div_first_wallet_narrate" >
                             Wallet Balance
                        </div>

                        <div className="main_referal_div_first_wallet_amount">
                            ₦ {new Intl.NumberFormat({ style: 'currency', currency: 'EUR' }).format(Wallet) }
                        </div>
                        
                    </div>


                    <div className="main_referal_div_first_linkdiv">

                        <div className="main_referal_div_first_linkdiv_title">
                                My Referal Link
                        </div>

                        <div className="main_referal_div_first_linkdiv_linkdivtwo">

                            <div className="main_referal_div_first_linkdiv_linkdivtwo_linkbox">
                                https://www.myoffsprings.com/referid{context.User_id}  
                            </div>

                            <CopyToClipboard text={'https://www.myoffsprings.com/referid'+context.User_id}
                                onCopy={CopyingToClipboard}>
                                <div className="main_referal_div_first_linkdiv_linkdivtwo_copybox" >
                                    <AiOutlinePaperClip className="main_referal_div_first_linkdiv_linkdivtwo_copybox_ic" />
                                </div>
                            </CopyToClipboard>

                        </div>
                        
                        <div className="main_referal_div_first_linkdiv_sharetext">
                            Share On
                        </div>

                        <div className="main_referal_div_first_linkdiv_socialboxes">

                            <WhatsappShareButton className="referf"  
                                url={ "https://www.myoffsprings.com/referid" + context.User_id }
                                title=" You will not believe how much i saved making a purchase on" >
                                <div className="main_referal_div_first_linkdiv_socialboxes_boxone">
                                    <FaWhatsappSquare 
                                    className="main_referal_div_first_linkdiv_socialboxes_boxone_ic"
                                    />
                                </div>
                            </WhatsappShareButton>

                            <FacebookShareButton quote=" You will not believe how much i saved making a purchase on" className="referf" url={ "https://www.myoffsprings.com/referid" + context.User_id }>
                                <div className="main_referal_div_first_linkdiv_socialboxes_boxone">
                                    <FaFacebookSquare  
                                        className="main_referal_div_first_linkdiv_socialboxes_boxone_ic"
                                    />
                                </div>  
                            </FacebookShareButton> 

                            <TwitterShareButton title=" You will not believe how much i saved making a purchase on" className="referf" url={ "https://www.myoffsprings.com/referid" + context.User_id }>
                                <div className="main_referal_div_first_linkdiv_socialboxes_boxone">                                
                                    <FaTwitterSquare 
                                        className="main_referal_div_first_linkdiv_socialboxes_boxone_ic"
                                    />
                                </div>
                            </TwitterShareButton>

                            <LinkedinShareButton summary=" You will not believe how much i saved making a purchase on" className="referf" url={ "https://www.myoffsprings.com/referid" + context.User_id }>
                                <div className="main_referal_div_first_linkdiv_socialboxes_boxone">
                                    <FaLinkedinIn 
                                        className="main_referal_div_first_linkdiv_socialboxes_boxone_ic"
                                    />
                                </div>
                            </LinkedinShareButton>

                            <TelegramShareButton title=" You will not believe how much i saved making a purchase on" className="referf" url={ "https://www.myoffsprings.com/referid" + context.User_id }>
                                <div className="main_referal_div_first_linkdiv_socialboxes_boxone">
                                    <FaTelegram 
                                        className="main_referal_div_first_linkdiv_socialboxes_boxone_ic"
                                    />
                                </div>
                            </TelegramShareButton>

                        </div>
                        
                    </div>    

                </div>


                <div className="main_referal_div_third">

                    <div className="main_referal_div_third_right" >
                        <img src={RefImg} alt="" className="main_referal_div_third_right-img" />
                    </div>

                    <div className="main_referal_div_third_termslist">


                        <div className="main_referal_div_third_title">
                            Terms & Conditions
                        </div>

                        <li className="main_referal_div_third_termslist_li" >
                            By participating in the Program, you agree to and are bound 
                            by the Program Terms and Conditions. If you do not wish to 
                            agree to and abide by the Program Terms and Conditions in their 
                            entirety, you are not authorized to participate in the Program.
                        </li>

                        <li className="main_referal_div_third_termslist_li" >
                            To be eligible for participation in the program, 
                            the Referrer must be a current Customer of MyOffsprings. 
                            Both the Referrer and the Referred must be at least 18 years of age. 
                            MyOffsprings reserves the right to find ineligible any participant 
                            in the program at its sole discretion.
                        </li>

                        <li className="main_referal_div_third_termslist_li" >
                            Rewards may be taxable, depending on the value of the item and the federal, 
                            state, and local tax laws applicable to the participant. Participants are 
                            solely responsible for reporting such items on their tax returns and paying 
                            any associated tax liability.
                        </li>

                        <li className="main_referal_div_third_termslist_li" >
                            You entitled to a certain percentage of our profit on every 
                            transaction everyone who signed up on MyOffsprings using your 
                            referral link. This reward will be deposited on you MyOffsprings 
                            wallet and can be used to purchase anything on MyOffsprings platform 
                            at all. And the case what you’re purchasing is more expensive than what 
                            you have in you wallet, you’d have to pay using your debit card after the 
                            amount in your wallet had been deducted from the total cost of the product.
                        </li>


                        <li className="main_referal_div_third_termslist_li" >
                            MyOffsprings may, in its sole and absolute discretion, 
                            cancel, change, suspend, or modify any aspect of the Program 
                            or Program Terms and Conditions at any time, without notice. 
                            MyOffsprings may, in its sole and absolute discretion, terminate 
                            or suspend any Member’s participation in the Program for breach of 
                            these Program Terms and Conditions or taking any actions that are 
                            inconsistent with the intent of these Program Terms and Conditions. 
                        </li>

                        <li className="main_referal_div_third_termslist_li" >
                            Offspring reserves the right to cancel or suspend the program, 
                            in its sole discretion, that the administration, security, or 
                            fairness of the Program has been compromised in any way
                        </li>

                    </div>

                </div>
 
                <div className="main_referal_div_friends" >

                    <div className="main_referal_div_friends_top" > My Friends </div>

                        { referal_list && referal_list.length !== 0 ?

                            referal_list.map( ( refer , index ) => {

                                return  <div className="profiletemplate_div_top_referal_link" key={index} >
                                            <div className="profiletemplate_div_top_referal_link_name" > {refer.username} </div>
                                            {/* <div className="profiletemplate_div_top_referal_link_amount" > ₦5000 </div> */}
                                        </div>

                            } )

                            :
                        <div className="profiletemplate_div_middle_main_empty" >
                            <img src={HandiImg} alt="" className="profiletemplate_div_middle_main_empty_img" />
                            <div className="profiletemplate_div_middle_main_empty_text" > You Have Not Refered Anyone </div>
                            {/* <Link className="profiletemplate_div_middle_main_empty_btn" to="/" > Start Refering </Link> */}
                        </div>
                        }

                </div>

            </div>
            

                            </>
          }
        }
      }


      return ( 
          <>

            <ProfileHeader
                title="My Referal"
                goback={ goBack }
            />

            {what_to_return}

          </>
      );

}

export default ReferalPage;