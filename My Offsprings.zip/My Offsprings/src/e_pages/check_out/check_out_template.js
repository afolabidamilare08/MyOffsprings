import React from 'react';
import {AiOutlinePlus} from 'react-icons/ai';
import {FaMapMarkedAlt} from 'react-icons/fa';
import { InputWithLabel, LoginTextarea, LoginBtn } from '../../component/login_components/login_components';

// const url = 'https://myoffsprings.xyz'


export const OproductList = (props) => {

    return (

        <div className="orductList_div" >

            <div className="orductList_div-product" >

                <div className="orductList_div-product-pic" >
                    <img className="orductList_div-product-pic-img" alt="" src={props.img} />
               </div>

                <div className="orductList_div-product-det" >
                
                    <div className="orductList_div-product-det_name" > {props.product_name} </div>

                    <div style={{
                        display:'flex'
                    }} >

                        { props.size ? 
                            
                            <div className="orductList_div-product-det_split" >
                                <span className="orductList_div-product-det_split-1" > size : </span> 
                                <span className="orductList_div-product-det_split-2" > {props.size} </span>
                            </div>

                        : null }

                        { props.color ? 
                        
                            <div className="orductList_div-product-det_split" style={{marginLeft:'1rem'}} >
                                <span className="orductList_div-product-det_split-1" > color : </span> 
                                <span className="orductList_div-product-det_split-2" > {props.color} </span>
                            </div>

                        : null }

                    </div>

                </div>

            </div>

            <div className="orductList_div-qty" >
               {props.quantity}
            </div>

            <div className="orductList_div-price" >
                ₦ {new Intl.NumberFormat({ style: 'currency', currency: 'EUR' }).format(props.price)}
            </div>

        </div>

    );

}






export const CheckoutPreviewTemplate = (props) => {

    return (

        <div className="checkout-preview-template" >

            <div className="checkout-preview-template_left" >

                <div className="checkout-preview-template_left_top" >
                    
                    <div className="checkout-preview-template_left_top_product" >
                        Order Items ({props.items_length})
                    </div>

                </div>

                {props.items}

                {props.children}

            </div>

            <div className="checkout-preview-template_right" >

                <div className="checkout-preview-template_right-delivery" >

                    <div className="checkout-preview-template_right-delivery_top" >
                        Delivery Information
                    </div>

                    <div className="checkout-preview-template_right-delivery_tag" >
                        Delivery Address
                    </div>

                    <div className="checkout-preview-template_right-delivery_det" >
                        {props.address} , {props.lga} , {props.state}
                    </div>

                    { props.address_to_show ? 
                        <button className="checkout-preview-template_right-delivery_btn" onClick={props.openAdpanel} >
                            <FaMapMarkedAlt className="checkout-preview-template_right-delivery_btn-ic " /> change address delivery
                        </button>
                    : null }

                    <div className="checkout-preview-template_right-delivery_tag" >
                        Delivery Date
                    </div>

                    <div className="checkout-preview-template_right-delivery_det" >
                        {props.delivery_date}
                    </div>

                </div>

                <div className="checkout-preview-template_right-policy" >

                    <div className="checkout-preview-template_right-delivery_top" >
                        Return Policy
                    </div>

                    <div className="productdetailtemplate-div_first-delivery-delivery-policy" >
                            This policy only applies to returnable goods from N1000 upward
                            <br/>

                            {/* <div className="productdetailtemplate-div_first-delivery-delivery-policy-title" >REFUND ONLINE POLICY</div> */}
                            You can return all eligible item(s) within 7 business days to any selected MyOffspring Pickup Stations.

                            <div className="productdetailtemplate-div_first-delivery-delivery-policy-title" >PREPARE THE ITEM</div>
                            Place the item in its original packaging, including any accessories, tags, labels or freebies otherwise,
                            your return will be invalid.

                            <div className="productdetailtemplate-div_first-delivery-delivery-policy-title" >DROP OFF THE ITEMS OR SCHEDULE A PICK UP</div>
                            Return the item at our pickup stations or we can pick up from you within 1 - 4 business days (Transport will be deducted).
                            Always ensure your return slip is signed by our agents as your proof of return.


                            <div className="productdetailtemplate-div_first-delivery-delivery-policy-title" >REFUND PROCESSED</div>
                            Once we receive your returned item, we will inspect it and process your refund within 10 business days 
                            into your back account or wallet.

                        </div>

                </div>

            </div>

        </div>

    );

}








export const ChooseLocationDiv = (props) => {

    return(

        <div className="chooselocation_div" style={{
            display: props.show ? 'block' : 'none'
        }} >

            <div className="chooselocation_div-top" >

                <div className="chooselocation_div-top_title" >
                    Delivery Address
                </div>

                <AiOutlinePlus className="chooselocation_div-top_cancel" onClick={props.closeshow} />

            </div>

            <div className="chooselocation_div-msg" style={{
                color: props.msg_color,
                display: props.msg_display,
                padding:'.5rem 1rem',
                textAlign:'center'
            }} >
                {props.msg}
            </div>

            <form className="chooselocation_div-form" onSubmit={props.submit} >


                <div className="inputwithlabel" >
                    <label className="inputwithlabel_label" > State </label>
                    <div className="inputwithlabel_input" style={{
                        fontSize:'1.4rem',
                    }} > {props.state}  </div>
                </div>

                <InputWithLabel
                    label="Local Government Area"
                    value={props.lga}
                    onChange={props.changelga}
                />

                <LoginTextarea
                    label="Home Address"
                    value={props.address}
                    onChange={props.changeaddress}
                />

                <LoginBtn
                    value={props.btn}
                    disabled={props.disabled}
                />

            </form>

        </div>

    );

}

















export const CheckoutBtn = (props) => {

    var transport = parseInt(props.transport)
    var product_total = parseInt(props.product_total)
    var wallet_balance = parseInt(props.wallet_balance)
    
    var all_cost = transport + product_total

    if( wallet_balance < all_cost || wallet_balance === 0 ){

        return(

            <div className="real_checkout_btn" >
                
                <div className="real_checkout_btn-top" > 
                    <div className="real_checkout_btn-top_tit" > Total </div>
                    <div className="real_checkout_btn-top_fit" > ₦{new Intl.NumberFormat({ style: 'currency', currency: 'EUR' }).format(product_total)} </div>
                </div>

                <div className="real_checkout_btn-top" > 
                    <div className="real_checkout_btn-top_tit" > Transport </div>
                    <div className="real_checkout_btn-top_fit" > ₦{new Intl.NumberFormat({ style: 'currency', currency: 'EUR' }).format(transport)} </div>
                </div>

                <div className="real_checkout_btn-next" >
                    ₦{new Intl.NumberFormat({ style: 'currency', currency: 'EUR' }).format(all_cost)}
                </div>

                <div className="real_checkout_btn-wall" >
                    <span className="real_checkout_btn-wall-left" > Wallet Balance </span>
                    <span className="real_checkout_btn-wall-right" > ₦{new Intl.NumberFormat({ style: 'currency', currency: 'EUR' }).format(wallet_balance)} </span>
                </div>

                <div className="real_checkout_btn-sbt" >
                    {props.btn}
                </div>

            </div>

        );

    }

    if( wallet_balance > all_cost ){

        return(

            <div className="real_checkout_btn" >

                <div className="real_checkout_btn-wall" style={{borderBottom:'0px'}} >
                    <span className="real_checkout_btn-wall-left" > Wallet Balance </span>
                    <span className="real_checkout_btn-wall-right" > ₦{new Intl.NumberFormat({ style: 'currency', currency: 'EUR' }).format(wallet_balance)} </span>
                </div>
                
                <div className="real_checkout_btn-top" > 
                    <div className="real_checkout_btn-top_tit" > Total </div>
                    <div className="real_checkout_btn-top_fit" > ₦{new Intl.NumberFormat({ style: 'currency', currency: 'EUR' }).format(product_total)} </div>
                </div>

                <div className="real_checkout_btn-top" > 
                    <div className="real_checkout_btn-top_tit" > Transport </div>
                    <div className="real_checkout_btn-top_fit" > ₦{new Intl.NumberFormat({ style: 'currency', currency: 'EUR' }).format(transport)} </div>
                </div>

                <div className="real_checkout_btn-next" style={{borderBottom:'1px solid lightgray',marginBottom:'1rem'}} >
                    ₦{new Intl.NumberFormat({ style: 'currency', currency: 'EUR' }).format(all_cost)}
                </div>

                <div className="real_checkout_btn-sbt" >
                    {props.btn}
                </div>

            </div>

        );

    }
    
    else{

        return <h1>comming</h1>

    }

}





export const Orderstatusbtn = (props) => {

    var transport = parseInt(props.transport_cost)
    var product_total = parseInt(props.all_total)
    
    var all_cost = transport + product_total


    return (

        <div className="real_checkout_btn" >

            <div className="real_checkout_btn-top" > 
                <div className="real_checkout_btn-top_tit" > Total </div>
                <div className="real_checkout_btn-top_fit" > ₦{new Intl.NumberFormat({ style: 'currency', currency: 'EUR' }).format(product_total)} </div>
            </div>

            <div className="real_checkout_btn-top" > 
                <div className="real_checkout_btn-top_tit" > Transport </div>
                <div className="real_checkout_btn-top_fit" > ₦{new Intl.NumberFormat({ style: 'currency', currency: 'EUR' }).format(transport)} </div>
            </div>

            <div className="real_checkout_btn-next" style={{borderBottom:'1px solid lightgray',marginBottom:'1rem'}} >
                ₦{new Intl.NumberFormat({ style: 'currency', currency: 'EUR' }).format(all_cost)}
            </div>

            <div className="real_checkout_btn-sbt" >
                <button className="real_checkout_btn-sbt-btn" style={{background:props.backgroundcolor,textTransform:'uppercase'}} disabled={true} > {props.status} </button>
            </div>

        </div>

    );

}





export const OrderChangestatusbtn = (props) => {

    var transport = parseInt(props.transport_cost)
    var product_total = parseInt(props.all_total)
    
    var all_cost = transport + product_total


    return (

        <div className="real_checkout_btn" >

            <div className="real_checkout_btn-top" > 
                <div className="real_checkout_btn-top_tit" > Total </div>
                <div className="real_checkout_btn-top_fit" > ₦{new Intl.NumberFormat({ style: 'currency', currency: 'EUR' }).format(product_total)} </div>
            </div>

            <div className="real_checkout_btn-top" > 
                <div className="real_checkout_btn-top_tit" > Transport </div>
                <div className="real_checkout_btn-top_fit" > ₦{new Intl.NumberFormat({ style: 'currency', currency: 'EUR' }).format(transport)} </div>
            </div>

            <div className="real_checkout_btn-next" style={{borderBottom:'1px solid lightgray',marginBottom:'1rem'}} >
                ₦{new Intl.NumberFormat({ style: 'currency', currency: 'EUR' }).format(all_cost)}
            </div>

            <div className="real_checkout_btn-sbt" >
                {props.children}
            </div>

        </div>

    );


}