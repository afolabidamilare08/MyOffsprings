export const useMonth = (number) => {

    const months = ["January", "February", "March", "April", "May", "June", "July", "August", "September", "October", "November", "December"]

    var month = months[number]

      return [ month ]

    }


export const useDay = (number) => {

    const days = ["Sunday", "Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday"]

    var day = days[number]

        return [ day ]

    }    