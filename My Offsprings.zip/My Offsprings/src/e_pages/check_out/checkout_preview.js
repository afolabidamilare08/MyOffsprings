import React,{useState,useEffect,useContext} from 'react';
import { CheckoutPreviewTemplate, ChooseLocationDiv , CheckoutBtn } from './check_out_template';
import LoadingPage from '../../component/utilities/loading/loading';
import OppsPage from '../../component/utilities/oppspage/oppspage';
import BtnSpin from '../../component/utilities/btnSpin/btnSpin';
import Axios from 'axios';
import { OrderItem } from '../cart_page/item';
import Store from '../../store/managementstore/managementstore';
import ProfileHeader from '../../layout_components/profile_header/profile_header';
import { useMonth } from './useMonth';
import {PaystackButton } from 'react-paystack';     
import OrderErrorPage from '../../component/utilities/oppspage/order_error';


const CheckoutPreviewPage = (props) => {

      const Orid = props.match.params.id
      const context = useContext(Store)
      const REACT_APP_PAYSTACK_TEST_KEY = process.env.REACT_APP_PAYSTACK_KEY


      const [ Loadingpage , setLoadingpage ] = useState(false)
      const [ Errorpage , setErrorpage ] = useState(false)  
      const [ openAddressform , setopenAddressform ] = useState({
          status:true
      })
      const [ Order , setOrder ] = useState(null)
      const [ OrderAddress , setOrderAddress ] = useState(null)
      const [ EditOrderAddress , setEditOrderAddress ] = useState(null)
      const [ AddressStatus , setAddressStatus ] = useState({
        loading:false,
        error:false,
        msg:''
      })
      const [ DeliveryDate , setDeliveryDate ] = useState(null)
      const [ OrderError , setOrderError ] = useState(false)




      



      useEffect( () => {

        setErrorpage(false)
        setLoadingpage(true)


        Axios.get('/myorder/myorder/' + Orid + '/' ).then(

            response => {

                  if ( response.data.status === 'paid' || response.data.status === 'in_transit' || response.data.status === 'delivered' ) {
                    props.history.push('/my_order/'+response.data.id)
                  }else{

                    var another_response = response.data

                    Axios.get('/myaccount/users/' + context.User_id + '/').then(

                      response => {
                        setOrder(another_response)
                        setErrorpage(false)
                        setLoadingpage(false)  
                        setOrderAddress(response.data.address)
                        setEditOrderAddress(response.data.address)
                      }

                    ).catch(
                      
                      e => {
                        setErrorpage(true)
                        setLoadingpage(false)
                      }

                    )
                    
                     }
                  
                }

        ).catch(

            e => {
                setErrorpage(true)
                setLoadingpage(false)
            }

        )
// eslint-disable-next-line
      },[Orid] )




      const GetMonth = (number) => {
        const [month] = useMonth(number)
        return month
      }


      const Addtodeliv = (fulldate) => {

        setDeliveryDate({
          day:fulldate.day,
          month:fulldate.month,
          year:fulldate.year
        })

      }



      if( Order && !DeliveryDate ){

        var longest = 0

        for (let u = 0; u < Order.items.length; u++) {
          
          var day_to = parseInt(Order.items[u].product.days_to)

          if ( day_to > longest ) {
              longest = day_to
          }

        }

        const event = new Date(Order.create_date);

        event.setDate(event.getDate() + longest);

        const first_day = event.getDay()

          if ( first_day === 0 ) {

            var some = new Date(Order.create_date)
            var newlongest = longest + 3

            some.setDate(some.getDate() + newlongest)
  
            const theyear = some.getFullYear()
            const themonth = some.getMonth()
  
            const readymonth = GetMonth(themonth)
        
            
            var Datetosend = {
              day:some.getDate(),
              month:readymonth,
              year:theyear
            }

            Addtodeliv(Datetosend)
          }

          if ( first_day === 1 ) {

             some = new Date(Order.create_date)
            newlongest = longest + 5
            some.setDate(some.getDate() + newlongest)
  
            const theyear = some.getFullYear()
            const themonth = some.getMonth()
  
            const readymonth = GetMonth(themonth)
        
            
             Datetosend = {
              day:some.getDate(),
              month:readymonth,
              year:theyear
            }

            Addtodeliv(Datetosend)
          }

          if ( first_day === 2 ) {

            some = new Date(Order.create_date)

            newlongest = longest + 4

            some.setDate(some.getDate() + newlongest)
  
            const theyear = some.getFullYear()
            const themonth = some.getMonth()
  
            const readymonth = GetMonth(themonth)
        
            
             Datetosend = {
              day:some.getDate(),
              month:readymonth,
              year:theyear
            }

            Addtodeliv(Datetosend)
          }

          if ( first_day === 3 ) {

            some = new Date(Order.create_date)

            newlongest = longest + 3

            some.setDate(some.getDate() + newlongest)
  
            const theyear = some.getFullYear()
            const themonth = some.getMonth()
  
            const readymonth = GetMonth(themonth)
        
            
            Datetosend = {
              day:some.getDate(),
              month:readymonth,
              year:theyear
            }

            Addtodeliv(Datetosend)
          }

          if ( first_day === 4 ) {

            some = new Date(Order.create_date)

            newlongest = longest + 6

            some.setDate(some.getDate() + newlongest)
  
            const theyear = some.getFullYear()
            const themonth = some.getMonth()
  
            const readymonth = GetMonth(themonth)
            
            Datetosend = {
              day:some.getDate(),
              month:readymonth,
              year:theyear
            }

            Addtodeliv(Datetosend)
          }

          if ( first_day === 5 ) {

            some = new Date(Order.create_date)
            
            newlongest = longest + 5

            some.setDate(some.getDate() + newlongest)
  
            const theyear = some.getFullYear()
            const themonth = some.getMonth()
  
            const readymonth = GetMonth(themonth)
        
            
            Datetosend = {
              day:some.getDate(),
              month:readymonth,
              year:theyear
            }

            Addtodeliv(Datetosend)
          }

          if ( first_day === 6 ) {

            some = new Date(Order.create_date)

            newlongest = longest + 4

            some.setDate(some.getDate() + newlongest)
  
            const theyear = some.getFullYear()
            const themonth = some.getMonth()
  
            const readymonth = GetMonth(themonth)
        
            
            Datetosend = {
              day:some.getDate(),
              month:readymonth,
              year:theyear
            }

            Addtodeliv(Datetosend)
          }

        
      }

      if ( DeliveryDate ) {
        var date = DeliveryDate.day.toString()
        var number = date[date.length - 1]

        if ( date === '11' || date === '12' || date === '13' || date === '14' || date === '15' || date === '16' || date === '17' || date === '18' || date === '19' ) {
          var back = 'th'
        }else{
          if ( number === '4' || number === '5' || number === '6' || number === '8' || number === '9' || number === '0' ) {
             back = 'th'
          }else{
            if ( number === '1' ) {
              back = 'st'
            }
            if( number === '2' ){
              back = 'nd'
            }
            if ( number === '3' ) {
              back = 'rd'            
            }
          }
        }

      }else{

      }



      //  var yam = new Date()

      //  console.log(yam.getHours())






      const paymentCallback = (query) => {

        setOrderError(false)
        
        if ( query.wallet_will_drop ) {
          
          Axios.patch( '/myorder/myorder/' + Orid + '/' , { status: 'paid' }).then( 
              
            response => {     

              Axios.post('/myaccount/payment/',{amount:query.wallet_will_drop,profile:Order.user.id}).then(

                response => {

                  if(Order.user.pro.referer){
                    Axios.post( '/myaccount/income/' , {amount:Order.absolute_total,profile:Order.user.pro.referer} ).then(

                      response => {
                        context.Refresh_Cart()
                        props.history.push('/my_orders')
                      }
      
                    ).catch(
                      e => {
                        context.Refresh_Cart()
                        props.history.push('/my_orders')
                      }
                    )
                  }else{
                    context.Refresh_Cart()
                    props.history.push('/my_orders')
                  }

                }

              ).catch(

                e => {
                  context.Refresh_Cart()
                  props.history.push('/my_orders')
                }

              )


          } ).catch(

            e => {
              setOrderError(true)
            }

          )

        }else{

            Axios.patch( '/myorder/myorder/' + Orid + '/' , { status: 'paid' }).then( 
              
              response => {     

                      if(Order.user.pro.referer){
                        Axios.post( '/myaccount/income/' , {amount:Order.absolute_total,profile:Order.user.pro.referer} ).then(

                          response => {
                            context.Refresh_Cart()
                            props.history.push('/my_orders')
                          }
          
                        ).catch(
                          e => {
                            context.Refresh_Cart()
                            props.history.push('/my_orders')
                          }
                        )
                      }else{
                        context.Refresh_Cart()
                        props.history.push('/my_orders')
                      }


            } ).catch(

              e => {
                setOrderError(true)
              }

            )

        }

    }





    const EditAddressHandler = (e) => {

        e.preventDefault()
        setAddressStatus({
          loading:true,
          error:false,
          msg:''
        })

        if( EditOrderAddress.lga === '' || EditOrderAddress.address === '' ){
          setAddressStatus({
            loading:false,
            error:true,
            msg:'All Fields Should Be Filled'
          })
        }else{

          Axios.patch('/myaccount/myaddress/' + OrderAddress.id + '/',{
            address:EditOrderAddress.address,
            lga:EditOrderAddress.lga,
            state:'Oyo',
          }).then(

            response => {

              setAddressStatus({
                loading:false,
                error:false,
                msg:''
              })
              setOrderAddress({
                ...OrderAddress,
                address:EditOrderAddress.address,
                lga:EditOrderAddress.lga,
                state:'Oyo'
              })
              setopenAddressform({...openAddressform,status:false})

            }

          ).catch(

            e => {
              setAddressStatus({
                loading:false,
                error:true,
                msg:'Something Went Wrong'
              })
            }

          )

        }

    }



    if ( Order ) {
      
      var absolute = parseInt(Order.absolute_total) 
      var Wallet_balance = parseInt(Order.user.pro.balance)

      if ( Wallet_balance > 0 ) {

        if ( Wallet_balance > absolute ) {
          // no paystack
          var amount_to_pay = absolute
          var wallet_will_drop = absolute
          var btn_final = <button 
                            className='className="real_checkout_btn-sbt-btn'
                            onClick={ () => paymentCallback({wallet_will_drop:wallet_will_drop}) } >  Complete your order of ₦{new Intl.NumberFormat({ style: 'currency', currency: 'EUR' }).format(Order.absolute_total)} with wallet </button>
        } 

        if ( absolute > Wallet_balance && Wallet_balance > 0 ) {
          // paystack
          amount_to_pay = absolute - Wallet_balance
          wallet_will_drop = Wallet_balance
          btn_final = 
          // <button className="real_checkout_btn-sbt-btn" onClick={ () => paymentCallback({wallet_will_drop:wallet_will_drop}) } >  Pay ₦ + {new Intl.NumberFormat({ style: 'currency', currency: 'EUR' }).format(Order.absolute_total)} </button>
          <PaystackButton
                        reference = { (new Date()).getTime() }
                        email = { Order.user.email }
                        amount = { amount_to_pay + '00' }
                        publicKey={REACT_APP_PAYSTACK_TEST_KEY}
                        text = { 'Pay ₦' + new Intl.NumberFormat({ style: 'currency', currency: 'EUR' }).format(amount_to_pay)}
                        onSuccess={ () => paymentCallback({wallet_will_drop:wallet_will_drop}) }
                        className="real_checkout_btn-sbt-btn"
                      />
        }
        
      }else{



         btn_final = 
        //  <button onClick={ () => paymentCallback({wallet_will_drop:null}) } className="real_checkout_btn-sbt-btn" >
        //                 Pay ₦{new Intl.NumberFormat({ style: 'currency', currency: 'EUR' }).format(Order.absolute_total)}
        //              </button>    
         <PaystackButton
            reference = { (new Date()).getTime() }
            email = { Order.user.email }
            amount = {Order.absolute_total + '00'}
            publicKey={ REACT_APP_PAYSTACK_TEST_KEY }
            text = { 'Pay ₦' + new Intl.NumberFormat({ style: 'currency', currency: 'EUR' }).format(Order.absolute_total)}
            onSuccess={ () => paymentCallback({wallet_will_drop:null}) }
            className='real_checkout_btn-sbt-btn'
          />
      }

    }









      const gogo = () => {
        props.history.go()
      } 
    
      const goBack = () => {
        props.history.goBack()
      }




    
    
      if( Loadingpage && !Order && !Errorpage ){
        var what_to_return = <LoadingPage/>
      }else{
        if ( !Loadingpage && Errorpage && !Order ) {
          what_to_return = <OppsPage tryagain={gogo} goback={goBack} />
        }else{
          if ( !Loadingpage && !Errorpage && Order ) {
            what_to_return = <>
                                    <div className="checkout_page-backdrop" style={{
                                        display: openAddressform.status ? 'block' : 'none'
                                    }} ></div>



                                    <ChooseLocationDiv
                                        show={ openAddressform.status }
                                        closeshow={ EditOrderAddress ?
                                          EditOrderAddress.address !== '' || EditOrderAddress.lga !== '' ? () => setopenAddressform({...openAddressform,status:false}) : null 
                                          : null }
                                        msg_color="tomato"
                                        msg={ AddressStatus.msg }
                                        submit={EditAddressHandler}
                                        msg_display={ AddressStatus.error ? 'display' : 'none' }
                                        address={ EditOrderAddress ? EditOrderAddress.address : null }
                                        lga={ EditOrderAddress ? EditOrderAddress.lga : null }
                                        state="Oyo"
                                        changelga={ EditOrderAddress ? (event) => setEditOrderAddress({...EditOrderAddress,lga:event.target.value}) : null }
                                        changeaddress={ EditOrderAddress ? (event) => setEditOrderAddress({...EditOrderAddress,address:event.target.value}) : null }
                                        btn={ AddressStatus.loading ? <BtnSpin bgColor="white" /> : "Edit Delivery Address" }
                                        disabled={ AddressStatus.loading }
                                        />





                                    <CheckoutPreviewTemplate 
                                        items={ 

                                            <> 
                                                
                                                { Order.items.length > 0 ? 

                                                    Order.items.map( ( item , index ) => {
                                                        return <OrderItem
                                                                    key={index}
                                                                    img={ item.product.product_img1 }
                                                                    product_name={ item.product.myproduct_name }
                                                                    size={ item.size ? item.size.size : null }
                                                                    color={ item.colour ? item.colour.colour : null }
                                                                    quantity={ item.quantity }
                                                                    unit_price={ item.product.selling_price }
                                                                    sub_total={ item.product.selling_price * item.quantity }
                                                                />
                                                    } )

                                                : null }

                                            </>

                                         } 
                                        address_to_show
                                        address={ OrderAddress ? OrderAddress.address : null }
                                        lga={ OrderAddress ? OrderAddress.lga : null }
                                        state={ OrderAddress ? OrderAddress.state : null }
                                        openAdpanel={ () => setopenAddressform({...openAddressform,status:true}) }
                                        items_length={ Order.items.length }
                                        delivery_date={ DeliveryDate ? DeliveryDate.day + back + ' of ' + DeliveryDate.month + ' ' + DeliveryDate.year : null }
                                    >

                                              <CheckoutBtn
                                                transport={ Order.get_tfare }
                                                wallet_balance={Order.user.pro.balance}
                                                product_total={ Order.total_cost }
                                                btn={btn_final}
                                            />

                                    </CheckoutPreviewTemplate>


                            </>
          }
        }
      }
    

      return (
        
        <>

            <ProfileHeader
              title="Checkout"
              goBack={goBack}
            />

            { OrderError ? <OrderErrorPage tryagain={ () => paymentCallback({wallet_will_drop:null}) } /> : what_to_return }

        </>

      );

}

export default CheckoutPreviewPage;