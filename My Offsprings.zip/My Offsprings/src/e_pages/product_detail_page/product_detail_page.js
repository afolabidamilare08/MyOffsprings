import React,{useState,useEffect,useContext} from 'react';
import { ProductTemplate, 
         ProductComposeComment, 
         ProductComposeReply, 
         Addtocartdiv, 
         BigImage, 
         CommentDiv, 
         ComposeReplyReply, 
         ReplyDiv } from './product_detail_template';
import CommentImg from './comment.png';
import Axios from 'axios';
import LoadingPage from '../../component/utilities/loading/loading';
import OppsPage from '../../component/utilities/oppspage/oppspage';
import Store from '../../store/managementstore/managementstore';
import BtnSpin from '../../component/utilities/btnSpin/btnSpin';

const ProductDetailPage = (props) => {

      const product_Id = props.match.params.id
      const context = useContext(Store) 

      const [ open_compose_comment , set_open_compose_comment ] = useState(false)
      const [ open_compose_reply , set_open_compose_reply ] = useState(false)
      const [ open_add_to_cart , setopen_add_to_cart ] = useState(false)
      const [ comment_list , setcomment_list ] = useState({
        list:[],
        pag_number:3
      })
      const [ commentToreply , setcommentToreply ]=useState({
        comment:null,
        value:'',
        error:false,
        loading:false,
        msg:''
      })
      const [ product , setproduct ] = useState(null)
      const [ loadstatus , setloadstatus ] = useState({ error:false,loading:false })
      const [ openbigimage , setopenbigimage ] = useState(false)
      const [ product_img , setproduct_img ] = useState({
        image_1:null,
        image_2:null,
        image_3:null,
        number:1
      })
      const [ Addcomment , setAddcomment ] = useState({
        value:'',
        error:false,
        loading:false,
        msg:''
      })

      const [ AddtocartDetails , setAddtocartDetails ] = useState({
        quantity:1,
        color:null,
        size:null,
        loading:false,
        error:false,
        success:false
      })



    useEffect( () => {

      setloadstatus({ error:false,loading:true})

      Axios.get('/myproduct/myproduct/' + product_Id + '/' ).then(

          response => {
            setproduct(response.data)
            setcomment_list({...comment_list,list:response.data.comments})
            setloadstatus({ error:false,loading:false})
            setproduct_img({
              image_1:response.data.product_img1,
              image_2:response.data.product_img2,
              image_3:response.data.product_img3,
              number:1
            })
          }

      ).catch(
        e => {
          setloadstatus({ error:true,loading:false })
        }
      )
// eslint-disable-next-line
    },[] )



      const HandlerToCart = (e) => {

        e.preventDefault()
        setAddtocartDetails({...AddtocartDetails,loading:true,error:false,success:false})

        if ( AddtocartDetails.quantity === '' || AddtocartDetails.quantity < 1 ) {
              setAddtocartDetails({...AddtocartDetails,loading:false,error:' Quantity Field Must Be Filled '})
        }else{

          if( product.colors.length > 0 || product.sizes.length > 0 ){

            if( product.colors.length > 0 && product.sizes.length < 1 ){
              if( !AddtocartDetails.color ){
                setAddtocartDetails({...AddtocartDetails,loading:false,error:' Select What Color You Want '})                   
            }else{

              const item_to_be_added = {
                myproduct_id:product.id,
                quantity:AddtocartDetails.quantity,
                colour_id:AddtocartDetails.color,
              }

              Axios.post( 'mycart/mycart/' + context.User_Cart.id + '/add_to_cart/' , item_to_be_added ).then(
                response => {
                  setAddtocartDetails({...AddtocartDetails,loading:false,error:false,success:'Item Was Added To Cart Successfully'})                   
                  context.Refresh_Cart()
                  setTimeout(() => {
                    setopen_add_to_cart(false)
                  }, 2000);
                }
              ).catch(
                e => {
                  setAddtocartDetails({...AddtocartDetails,loading:false,error:'Something Went Wrong'})                   
                }
              )

            }
            }else{
              if( product.colors.length < 1 && product.sizes.length > 0 ){
                if( !AddtocartDetails.size ){
                  setAddtocartDetails({...AddtocartDetails,loading:false,error:' Select What Size You Want '})                   
              }else{

                const item_to_be_added = {
                  myproduct_id:product.id,
                  quantity:AddtocartDetails.quantity,
                  size_id:AddtocartDetails.size
                }

                Axios.post( 'mycart/mycart/' + context.User_Cart.id + '/add_to_cart/' , item_to_be_added ).then(
                  response => {
                    setAddtocartDetails({...AddtocartDetails,loading:false,error:false,success:'Item Was Added To Cart Successfully'})                   
                    context.Refresh_Cart()                    
                    setTimeout(() => {
                      setopen_add_to_cart(false)
                    }, 2000);
                  }
                ).catch(
                  e => {
                    setAddtocartDetails({...AddtocartDetails,loading:false,error:'Something Went Wrong'})                   
                  }
                )

              }
              }else{
                if( product.colors.length > 0 && product.sizes.length > 0 ){
                  
                  if( !AddtocartDetails.color || !AddtocartDetails.size ){
                      setAddtocartDetails({...AddtocartDetails,loading:false,error:' Select What Color And Size You Want '})                   
                  }else{

                    const item_to_be_added = {
                      myproduct_id:product.id,
                      quantity:AddtocartDetails.quantity,
                      colour_id:AddtocartDetails.color,
                      size_id:AddtocartDetails.size
                    }

                    Axios.post( 'mycart/mycart/' + context.User_Cart.id + '/add_to_cart/' , item_to_be_added ).then(
                      response => {
                        setAddtocartDetails({...AddtocartDetails,loading:false,error:false,success:'Item Was Added To Cart Successfully'})                   
                        context.Refresh_Cart()                        
                        setTimeout(() => {
                          setopen_add_to_cart(false)
                        }, 2000);
                      }
                    ).catch(
                      e => {
                        setAddtocartDetails({...AddtocartDetails,loading:false,error:'Something Went Wrong'})                   
                      }
                    )

                  }

                }
              }
            }

          }else{
            const item_to_be_added = {
              myproduct_id:product.id,
              quantity:AddtocartDetails.quantity,
            }

            Axios.post( 'mycart/mycart/' + context.User_Cart.id + '/add_to_cart/' , item_to_be_added ).then(
              response => {
                setAddtocartDetails({...AddtocartDetails,loading:false,error:false,success:'Item Was Added To Cart Successfully'})                   
                context.Refresh_Cart()                
                setTimeout(() => {
                  setopen_add_to_cart(false)
                }, 2000);
              }
            ).catch(
              e => {
                setAddtocartDetails({...AddtocartDetails,loading:false,error:'Something Went Wrong'})                   
              }
            )
          }

        }

      }


      const open_Compose_the_reply = (comment) => {
        setcommentToreply({
          comment:comment,
          value:'',
          error:false,
          loading:false,
          msg:''
        })
        set_open_compose_reply(true)
        set_open_compose_comment(false)
        setopen_add_to_cart(false)
      }

      const open_Compose_the_comment = () => {
        set_open_compose_reply(false)
        set_open_compose_comment(true)
        setopen_add_to_cart(false)
      }

      const open_Cart_div = () => {
        set_open_compose_reply(false)
        set_open_compose_comment(false)
        setopen_add_to_cart(true)
      }

      const openbigimageHandler = () => {
        set_open_compose_reply(false)
        set_open_compose_comment(false)
        setopen_add_to_cart(false)
        setopenbigimage(true)
      }

      const post_commentHandler = (e) => {

        e.preventDefault()
        setAddcomment({...Addcomment,error:false,loading:true})

        if( Addcomment.value === '' ){
          setAddcomment({...Addcomment,error:false,loading:false})
        }else{

          Axios.post('/myproduct/myproduct/' + product_Id + '/myproduct_comment/', {myproduct:product_Id,comment:Addcomment.value} ).then(

            response => {
              Axios.get('/myproduct/myproduct/' + product_Id + '/' ).then(

                response => {
                  setcomment_list({...comment_list,list:response.data.comments})
                  setAddcomment({value:'',error:false,loading:false,msg:'Comment Was Successfuly Posted'})
                  setTimeout(() => {
                    setAddcomment({value:'',error:false,loading:false,msg:''})
                  }, 3000);
                }
      
            ).catch(
              e => {
                setloadstatus({ error:true,loading:false })
                setAddcomment({...Addcomment,error:false,loading:false,msg:'Something Went Wrong Try Again'})
              }
            )
            }

          ).catch(

            e => {
              setAddcomment({...Addcomment,error:false,loading:false,msg:'Something Went Wrong Try Again'})
            }

          )

        }

      }


      const reply_commentHandler = (e) => {

        e.preventDefault()
        setcommentToreply({...commentToreply,error:false,loading:true})

        if( commentToreply.value === '' ){
          setcommentToreply({...commentToreply,error:false,loading:false})
        }else{

          Axios.post('/myproduct/comment/' + commentToreply.comment.id + '/reply_comment/', {comment:commentToreply.comment.id,reply:commentToreply.value} ).then(
 
            response => {
              Axios.get('/myproduct/myproduct/' + product_Id + '/' ).then(

                response => {
                  setcomment_list({...comment_list,list:response.data.comments})
                  setcommentToreply({...commentToreply,value:'',error:false,loading:false,msg:'Comment Was Successfuly Posted'})
                  setTimeout(() => {
                    setcommentToreply({...commentToreply,value:'',error:false,loading:false,msg:''})
                  }, 3000);
                }
      
            ).catch(
              e => {
                setloadstatus({ error:true,loading:false })
                setcommentToreply({...commentToreply,error:true,loading:false,msg:'Something Went Wrong Try Again'})
              }
            )
            }

          ).catch(

            e => {
              setcommentToreply({...commentToreply,error:true,loading:false,msg:'Something Went Wrong Try Again'})
            }

          )

        }

      }


      const moveImage = (operation) => {

        var numit = product_img.number

        if (operation === 'sub' ) {
          var newnumit = numit - 1
            if( newnumit < 1 ){
              if( product_img.image_2 && product_img.image_3 ){
                newnumit = 3
              }else{
                if( product_img.image_2 && !product_img.image_3 ){
                  newnumit = 2
                }
              }
            }
        }else{
          if ( operation === 'add' ) {
            newnumit = numit + 1
            if( newnumit > 3 ){
                newnumit = 1
            }
          }
        }

        setproduct_img({...product_img,number:newnumit})

      }

      if ( product_img.number === 1 ) {
          var bigshowimage = product_img.image_1
      }else{
        if ( product_img.number === 2 ) {
          bigshowimage = product_img.image_2
        }else{
          if ( product_img.number === 3 ) {
            bigshowimage = product_img.image_3
          }
        }
      }


      const gogo = () => {
        props.history.go()
      } 
    
      const goBack = () => {
        props.history.goBack()
      }
    


      if( !loadstatus.error && loadstatus.loading && !product ){
        var toshow = <LoadingPage/>
      }else{
        if ( loadstatus.error && !loadstatus.loading && !product ) {
            toshow = <OppsPage tryagain={gogo} goback={goBack} />
        }else{
          if( !loadstatus.error && !loadstatus.loading && product ){
            toshow = <>

                <BigImage
                  show={openbigimage}
                  close={ () => setopenbigimage(false) }
                  image_fr={ bigshowimage }
                  image_1={ product_img.image_1 }
                  image_2={ product_img.image_2 } 
                  image_3={ product_img.image_3 } 
                  selectimage1={ () => setproduct_img({...product_img,number:1}) }
                  selectimage2={ () => setproduct_img({...product_img,number:2}) }
                  selectimage3={ () => setproduct_img({...product_img,number:3}) }
                />

                <ProductTemplate
                  image_fr={ bigshowimage }
                  image_1={ product_img.image_1 }
                  image_2={ product_img.image_2 } 
                  image_3={ product_img.image_3 } 
                  lessimg={ () => moveImage('sub') }
                  addimg={ () => moveImage('add') }
                  selectimage1={ () => setproduct_img({...product_img,number:1}) }
                  selectimage2={ () => setproduct_img({...product_img,number:2}) }
                  selectimage3={ () => setproduct_img({...product_img,number:3}) }
                  openbigImage={openbigimageHandler}
                  product_name={product.myproduct_name}
                  price={product.selling_price}
                  avg_rating={product.avg_rating}
                  specs={ product.specs }
                  shareurl={ "https://www.myoffsprings.com/product/" + product.slug + '/' + product_Id }
                  sizes={ product.sizes.length > 0 ? 
                    
                    <>

                            <div className="productdetailtemplate-div_first-detail-other-size_top" >
                              Size
                            </div>

                            <div className="productdetailtemplate-div_first-detail-other-size_body" >

                              { product.sizes.map( (size,index) => {

                                  return <div key={index} className="productdetailtemplate-div_first-detail-other-size_body-box" > {size.size} </div>

                                
                              } ) }

                            </div>

                    </>

                    :null }

                    
                  color={ product.colors.length > 0 ? 
                    
                    <>

                            <div className="productdetailtemplate-div_first-detail-other-size_top" >
                              Colors
                            </div>

                            <div className="productdetailtemplate-div_first-detail-other-size_body" >

                              { product.colors.map( (color,index) => {

                                  return <div key={index} className="productdetailtemplate-div_first-detail-other-size_body-box" > {color.colour} </div>

                                
                              } ) }

                            </div>

                    </>

                    :null }
                  desc={ product.description }
                  open_compose_comment={ !context.User_token && !context.User_id ? () => props.history.push('/quicksignin') : open_Compose_the_comment }
                  addtocart={!context.User_token && !context.User_id ? () => props.history.push('/quicksignin') : open_Cart_div}
                  Allcommet={ 

                        <>

                            { comment_list.list.map( ( comment , index ) => {

                                return <CommentDiv
                                         key={index}
                                         comment={comment.comment} 
                                         name={ comment.user.first_name + ' ' + comment.user.last_name }
                                         date={ comment.time_since }
                                         img={ comment.user.pro.profile_picture }
                                         open_reply_box={!context.User_token && !context.User_id ? () => props.history.push('/quicksignin') : () => open_Compose_the_reply(comment) }
                                         reply_list={

                                          comment.replies.map( (reply,index) => {

                                            return <ReplyDiv
                                              key={index}
                                              reply={reply.reply} 
                                              name={ reply.user.first_name + ' ' + reply.user.last_name }
                                              date={ reply.time_since }
                                              img={ reply.user.pro.profile_picture }
                                            />

                                          } )

                                         }


                                        />

                            } ) }

                            { comment_list.list.length < 1 ? 

                                <div className="no-comment-div" >

                                  <img className="no-comment-div-img" src={CommentImg} alt="" />

                                  <div className="no-comment-div-txt" > Be The First To Leave A Comment </div>

                                  <button className="no-comment-div-btn" onClick={!context.User_token && !context.User_id ? () => props.history.push('/quicksignin') : open_Compose_the_comment } >
                                    Leave A Comment
                                  </button>

                                </div>

                              : null }

                        </>

                   }
                />

                <ProductComposeComment 
                  show={open_compose_comment}
                  close={ () => set_open_compose_comment(false) }
                  post_comment={post_commentHandler}
                  comment={ Addcomment.value }
                  onChange={ (event) => setAddcomment({...Addcomment,value:event.target.value})  }
                  sbt={ Addcomment.loading && !Addcomment.error ? <BtnSpin bgColor="white" /> : 'Post Comment' }
                  disabled={ Addcomment.loading && !Addcomment.error ? true : false }
                  msg={ Addcomment.msg }
                  comdisplay={ Addcomment.msg === 'Comment Was Successfuly Posted' || Addcomment.msg === 'Something Went Wrong Try Again' ? 'block' : 'none' }
                  comcolor={ Addcomment.msg === 'Comment Was Successfuly Posted' ? 'green' : 'tomato' }
                />

                <ProductComposeReply
                  show={open_compose_reply}
                  close={ () => set_open_compose_reply(false) }
                  commentToreply={ 

                    commentToreply.comment ? 
                    
                      <ComposeReplyReply
                        story={commentToreply.comment.comment}
                        img={ commentToreply.comment.user.pro.profile_picture }
                        name={ commentToreply.comment.user.first_name + ' ' + commentToreply.comment.user.last_name }
                        date={ commentToreply.comment.time_since }
                        msg={ commentToreply.msg }
                        comdisplay={ commentToreply.msg === 'Comment Was Successfuly Posted' || commentToreply.msg === 'Something Went Wrong Try Again' ? 'block' : 'none' }
                        comcolor={ commentToreply.msg === 'Comment Was Successfuly Posted' ? 'green' : 'tomato' }     
                      />

                    : null

                   }
                   post_reply={reply_commentHandler}
                   reply={ commentToreply.value }
                   onChange={ (event) => setcommentToreply({...commentToreply,value:event.target.value})  }
                   sbt={ commentToreply.loading && !commentToreply.error ? <BtnSpin bgColor="white" /> : 'Reply Comment' }
                   disabled={ commentToreply.loading && !commentToreply.error ? true : false } 
                  />



            <div className="add_to_cart_back" style={{
              display: open_add_to_cart ? 'flex' : 'none'
            }} >

                <Addtocartdiv
                  show={open_add_to_cart}
                  qty={AddtocartDetails.quantity}
                  changeqty={ (event) => setAddtocartDetails({...AddtocartDetails,quantity:event.target.value}) }
                  price={ product.selling_price * AddtocartDetails.quantity }
                  close={ () => setopen_add_to_cart(false) }
                  colorAvailable={ product.colors.length < 1 ? null :
                  
                    <>

                      { product.colors.map( (color,index) => {
                        return  <div key={index}
                                     style={{ border: AddtocartDetails.color === color.id ? '1px solid tomato' : '' }}
                                     className="addtocart-div_form-col_box-val"
                                     onClick={ () => setAddtocartDetails({...AddtocartDetails,color:color.id}) } >
                                    {color.colour}
                                </div>
                      } ) }

                    </>
                  
                  }

                  sizeAvailable={ product.sizes.length < 1 ? null :
                  
                    <>

                      { product.sizes.map( (size,index) => {
                        return  <div key={index} 
                                     style={{ border: AddtocartDetails.size === size.id ? '1px solid tomato' : '' }}
                                     className="addtocart-div_form-col_box-val"
                                     onClick={ () => setAddtocartDetails({...AddtocartDetails,size:size.id}) } >
                                    {size.size}
                                </div>
                      } ) }

                    </>
                  
                  }

                  addtocart={HandlerToCart}
                  btn={ AddtocartDetails.loading ? <BtnSpin bgColor="white" /> : 'Add To Cart' }
                  comdisplay={ AddtocartDetails.error || AddtocartDetails.success ? 'block' : 'none' }
                  comcolor={ AddtocartDetails.error ? 'tomato' : 'green' }
                  msg={ AddtocartDetails.error ? AddtocartDetails.error : AddtocartDetails.success }
                  disabled={AddtocartDetails.loading}
                />  

                
            </div>

{/* 
            <div className="addto_to_Btn_cart" >

            </div> */}

            </>
          }
        }
      }




      return ( 

        <>

            {toshow}

        </>
        
      );

}

export default ProductDetailPage;