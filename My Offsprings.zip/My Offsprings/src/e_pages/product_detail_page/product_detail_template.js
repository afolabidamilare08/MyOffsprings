import React from 'react';
import {Link} from 'react-router-dom';
import { MdAddShoppingCart } from 'react-icons/md';
import { BsFillCaretLeftFill , BsPersonFill , BsFillCaretRightFill } from 'react-icons/bs';
import { AiFillStar , AiOutlinePlus , AiOutlineStar } from 'react-icons/ai';
import { BiCalendar } from 'react-icons/bi';
import {TiArrowForwardOutline} from 'react-icons/ti';
import { MdLocationOn } from 'react-icons/md';
import { LoginBtn, InputWithLabel } from '../../component/login_components/login_components';
import { FaWhatsappSquare, FaFacebookSquare, FaTwitterSquare, FaLinkedinIn, FaTelegram } from 'react-icons/fa';
import {
    FacebookShareButton,
    LinkedinShareButton,
    TelegramShareButton,
    TwitterShareButton,
    WhatsappShareButton
  } from "react-share";



const url = ''


export const ReplyDiv = (props) => {

    return (

        <div className="reply_div" >

            <div className="reply_div-top" >

                <div className="reply_div-top_img" >
                   { props.img ? <img src={ url + props.img} alt="" className="comment_div-top_img-pic" /> : <BsPersonFill className="comment_div-top_img-ic" /> }
                </div>

                <div className="reply_div-top_name" >
                    <span className="reply_div-top_name-top" > {props.name} </span>
                    <br/>
                    <span className="reply_div-top_name-btm" > {props.date} </span>
                </div>

            </div>

            <div className="reply_div-body" >
                {props.reply}
            </div>

        </div>

    );

}

export const CommentDiv = (props) => {

    return (

        <div className="comment_div" >

            <div className="comment_div-top" >

                <div className="comment_div-top_img" >
                    { props.img ? <img src={ url + props.img} alt="" className="comment_div-top_img-pic" /> : <BsPersonFill className="comment_div-top_img-ic" /> }
                </div>

                <div className="comment_div-top_name" >
                    <span className="comment_div-top_name-top" > {props.name} </span>
                        <br/>
                    <span className="comment_div-top_name-btm" > {props.date} </span>
                </div>

            </div>

            <div className="comment_div-body" >
                {props.comment}
            </div>

            <Link to="#" className="comment_div-text" onClick={props.open_reply_box} > Reply Comment <TiArrowForwardOutline className="comment_div-text-ic" /> </Link>

            <div className="comment_div-reply" >

                {props.reply_list}

            </div>

        </div>

    );

}

export const ComposeReplyReply = (props) => {

    return (

        <div className="compose_reply_reply" >

            <div className="compose_reply_reply-top" >

                <div className="compose_reply_reply-top_img" >
                { props.img ? <img src={ url + props.img} alt="" className="compose_reply_reply-top_img-pic" /> : <BsPersonFill className="compose_reply_reply-top_img-ic" /> }
                </div>

                <div className="compose_reply_reply-top_name" >
                    <span className="compose_reply_reply-top_name-top" > {props.name} </span>
                    <br/>
                    <span className="compose_reply_reply-top_name-btm" > {props.date} </span>
                </div>

            </div>

            <div className="product_compose_comment-top-msg" style={{ display: props.comdisplay,color:props.comcolor,padding:'1rem',textAlign:'center' }} >
                {props.msg}
            </div>

            <div className="compose_reply_reply-body" >
                {props.story}
            </div>

        </div>
 
    );

}

export const ProductTemplate = (props) => {

    return (

        <div className="productdetailtemplate-div" >

            <div className="productdetailtemplate-div_first" >

                <div className="productdetailtemplate-div_first-detail" >

                    <div className="productdetailtemplate-div_first-detail-img" >

                        { props.image_2 || props.image_3 ? 
                            <div className="productdetailtemplate-div_first-detail-img_left" onClick={props.lessimg} >
                                <BsFillCaretLeftFill className="productdetailtemplate-div_first-detail-img_left-ic" />
                            </div>
                        : null }

                        <img src={props.image_fr} alt="" onClick={props.openbigImage} className="productdetailtemplate-div_first-detail-img_pic" />
                        
                        {/* <div className="productdetailtemplate-div_first-detail-img_right" onClick={props.addimg} >
                            <BsFillCaretRightFill className="productdetailtemplate-div_first-detail-img_right-ic" />
                        </div> */}

                        { props.image_2 || props.image_3 ? 
                            <div className="productdetailtemplate-div_first-detail-img_right" onClick={props.lessimg} >
                                <BsFillCaretRightFill className="productdetailtemplate-div_first-detail-img_right-ic" />
                            </div>
                        : null }

                    </div>

                    <div className="productdetailtemplate-div_first-detail-more" >

                        <div className="productdetailtemplate-div_first-detail-more-left" > Product Images </div>

                        <div className="productdetailtemplate-div_first-detail-more-right" >
                            
                            <div className="productdetailtemplate-div_first-detail-more-right-box" onClick={ props.selectimage1 } >
                                <img className="productdetailtemplate-div_first-detail-more-right-box_img" src={props.image_1} alt="" />
                            </div>

                            { props.image_2 ? 
                            
                                <div className="productdetailtemplate-div_first-detail-more-right-box" onClick={ props.selectimage2 } >
                                    <img className="productdetailtemplate-div_first-detail-more-right-box_img" src={props.image_2} alt="" />
                                </div>
                            
                            : null }

                            { props.image_3 ? 
                            
                                <div className="productdetailtemplate-div_first-detail-more-right-box" onClick={ props.selectimage3 } >
                                    <img className="productdetailtemplate-div_first-detail-more-right-box_img" src={props.image_3} alt="" />
                                </div>
                            
                            : null }

                        </div>

                    </div>
                
                    <div className="productdetailtemplate-div_first-detail-other" >

                        <div className="productdetailtemplate-div_first-detail-other-name" >
                            {props.product_name}
                        </div>

                        <div className="productdetailtemplate-div_first-detail-other-rating" >

                            <div className="productdetailtemplate-div_first-detail-other-rating-right" >


                            { props.avg_rating > 0 ?  

                                    <AiFillStar className="productdetailtemplate-div_first-detail-other-rating-ic" />

                                    : <AiOutlineStar className="productdetailtemplate-div_first-detail-other-rating-ic" /> 

                                    }

                                    { props.avg_rating > 1 ? 

                                    <AiFillStar className="productdetailtemplate-div_first-detail-other-rating-ic" />

                                    : <AiOutlineStar className="productdetailtemplate-div_first-detail-other-rating-ic" /> 

                                    }

                                    { props.avg_rating > 2 ? 

                                    <AiFillStar className="productdetailtemplate-div_first-detail-other-rating-ic" />

                                    : <AiOutlineStar className="productdetailtemplate-div_first-detail-other-rating-ic" /> 

                                    }

                                    { props.avg_rating > 3 ? 

                                    <AiFillStar className="productdetailtemplate-div_first-detail-other-rating-ic" />

                                    : <AiOutlineStar className="productdetailtemplate-div_first-detail-other-rating-ic" /> 

                                    }

                                    { props.avg_rating > 4 ? 

                                    <AiFillStar className="productdetailtemplate-div_first-detail-other-rating-ic" />

                                    : <AiOutlineStar className="productdetailtemplate-div_first-detail-other-rating-ic" /> 

                                    }


                            </div>
                            
                            <div className="productdetailtemplate-div_first-detail-other-rating-left" >
                                ₦ {new Intl.NumberFormat({ style: 'currency', currency: 'EUR' }).format(props.price) }
                            </div>

                        </div>

                        <div className="productdetailtemplate-div_first-detail-other-size" >

                            {props.sizes}

                        </div>

                        <div className="productdetailtemplate-div_first-detail-other-size" >

                            {props.color}

                        </div>

                        <div className="productdetailtemplate-div_first-detail-other-dec" >

                            <div className="productdetailtemplate-div_first-detail-other-dec-top" > Product Description </div>

                            <div className="productdetailtemplate-div_first-detail-other-dec-body" >
                                {props.desc}
                            </div>

                            {/* <textarea value={props.desc} className="productdetailtemplate-div_first-detail-other-dec-txt" >

                            </textarea> */}

                        </div>

                        { props.specs.length > 0 ? 
                        
                            <div className="productdetailtemplate-div_first-detail-other-dec" >

                                <div className="productdetailtemplate-div_first-detail-other-dec-top" > Specifications </div>

                                <div className="productdetailtemplate-div_first-detail-other-dec-body" >
                                    {props.specs.map( ( spec , index ) => {

                                        return <li key={index} className="productdetailtemplate-div_first-detail-other-dec-body-div" >
                                                    <span> { spec.title } </span> - <span> { spec.response } </span>
                                                </li>

                                    } )}
                                </div>

                            </div>
                        
                        : null }


                        <div className="productdetailtemplate-div_first-detail-other-dec" style={{
                            width:'fit-content'
                        }} >


                             <div className="productdetailtemplate-div_first-detail-other-dec-top" style={{
                                 textAlign:'center',
                                 fontSize:'1.3rem'
                             }} > Share This Product </div>


                            <div className="productdetailtemplate-div_first-detail-other-dec-body" style={{
                                marginTop:'.5rem'
                            }} >

                                <WhatsappShareButton className="referf"  
                                    url={props.shareurl}
                                    title={props.sharetitle} >
                                    <div className="main_referal_div_first_linkdiv_socialboxes_boxone">
                                        <FaWhatsappSquare 
                                        className="main_referal_div_first_linkdiv_socialboxes_boxone_ic"
                                        style={{
                                            width:'2.5rem',
                                            height:'2.5rem'
                                        }}
                                        />
                                    </div>
                                </WhatsappShareButton>

                                <FacebookShareButton quote={props.sharetitle} className="referf" url={props.shareurl}>
                                    <div className="main_referal_div_first_linkdiv_socialboxes_boxone">
                                        <FaFacebookSquare  
                                            className="main_referal_div_first_linkdiv_socialboxes_boxone_ic"
                                            style={{
                                                width:'2.5rem',
                                                height:'2.5rem'
                                            }}
                                        />
                                    </div>  
                                </FacebookShareButton> 

                                <TwitterShareButton title={props.sharetitle} className="referf" url={props.shareurl}>
                                    <div className="main_referal_div_first_linkdiv_socialboxes_boxone">                                
                                        <FaTwitterSquare 
                                            className="main_referal_div_first_linkdiv_socialboxes_boxone_ic"
                                            style={{
                                                width:'2.5rem',
                                                height:'2.5rem'
                                            }}
                                        />
                                    </div>
                                </TwitterShareButton>

                                <LinkedinShareButton summary={props.sharetitle} className="referf" url={props.shareurl}>
                                    <div className="main_referal_div_first_linkdiv_socialboxes_boxone">
                                        <FaLinkedinIn 
                                            className="main_referal_div_first_linkdiv_socialboxes_boxone_ic"
                                            style={{
                                                width:'2.5rem',
                                                height:'2.5rem'
                                            }}
                                        />
                                    </div>
                                </LinkedinShareButton>

                                <TelegramShareButton title={props.sharetitle} className="referf" url={props.shareurl}>
                                    <div className="main_referal_div_first_linkdiv_socialboxes_boxone">
                                        <FaTelegram 
                                            className="main_referal_div_first_linkdiv_socialboxes_boxone_ic"
                                            style={{
                                                width:'2.5rem',
                                                height:'2.5rem'
                                            }}
                                        />
                                    </div>
                                </TelegramShareButton>

                            </div>
    
                        </div>


                        <button onClick={props.addtocart} className="productdetailtemplate-div_first-detail-other-btn" >

                            <MdAddShoppingCart className="productdetailtemplate-div_first-detail-other-btn-ic" />

                            Add To Cart


                        </button>

                    </div>

                </div>

                <div className="productdetailtemplate-div_first-delivery" >

                    <div className="productdetailtemplate-div_first-delivery-delivery" >

                        <div className="productdetailtemplate-div_first-delivery-delivery-top" > Delivery Information </div>

                        <div className="productdetailtemplate-div_first-delivery-delivery-body" >
                            
                            <div className="productdetailtemplate-div_first-delivery-delivery-body-left" >

                                <BiCalendar className="productdetailtemplate-div_first-delivery-delivery-body-left-ic" />

                            </div>

                            <div className="productdetailtemplate-div_first-delivery-delivery-body-right" >

                                <div className="productdetailtemplate-div_first-delivery-delivery-body-right-top" > Delivery Dates </div>

                                <div className="productdetailtemplate-div_first-delivery-delivery-body-right-body" >
                                    All products ordered would be 
                                    delivered on wednesdays and saturdays.
                                </div>

                            </div>

                        </div>

                        <div className="productdetailtemplate-div_first-delivery-delivery-body" >
                            
                            <div className="productdetailtemplate-div_first-delivery-delivery-body-left" >

                                <MdLocationOn className="productdetailtemplate-div_first-delivery-delivery-body-left-ic" />

                            </div>

                            <div className="productdetailtemplate-div_first-delivery-delivery-body-right" >

                                <div className="productdetailtemplate-div_first-delivery-delivery-body-right-top" > Delivery Stations </div>

                                <div className="productdetailtemplate-div_first-delivery-delivery-body-right-body" >
                                    All products will be delivered to the address stated on the checkoutpage
                                </div>

                            </div>

                        </div>

                    </div>

                    <div className="productdetailtemplate-div_first-delivery-delivery" >

                        <div className="productdetailtemplate-div_first-delivery-delivery-top" > Return Policy </div>

                        <div className="productdetailtemplate-div_first-delivery-delivery-policy" >
                            This policy only applies to returnable goods from N1000 upward
                            <br/>

                            {/* <div className="productdetailtemplate-div_first-delivery-delivery-policy-title" >REFUND ONLINE POLICY</div> */}
                            You can return all eligible item(s) within 7 business days to any selected MyOffspring Pickup Stations.

                            <div className="productdetailtemplate-div_first-delivery-delivery-policy-title" >PREPARE THE ITEM</div>
                            Place the item in its original packaging, including any accessories, tags, labels or freebies otherwise,
                            your return will be invalid.

                            <div className="productdetailtemplate-div_first-delivery-delivery-policy-title" >DROP OFF THE ITEMS OR SCHEDULE A PICK UP</div>
                            Return the item at our pickup stations or we can pick up from you within 1 - 4 business days (Transport will be deducted).
                            Always ensure your return slip is signed by our agents as your proof of return.


                            <div className="productdetailtemplate-div_first-delivery-delivery-policy-title" >REFUND PROCESSED</div>
                            Once we receive your returned item, we will inspect it and process your refund within 10 business days 
                            into your back account or wallet.

                        </div>

                    </div>

                </div>

            </div>

            <div className="productdetailtemplate-div_comment" >


                <div className="productdetailtemplate-div_comment_top" >
                    <div className="productdetailtemplate-div_comment_top-left" >Comments</div>
                    <Link to="#" className="productdetailtemplate-div_comment_top-right" onClick={props.open_compose_comment} > Leave A Comment </Link>
                </div>

                {/* <CommentDiv
                    open_reply_box={props.open_reply_box}
                /> */}

                { props.Allcommet }

            </div>

        </div>

    );

}

export const ProductComposeComment = (props) => {

    return (

        <div className="product_compose_comment" style={{

            transform: !props.show ? "translateX(50rem)" : "translateX(0)"

        }} >

            <div className="product_compose_comment-top" >

                <div className="product_compose_comment-top_title" >
                    Comment
                </div>

                <AiOutlinePlus className="addtocart-div_top-cancel" onClick={props.close} />

            </div>

            <div className="product_compose_comment-top-msg" style={{ display: props.comdisplay,color:props.comcolor }} >
                {props.msg}
            </div>

            <form className="product_compose_comment-form" onSubmit={props.post_comment} >

                <textarea className="product_compose_comment-form-text" value={props.comment} onChange={props.onChange} placeholder="Leave A Comment About The Product" ></textarea>

                <LoginBtn value={props.sbt} disabled={props.disabled} />

            </form>

        </div>

    );

}

export const ProductComposeReply = (props) => {

    return (

        <div className="product_compose_reply" style={{

            transform: !props.show ? "translateY(80rem)" : "translateY(0)"

        }} >

            <div className="product_compose_reply-top" >

                <div className="product_compose_reply-top_title" >
                    Reply Comment
                </div>

                <AiOutlinePlus className="addtocart-div_top-cancel" onClick={props.close} />

            </div>

            {props.commentToreply}

            <form className="product_compose_reply-form" onSubmit={props.post_reply} >

                <textarea className="product_compose_reply-form-text" placeholder="Reply Comment " value={props.reply} onChange={props.onChange} ></textarea>

                <LoginBtn value={props.sbt} disabled={props.disabled} />

            </form>

        </div>

    );

}

export const Addtocartdiv = (props) => {

    return(

        <div className="addtocart-div" style={{

            transform: !props.show ? "translateY(80rem)" : "translateY(0)"

        }} >

            <div className="addtocart-div_top" >

                <div className="addtocart-div_top-title" >
                    Add To Cart
                </div>

                <AiOutlinePlus className="addtocart-div_top-cancel" onClick={props.close} />

            </div>

            <form onSubmit={props.addtocart} className="addtocart-div_form" >

                <div className="product_compose_comment-top-msg" style={{ display: props.comdisplay,color:props.comcolor }} >
                    {props.msg}
                </div>
                
                <InputWithLabel
                    label="Quantity"
                    type="number"
                    onChange={props.changeqty}
                    value={props.qty} 
                />
                
                { props.colorAvailable ?
                
                    <div className="addtocart-div_form-col" >
                            
                        <div className="addtocart-div_form-col_top" >
                            Color
                        </div>

                        <div className="addtocart-div_form-col_box" >

                            {props.colorAvailable}

                        </div>

                    </div>
                
                : null }



                { props.sizeAvailable ?
                
                    <div className="addtocart-div_form-col" >
                            
                        <div className="addtocart-div_form-col_top" >
                            Size
                        </div>

                        <div className="addtocart-div_form-col_box" >

                            {props.sizeAvailable}

                        </div>

                    </div>
                
                : null }


                <div className="addtocart-div_price" >
                   <span className="addtocart-div_price_total" >Total Price :</span> ₦ {new Intl.NumberFormat({ style: 'currency', currency: 'EUR' }).format(props.price) }
                </div>

                <LoginBtn
                    value={props.btn}
                    disabled={props.disabled}
                />
                
            </form>

        </div>

    );

}

export const BigImage = (props) => {

    return(
            <div className="product_backdrop_div" style={{
                display: props.show ? 'flex' : 'none'
            }} >
               
               <div className="product_backdrop_div-mid" >

                  <div className="product_backdrop_div-mid_top" >

                      <div className="product_backdrop_div-mid_top-right" > Product Image </div>

                      <AiOutlinePlus className="product_backdrop_div-mid_top-right-ic" onClick={props.close} />

                  </div>

                  <div className="product_backdrop_div-mid_mg" >
                        <img src={props.image_fr} alt="" className="product_backdrop_div-mid_mg_pic" />
                  </div>

                  <div className="product_backdrop_div-mid_foot" >

                      <div className="product_backdrop_div-mid_foot-dic" >
                          <img className="product_backdrop_div-mid_foot-dic_img" onClick={ props.selectimage1 }  src={props.image_1} alt="" />
                      </div>

                      { props.image_2 ? 
                            <div className="product_backdrop_div-mid_foot-dic" >
                                <img className="product_backdrop_div-mid_foot-dic_img" onClick={ props.selectimage2 } src={props.image_2} alt="" />
                            </div>
                       : null }

                        { props.image_3 ? 
                            <div className="product_backdrop_div-mid_foot-dic" >
                                <img className="product_backdrop_div-mid_foot-dic_img" onClick={ props.selectimage3 } src={props.image_3} alt="" />
                            </div>
                       : null }

                  </div>

               </div>

            </div>
    );

}