import React from 'react';
import ReactDOM from 'react-dom';
import './index.css';
import axios from 'axios';
import App from './App';
// import * as serviceWorker from './serviceWorker';





axios.defaults.baseURL =  'https://myoffsprings.xyz'
// 'http://127.0.0.1:8000';
// https://myoffsprings.xyz

// 'http://35.156.230.147:8001' ;

// axios.interceptors.request.use(request => {
//     // console.log(request);
//     return request;
// }, error => {
//     console.log(error);
//     return Promise.reject(error);
// });

// axios.interceptors.response.use(response => {
//     console.log(response);
//     return response;
// }, error => {
//     console.log(error);
//     return Promise.reject(error);
// });


// [
//     {
//         "source": "https://farmyapp.com",
//         "target": "https://www.farmyapp.com",
//         "status": "302",
//         "condition": null
//     },
//     {
//         "source": "https://prod.douphwbi6ozp5.amplifyapp.com/sell",
//         "target": "https://prod.douphwbi6ozp5.amplifyapp.com/",
//         "status": "301",
//         "condition": null
//     }
// ]



ReactDOM.render(<App />, document.getElementById('root'));

// If you want your app to work offline and load faster, you can change
// unregister() to register() below. Note this comes with some pitfalls.
// Learn more about service workers: https://bit.ly/CRA-PWA
// serviceWorker.unregister();
